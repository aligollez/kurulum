export const version = "random/5.4.0";
//# sourceMappingURL=_version.js.map