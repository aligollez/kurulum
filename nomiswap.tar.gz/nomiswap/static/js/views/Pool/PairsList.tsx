import type { Pair } from '@nominex/nomiswap-sdk'
import React from 'react'
import { useTranslation } from 'contexts/Localization'
import useTheme from 'hooks/useTheme'
import { Text, Grid, BoxProps } from '@nominex/dex-uikit'
import FullPositionCard from '../../components/PositionCard'
import Dots from '../../components/Loader/Dots'
import BodyWrapper from './Body'

type Props = {
  isLoading: boolean
  account: boolean
  items?: Pair[]
} & BoxProps

const PairsList: React.FC<Props> = ({ account, isLoading, items = [], ...props }) => {
  const { t } = useTranslation()
  const { theme } = useTheme()

  if (!account) {
    return (
      <BodyWrapper minHeight="236px">
        <Text color="placeholder" my="auto" textAlign="center">
          {t('Connect to a wallet to view your liquidity.')}
        </Text>
      </BodyWrapper>
    )
  }

  if (isLoading) {
    return (
      <BodyWrapper minHeight="236px">
        <Text my="auto" color="placeholder" textAlign="center">
          <Dots>{t('Loading')}</Dots>
        </Text>
      </BodyWrapper>
    )
  }

  if (items?.length > 0) {
    return (
      <Grid {...props}>
        {items.map((pair) => (
          <FullPositionCard key={pair.liquidityToken.address} pair={pair} background={theme.colors.input} mt="20px" />
        ))}
      </Grid>
    )
  }

  return null
}

export default PairsList
