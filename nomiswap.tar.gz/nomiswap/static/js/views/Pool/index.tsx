import React, { useMemo } from 'react'
import { Pair } from '@nominex/nomiswap-sdk'
import { Text, Button, AddIcon } from '@nominex/dex-uikit'
import { Link } from 'react-router-dom'
import { useTranslation } from 'contexts/Localization'
import useActiveWeb3React from 'hooks/useActiveWeb3React'
import { useTokenBalancesWithLoadingIndicator } from '../../state/wallet/hooks'
import { toLiquidityToken, useTrackedTokenPairs } from '../../state/user/hooks'
import { usePairs } from '../../hooks/usePairs'
import { AppBody, AppTitle } from '../../components/App'
import FindLpTokensLink from './FindLpTokensLink'
import Page from '../Page'
import PairsList from './PairsList'
import BodyWrapper from './Body'

export default function Pool() {
  const { account } = useActiveWeb3React()
  const { t } = useTranslation()

  // fetch the user's balances of all tracked V2 LP tokens
  const trackedTokenPairs = useTrackedTokenPairs()

  const tokenPairsWithLiquidityTokens = useMemo(
    () => trackedTokenPairs.map((tokens) => ({ liquidityToken: toLiquidityToken(tokens), tokens })),
    [trackedTokenPairs],
  )
  const liquidityTokens = useMemo(
    () => tokenPairsWithLiquidityTokens.map((tpwlt) => tpwlt.liquidityToken),
    [tokenPairsWithLiquidityTokens],
  )
  const [pairsBalances, fetchingPairBalances] = useTokenBalancesWithLoadingIndicator(
    account ?? undefined,
    liquidityTokens,
  )

  // fetch the reserves for all V2 pools in which the user has a balance
  const liquidityTokensWithBalances = useMemo(
    () =>
      tokenPairsWithLiquidityTokens.filter(({ liquidityToken }) =>
        pairsBalances[liquidityToken.address]?.greaterThan('0'),
      ),
    [tokenPairsWithLiquidityTokens, pairsBalances],
  )

  const pairs = usePairs(liquidityTokensWithBalances.map(({ tokens }) => tokens))
  const isLoading =
    fetchingPairBalances || pairs?.length < liquidityTokensWithBalances.length || pairs?.some((pair) => !pair)

  const allPairsWithLiquidity = pairs.map(([, pair]) => pair).filter((pair): pair is Pair => Boolean(pair))

  return (
    <Page>
      <AppTitle
        title={t('Your Liquidity')}
        subtitle={t('Remove liquidity to receive tokens back')}
        alignItems="center"
        mb="24px"
      />
      <AppBody>
        <PairsList pt="16px" account={!!account} isLoading={isLoading} items={allPairsWithLiquidity} />

        {account && !isLoading && (
          <BodyWrapper minHeight={allPairsWithLiquidity.length === 0 ? '236px' : 'auto'}>
            {allPairsWithLiquidity.length === 0 && (
              <Text mt="auto" color="placeholder" textAlign="center">
                {t('No liquidity found.')}
              </Text>
            )}

            <FindLpTokensLink />
          </BodyWrapper>
        )}

        <Button
          scale="lg"
          id="join-pool-button"
          as={Link}
          to="/liquidity/add"
          width="100%"
          startIcon={<AddIcon color="white" />}
        >
          {t('Add Liquidity')}
        </Button>
      </AppBody>
    </Page>
  )
}
