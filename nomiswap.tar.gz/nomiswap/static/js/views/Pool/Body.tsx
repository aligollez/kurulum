import styled from 'styled-components'
import { CardBody } from '@nominex/dex-uikit'

const Body = styled(CardBody)<{ minHeight: string }>`
  background-color: ${({ theme }) => theme.colors.backgroundAlt2};
  border-radius: 12px;
  margin-top: 20px;
  margin-bottom: 20px;
  min-height: ${({ minHeight }) => minHeight};
  display: flex;
  flex-direction: column;
`
export default Body
