import React from 'react'
import { Text, Flex, Button } from '@nominex/dex-uikit'
import { Link } from 'react-router-dom'
import { useTranslation } from 'contexts/Localization'

export default function FindLpTokensLink() {
  const { t } = useTranslation()

  return (
    <Flex flexDirection="column" alignItems="center">
      <Text color="placeholder" mb="12px">
        {t("Don't see a pool you joined?")}
      </Text>
      <Button id="import-pool-link" variant="secondary" scale="sm" as={Link} to="/liquidity/find">
        {t('Find other LP tokens')}
      </Button>
    </Flex>
  )
}
