import React from 'react'
import { useSelector } from 'react-redux'
// import styled from 'styled-components'
import { Flex } from '@nominex/dex-uikit'
import { State } from 'state/types'
import { useTranslation } from 'contexts/Localization'
import { AppTitle } from 'components/App'
import { ReferralLinkWidget } from 'components/ReferralLinkWidget'
import Page from '../Page'
import NonAuthorized from './NonAuthorized'
/*
import FarmingLevelCard from './FarmingLevelCard'
import TabMenu from './TabMenu'
import Dashboard from './Dashboard'
import Farming from './Farming'
import LaunchPools from './LaunchPools'
import Trading from './Trading'

const StyledTabPanel = styled(Flex)`
  padding: 32px;
`
*/

export default function Referrals() {
  const { t } = useTranslation()
  // const [activeTab, setActiveTab] = useState('dashboard')
  const { isLoaded, userId } = useSelector((state: State) => state.profile.authentication)

  return (
    <Page>
      <Flex width="100%" justifyContent="space-between" flexWrap="wrap">
        <AppTitle
          title={t('Invite Your Friends. Earn Cryptocurrency Together.')}
          subtitle={t(
            'Nomiswap farms offer multiple farming opportunities to you. Increase your farming rewards participating in Team Farming program and continuously grow your extra bonuses for unstoppable farming up to 10x.',
          )}
          maxWidth="532px"
          alignSelf="start"
          mb="8px"
        />
        {isLoaded && !!userId && <ReferralLinkWidget link={`https://nomiswap.io/?r=${userId}`} />}
      </Flex>

      <NonAuthorized />

      {/* TODO: temporarily disabled
      <Flex justifyContent="space-between" width="100%" mt="40px">
        <FarmingLevelCard mr={28} />

        <Flex flexGrow={1}>
          <TabMenu onTabChange={setActiveTab}>
            <StyledTabPanel>
              {{
                trading: <Trading />,
                farming: <Farming />,
                launchpools: <LaunchPools />,
              }[activeTab] || <Dashboard />}
            </StyledTabPanel>
          </TabMenu>
        </Flex>
      </Flex> */}
    </Page>
  )
}
