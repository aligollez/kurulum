import React from 'react'
import styled from 'styled-components'
import { Flex, Text, Card, Image, Tag, CardBody, Grid, useMatchBreakpoints } from '@nominex/dex-uikit'
import { useTranslation } from 'contexts/Localization'
import useTheme from 'hooks/useTheme'

const StyledCardBody = styled(CardBody)`
  padding: 0 32px 48px 32px;
`

const NonAuthorized: React.FC = () => {
  const { t } = useTranslation()
  const { theme } = useTheme()
  const { isTablet, isMobile } = useMatchBreakpoints()

  return (
    <Grid gridTemplateColumns={isTablet || isMobile ? '' : 'repeat(3, 1fr)'} gridGap="28px" my="16px">
      <Card>
        <StyledCardBody>
          <Flex justifyContent="center">
            <Image src="/images/referrals/step1.png" alt="First step" height={198} width={318} />
          </Flex>
          <Flex alignItems="center" my="12px">
            <Tag variant="lightBlue" mr="12px">
              {t('Step')} 1
            </Tag>
            <Text fontSize="20px" semibold>
              {t('Get a referral link')}
            </Text>
          </Flex>
          <Text fontSize="14px" color={`${theme.colors.white}80`}>
            {t('Connect your wallet to get a referral link')}
          </Text>
        </StyledCardBody>
      </Card>
      <Card>
        <StyledCardBody>
          <Flex justifyContent="center">
            <Image src="/images/referrals/step2.png" alt="First step" height={198} width={318} />
          </Flex>
          <Flex alignItems="center" my="12px">
            <Tag variant="lightBlue" mr="12px">
              {t('Step')} 2
            </Tag>
            <Text fontSize="20px" semibold>
              {t('Invite friends')}
            </Text>
          </Flex>
          <Text fontSize="14px" color={`${theme.colors.white}80`}>
            {t('Invite your friends to register via your referral link')}
          </Text>
        </StyledCardBody>
      </Card>
      <Card>
        <StyledCardBody>
          <Flex justifyContent="center">
            <Image src="/images/referrals/step3.png" alt="First step" height={198} width={318} />
          </Flex>
          <Flex alignItems="center" my="12px">
            <Tag variant="lightBlue" mr="12px">
              {t('Step')} 3
            </Tag>
            <Text fontSize="20px" semibold>
              {t('Earn crypto')}
            </Text>
          </Flex>
          <Text fontSize="14px" color={`${theme.colors.white}80`}>
            {t('Receive referral rewards in NMX tokens from your friends’ earnings & swaps')}
          </Text>
        </StyledCardBody>
      </Card>
    </Grid>
  )
}

export default NonAuthorized
