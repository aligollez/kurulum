import React, { useEffect, useCallback, useState, useMemo, useRef } from 'react'
import { useLocation } from 'react-router-dom'
import BigNumber from 'bignumber.js'
import { useWeb3React } from '@web3-react/core'
import { RowType, Text, Flex } from '@nominex/dex-uikit'
import { ChainId } from '@nominex/nomiswap-sdk'
import styled from 'styled-components'
import Page from 'components/Layout/Page'
import { useFarms, usePollFarmsWithUserData } from 'state/farms/hooks'
import { useNmxUsdtPrice } from 'hooks/useBusdPrice'
import useIntersectionObserver from 'hooks/useIntersectionObserver'
import { DeserializedFarm } from 'state/types'
import { useTranslation } from 'contexts/Localization'
import { getBalanceNumber } from 'utils/formatBalance'
import { getFarmApr } from 'utils/apr'
import { orderBy } from 'lodash'
import isArchivedPid from 'utils/farmHelpers'
import { latinise } from 'utils/latinise'
import SearchInput from 'components/SearchInput'
import Select, { OptionProps } from 'components/Select/Select'
// import Loading from 'components/Loading'
import { FarmWithStakedValue } from './components/FarmCard/FarmCard'
import FarmTable from './components/FarmTable/FarmTable'
import FarmTabButtons from './components/FarmTabButtons'
import { RowProps } from './components/FarmTable/Row'
import { DesktopColumnSchema } from './components/types'
import ExtraRewardCard from './components/ExtraRewardCard'
// import PoolsSummaryCard from './components/PoolsSummaryCard'
import { ExtendedAppTitle } from '../../components/App'
import { StakingBanner } from './components/StakingBanner'

const Wrapper = styled.div`
  display: grid;
  grid-gap: 28px;
  grid-template-columns: 1fr;

  @media screen and (min-width: 1400px) {
    grid-template-columns: 305px auto;
    position: relative;
  }
`

const ControlContainer = styled.div`
  display: flex;
  width: 100%;
  align-items: end;
  position: relative;

  justify-content: space-between;
  flex-direction: column;

  ${({ theme }) => theme.mediaQueries.lg} {
    flex-direction: row;
    flex-wrap: wrap;
  }
`

const LabelWrapper = styled.div`
  > ${Text} {
    font-size: 12px;
  }
`

const FilterContainer = styled.div`
  display: flex;
  align-items: center;
  width: 100%;
  padding: 20px 0;

  ${({ theme }) => theme.mediaQueries.lg} {
    width: auto;
    padding: 0;
  }
`

const ViewControls = styled.div`
  flex-wrap: wrap;
  justify-content: space-between;
  display: flex;
  align-items: center;
  width: 100%;

  > div {
    padding: 8px 0;
  }

  ${({ theme }) => theme.mediaQueries.lg} {
    justify-content: flex-start;
    width: auto;

    > div {
      padding: 0;
    }
  }
`

const NUMBER_OF_FARMS_VISIBLE = 12

const getDisplayApr = (cakeRewardsApr?: number, lpRewardsApr?: number) => {
  if (cakeRewardsApr && lpRewardsApr) {
    return (cakeRewardsApr + lpRewardsApr).toLocaleString('en-US', { maximumFractionDigits: 2 })
  }
  if (cakeRewardsApr) {
    return cakeRewardsApr.toLocaleString('en-US', { maximumFractionDigits: 2 })
  }
  return null
}

const Farms: React.FC = () => {
  const { pathname } = useLocation()
  const { t } = useTranslation()
  const { data: farmsLP, userDataLoaded } = useFarms()
  const nmxPrice = useNmxUsdtPrice()
  const [query, setQuery] = useState('')
  const { account } = useWeb3React()
  const [sortOption, setSortOption] = useState('hot')
  const { observerRef, isIntersecting } = useIntersectionObserver()
  const chosenFarmsLength = useRef(0)

  const isArchived = pathname.includes('archived')
  const isInactive = pathname.includes('history')
  const showAllStaked = pathname.includes('staked')
  const isActive = !isInactive && !isArchived

  usePollFarmsWithUserData(isArchived)

  // Users with no wallet connected should see 0 as Earned amount
  // Connected users should see loading indicator until first userData has loaded
  const userDataReady = !account || (!!account && userDataLoaded)

  const activeFarms = farmsLP.filter((farm) => farm.pid !== 0 && farm.multiplier !== '0X' && !isArchivedPid(farm.pid))
  const inactiveFarms = farmsLP.filter((farm) => farm.pid !== 0 && farm.multiplier === '0X' && !isArchivedPid(farm.pid))
  const archivedFarms = farmsLP.filter((farm) => isArchivedPid(farm.pid))
  const allStakedFarms = farmsLP.filter(
    (farm) => farm.userData && new BigNumber(farm.userData.stakedBalance).isGreaterThan(0),
  )

  const farmsList = useCallback(
    (farmsToDisplay: DeserializedFarm[]): FarmWithStakedValue[] => {
      let farmsToDisplayWithAPR: FarmWithStakedValue[] = farmsToDisplay.map((farm) => {
        if (!farm.lpTotalInQuoteToken || !farm.quoteTokenPriceBusd) {
          return farm
        }
        const totalLiquidity = new BigNumber(farm.lpTotalInQuoteToken).times(farm.quoteTokenPriceBusd)
        const { nmxRewardsApr, lpRewardsApr } = isActive
          ? getFarmApr(
              new BigNumber(farm.tokensPerSec),
              new BigNumber(nmxPrice?.toFixed(2)),
              totalLiquidity,
              farm.lpAddresses[ChainId.MAINNET],
            )
          : { nmxRewardsApr: 0, lpRewardsApr: 0 }

        return { ...farm, apr: nmxRewardsApr, lpRewardsApr, liquidity: totalLiquidity }
      })

      if (query) {
        const lowercaseQuery = latinise(query.toLowerCase())
        farmsToDisplayWithAPR = farmsToDisplayWithAPR.filter((farm: FarmWithStakedValue) => {
          return latinise(farm.lpSymbol.toLowerCase()).includes(lowercaseQuery)
        })
      }
      return farmsToDisplayWithAPR
    },
    [nmxPrice, query, isActive],
  )

  const handleChangeQuery = (event: React.ChangeEvent<HTMLInputElement>) => {
    setQuery(event.target.value)
  }

  const [numberOfFarmsVisible, setNumberOfFarmsVisible] = useState(NUMBER_OF_FARMS_VISIBLE)

  const chosenFarmsMemoized = useMemo(() => {
    let chosenFarms = []

    const sortFarms = (farms: FarmWithStakedValue[]): FarmWithStakedValue[] => {
      switch (sortOption) {
        case 'apr':
          return orderBy(farms, (farm: FarmWithStakedValue) => farm.apr + farm.lpRewardsApr, 'desc')
        // case 'multiplier':
        //   return orderBy(
        //     farms,
        //     (farm: FarmWithStakedValue) => (farm.multiplier ? Number(farm.multiplier.slice(0, -1)) : 0),
        //     'desc',
        //   )
        case 'earned':
          return orderBy(
            farms,
            (farm: FarmWithStakedValue) => (farm.userData ? Number(farm.userData.earnings) : 0),
            'desc',
          )
        case 'liquidity':
          return orderBy(farms, (farm: FarmWithStakedValue) => Number(farm.liquidity), 'desc')
        default:
          return farms
      }
    }

    if (isActive) {
      chosenFarms = farmsList(activeFarms)
    }
    if (isInactive) {
      chosenFarms = farmsList(inactiveFarms)
    }
    if (isArchived) {
      chosenFarms = farmsList(archivedFarms)
    }
    if (showAllStaked) {
      chosenFarms = farmsList(allStakedFarms)
    }

    return sortFarms(chosenFarms).slice(0, numberOfFarmsVisible)
  }, [
    sortOption,
    activeFarms,
    farmsList,
    inactiveFarms,
    archivedFarms,
    isActive,
    isInactive,
    isArchived,
    showAllStaked,
    allStakedFarms,
    numberOfFarmsVisible,
  ])

  chosenFarmsLength.current = chosenFarmsMemoized.length

  useEffect(() => {
    if (isIntersecting) {
      setNumberOfFarmsVisible((farmsCurrentlyVisible) => {
        if (farmsCurrentlyVisible <= chosenFarmsLength.current) {
          return farmsCurrentlyVisible + NUMBER_OF_FARMS_VISIBLE
        }
        return farmsCurrentlyVisible
      })
    }
  }, [isIntersecting])

  const rowData = chosenFarmsMemoized.map((farm) => {
    const { token, quoteToken } = farm
    const tokenAddress = token.address
    const quoteTokenAddress = quoteToken.address
    const lpLabel = farm.lpSymbol && farm.lpSymbol.split(' ')[0].toUpperCase().replace('PANCAKE', '')

    const row: RowProps = {
      apr: {
        value: getDisplayApr(farm.apr, farm.lpRewardsApr),
        pid: farm.pid,
        multiplier: farm.multiplier,
        lpLabel,
        lpSymbol: farm.lpSymbol,
        tokenAddress,
        quoteTokenAddress,
        nmxPrice: new BigNumber(nmxPrice?.toFixed(2)),
        originalValue: farm.apr,
      },
      farm: {
        label: lpLabel,
        pid: farm.pid,
        token: farm.token,
        quoteToken: farm.quoteToken,
      },
      earned: {
        earnings: getBalanceNumber(new BigNumber(farm.userData.earnings)),
        pid: farm.pid,
      },
      liquidity: {
        liquidity: farm.liquidity,
      },
      // multiplier: {
      //   multiplier: farm.multiplier,
      // },
      details: farm,
    }

    return row
  })

  const renderContent = (): JSX.Element => {
    const columns = DesktopColumnSchema.map((column) => ({
      id: column.id,
      name: column.name,
      label: column.label,
      sort: (a: RowType<RowProps>, b: RowType<RowProps>) => {
        switch (column.name) {
          case 'farm':
            return b.id - a.id
          case 'apr':
            if (a.original.apr.value && b.original.apr.value) {
              return Number(a.original.apr.value) - Number(b.original.apr.value)
            }

            return 0
          case 'earned':
            return a.original.earned.earnings - b.original.earned.earnings
          default:
            return 1
        }
      },
      sortable: column.sortable,
    }))

    return <FarmTable data={rowData} columns={columns} userDataReady={userDataReady} />
  }

  const handleSortOptionChange = (option: OptionProps): void => {
    setSortOption(option.value)
  }

  return (
    <>
      <Page>
        <ExtendedAppTitle
          title={t('Farms')}
          subtitle={t(
            'Nomiswap farms offer multiple farming opportunities to you. Increase your farming rewards participating in Team Farming program and continuously grow your extra bonuses for unstoppable farming up to 10x.',
          )}
          titleProps={{ maxWidth: '532px' }}
          mb="24px"
        >
          <StakingBanner />
        </ExtendedAppTitle>
        <Wrapper>
          <ExtraRewardCard />

          <Flex flexDirection="column">
            <ControlContainer>
              <ViewControls>
                <FarmTabButtons />
              </ViewControls>

              <FilterContainer>
                <LabelWrapper>
                  <Text textTransform="uppercase">{t('Sort by')}</Text>
                  <Select
                    options={[
                      {
                        label: t('Hot'),
                        value: 'hot',
                      },
                      {
                        label: t('APR'),
                        value: 'apr',
                      },
                      // {
                      //   label: t('Multiplier'),
                      //   value: 'multiplier',
                      // },
                      {
                        label: t('Earned'),
                        value: 'earned',
                      },
                      {
                        label: t('Liquidity'),
                        value: 'liquidity',
                      },
                    ]}
                    onOptionChange={handleSortOptionChange}
                  />
                </LabelWrapper>
                <LabelWrapper style={{ marginLeft: 16 }}>
                  <Text textTransform="uppercase">{t('Search')}</Text>
                  <SearchInput onChange={handleChangeQuery} placeholder={t('Search Farms')} />
                </LabelWrapper>
              </FilterContainer>
            </ControlContainer>
            {/* <PoolsSummaryCard /> */}
            {renderContent()}
          </Flex>
        </Wrapper>
        {/* {account && !userDataLoaded && (
          <Flex justifyContent="center">
            <Loading />
          </Flex>
        )} */}
        <div ref={observerRef} />
      </Page>
    </>
  )
}

export default Farms
