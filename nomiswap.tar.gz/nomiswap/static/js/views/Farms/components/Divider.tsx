import styled from 'styled-components'

export default styled.div`
  border-top: 2px dashed ${({ theme }) => theme.colors.blue500};
  margin: 20px 0;
  opacity: 0.5;
  width: 100%;
`
