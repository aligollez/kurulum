import React from 'react'
import styled from 'styled-components'
import { Text, Box, Card, Tag } from '@nominex/dex-uikit'
import { useTranslation } from 'contexts/Localization'
import Divider from './Divider'

const StickyWrapper = styled.div`
  @media screen and (min-width: 1400px) {
    position: sticky;
    top: 0;
    left: 0;
  }
`

const ExtraRewardCard: React.FC<React.HTMLAttributes<any>> = ({ ...rest }) => {
  const { t } = useTranslation()
  // const currentLevel = 5850
  // const maxLevel = 10000
  // const progress = (currentLevel / maxLevel) * 100

  return (
    <StickyWrapper {...rest}>
      <Card background="linear-gradient(167.09deg, #3E56FF 1.17%, #061BDA 97.46%)" p={0}>
        <Box p="32px">
          <Text fontSize="20px" fontWeight="500" mb="10px">
            {t('Nomiswap extra rewards')}
          </Text>
          <Text fontSize="14px" style={{ opacity: 0.5 }}>
            {t('NMX token and its farming/staking is utilitarian and gives unique rewards.')}
          </Text>

          <Divider />
          <Tag variant="success">Soon</Tag>

          {/* <Flex justifyContent="space-between" mb="20px">
            <Text fontSize="14px">{t('Farming level')}</Text>
            <Text fontSize="14px" fontWeight="600">
              👨🏻‍ Starter
            </Text>
          </Flex>

          <Text fontSize="12px" fontWeight="600">
            {t('Your farm ')}
            {`$${currentLevel} / $${maxLevel}`}
          </Text>

          <Box my="10px">
            <Progress primaryStep={progress} />
          </Box>

          <Text fontSize="12px">{t('Put $10,000 in NMX pools and get maximum bonuses.')}</Text>

          <Button scale="md" width="100%" mt="20px">
            {t('Go to Extra Rewards')}
          </Button> */}
        </Box>
      </Card>
    </StickyWrapper>
  )
}

export default ExtraRewardCard
