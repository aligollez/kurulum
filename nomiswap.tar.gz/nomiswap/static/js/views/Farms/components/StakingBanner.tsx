import React from 'react'
import { Button, Card, Flex, Skeleton, Tag, Text } from '@nominex/dex-uikit'
import { Link } from 'react-router-dom'
import { useFetchPublicPoolsData, usePool } from 'state/pools/hooks'
import Balance from 'components/Balance'
import styled from 'styled-components'

const ButtonWrapper = styled(Flex)`
  background-size: cover;
  background-image: url(/images/farming/stakeBanner.png);
  align-self: stretch;
  padding-right: 20px;
  padding-left: 20px;
  align-items: center;
`

const AprTag = styled(Tag)`
  display: inline-flex;
  background-image: linear-gradient(92deg, #44b0fe 12%, #c316ff 95%);
`

export const StakingBanner = () => {
  // TODO: Надо сделать возможность подгрузки единственного пула. Сейчас загружаются все пулы. Но нужен только один
  useFetchPublicPoolsData()
  const { pool } = usePool(0)

  return (
    <Card withoutBorder background="linear-gradient(109deg, #783BFF 34%, #410BB9 100%)">
      <Flex alignItems="center">
        <Flex py="20px" pl="20px" flexDirection="column">
          <Text fontSize="18px" semibold>
            Earn more NMX in Launchpool
          </Text>
          <Flex alignItems="center">
            <Text fontSize="14px">
              Stake your NMX with{' '}
              <AprTag fontSize="14px" fontWeight={600}>
                APR
                {pool?.apr ? (
                  <Balance color="white" ml="6px" value={pool.apr} decimals={0} unit="%" fontWeight={600} />
                ) : (
                  <Skeleton width="30px" height="18px" m="3px" />
                )}
              </AprTag>
            </Text>
          </Flex>
        </Flex>
        <ButtonWrapper>
          <Button style={{ whiteSpace: 'nowrap' }} scale="sm" as={Link} to="/pools">
            Stake now
          </Button>
        </ButtonWrapper>
      </Flex>
    </Card>
  )
}
