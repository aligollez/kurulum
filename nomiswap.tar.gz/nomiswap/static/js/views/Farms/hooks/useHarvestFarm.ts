import { useCallback } from 'react'
import { harvestFarm } from 'utils/calls'
import { useStakingService } from 'hooks/useContract'
import { DeserializedFarm } from 'state/types'

const useHarvestFarm = (farm: DeserializedFarm) => {
  const stakingService = useStakingService(farm.contractAddresses)

  const handleHarvest = useCallback(async () => {
    await harvestFarm(stakingService)
  }, [stakingService])

  return { onReward: handleHarvest }
}

export default useHarvestFarm
