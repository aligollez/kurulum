import { useCallback } from 'react'
import { unstakeFarm } from 'utils/calls'
import { useStakingService } from 'hooks/useContract'
import { DeserializedFarm } from 'state/types'

const useUnstakeFarms = (farm: DeserializedFarm) => {
  const stakingServiceContract = useStakingService(farm.contractAddresses)

  const handleUnstake = useCallback(
    async (amount: string) => {
      await unstakeFarm(stakingServiceContract, amount)
    },
    [stakingServiceContract],
  )

  return { onUnstake: handleUnstake }
}

export default useUnstakeFarms
