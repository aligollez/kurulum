import { useCallback } from 'react'
import { stakeFarm } from 'utils/calls'
import { DeserializedFarm } from 'state/types'
import { useStakingService } from 'hooks/useContract'

const useStakeFarms = (farm: DeserializedFarm) => {
  const stakingServiceContract = useStakingService(farm.contractAddresses)

  const handleStake = useCallback(
    async (amount: string) => {
      const txHash = await stakeFarm(stakingServiceContract, amount)
      console.info(txHash)
    },
    [stakingServiceContract],
  )

  return { onStake: handleStake }
}

export default useStakeFarms
