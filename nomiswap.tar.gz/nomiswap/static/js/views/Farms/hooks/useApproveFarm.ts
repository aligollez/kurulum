import { useCallback } from 'react'
import { ethers } from 'ethers'
import { useERC20 } from 'hooks/useContract'
import { useCallWithGasPrice } from 'hooks/useCallWithGasPrice'
import { DeserializedFarm } from 'state/types'
import { getAddress } from 'utils/addressHelpers'

const useApproveFarm = (farm: DeserializedFarm) => {
  const { callWithGasPrice } = useCallWithGasPrice()
  const lpAddress = getAddress(farm.lpAddresses)
  const serviceAddress = getAddress(farm.contractAddresses)
  const lpContract = useERC20(lpAddress)

  const handleApprove = useCallback(async () => {
    const tx = await callWithGasPrice(lpContract, 'approve', [serviceAddress, ethers.constants.MaxUint256])
    const receipt = await tx.wait()
    return receipt.status
  }, [lpContract, callWithGasPrice, serviceAddress])

  return { onApprove: handleApprove }
}

export default useApproveFarm
