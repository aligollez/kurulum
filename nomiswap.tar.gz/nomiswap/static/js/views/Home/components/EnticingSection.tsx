import React from 'react'
import { Link } from 'react-router-dom'
import { Button, Flex, Text, Heading, BackgroundImage, BoxProps, useMatchBreakpoints } from '@nominex/dex-uikit'
import styled from 'styled-components'

interface EnticingSectionProps extends BoxProps {
  label: string | React.ReactNode | React.ReactElement
  description: string
  reverseDirection?: boolean
  src: string
  linkText: string
  linkHref: string
}

const EnticingWrapper = styled(Flex)<{ reverseDirection?: boolean }>`
  flex-direction: ${({ reverseDirection }) => (reverseDirection ? 'row-reverse' : 'row')};
  & > * {
    width: 50%;

    @media (max-width: 768px) {
      width: 100%;
    }
  }

  @media (max-width: 768px) {
    flex-direction: column-reverse;
  }
`

const EnticingImage = styled(BackgroundImage)<{ reverseDirection?: boolean }>`
  background-size: contain;
  background-repeat: no-repeat;
  background-position: ${({ reverseDirection }) => (reverseDirection ? 'left' : 'right')} center;

  flex-grow: 1;

  min-width: initial;
  min-height: initial;
  width: 100%;

  @media (max-width: 768px) {
    max-width: 100%;
  }
`

export const EnticingSection: React.FC<EnticingSectionProps> = ({
  description,
  label,
  linkHref,
  linkText,
  reverseDirection,
  src,
}) => {
  const { isMobile } = useMatchBreakpoints()

  return (
    <EnticingWrapper reverseDirection={reverseDirection}>
      <Flex
        position="relative"
        zIndex={1}
        flexDirection="column"
        alignItems="start"
        justifyContent="center"
        flexGrow={1}
        mr={[0, '28px']}
        mt="48px"
      >
        <Heading mb="24px" scale="xxl" bold style={{ fontSize: isMobile ? '32px' : '48px' }}>
          {label}
        </Heading>
        <Text mb="24px" style={{ opacity: 0.6 }}>
          {description}
        </Text>
        <Button as={Link} to={linkHref} variant="primary" scale="lg" width={isMobile ? '100%' : 'auto'}>
          {linkText}
        </Button>
      </Flex>
      <EnticingImage reverseDirection={reverseDirection} width={616} height={616} src={src} />
    </EnticingWrapper>
  )
}
