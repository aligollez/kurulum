import React from 'react'
import {
  BoxProps,
  SvgProps,
  Flex,
  Text,
  Heading,
  DirectBonusIcon,
  ReferralIcon,
  EarnFillIcon,
  TuneIcon,
  useMatchBreakpoints,
} from '@nominex/dex-uikit'
import { CircleIconWrapper } from './CircleIconWrapper'
import { SectionWrapper } from './SectionWrapper'

interface BenefitItemProp extends BoxProps {
  iconBackground: string
  iconShadow?: string
  children: React.ReactElement<SvgProps>
  label: string
  description: string
}

export const BenefitItem: React.FC<BenefitItemProp> = ({
  iconBackground,
  iconShadow,
  children,
  label,
  description,
  ...props
}) => (
  <Flex flexDirection="column" maxWidth="285px" mb="28px" {...props}>
    <CircleIconWrapper background={iconBackground} boxShadow={iconShadow} mb="24px">
      {children}
    </CircleIconWrapper>

    <Text mb="10px" color="white" fontSize="28px" bold>
      {label}
    </Text>
    <Text color="darkGray100" fontSize="14px">
      {description}
    </Text>
  </Flex>
)

export const Benefits: React.FC<BoxProps> = (props) => {
  const { isMobile } = useMatchBreakpoints()
  return (
    <SectionWrapper justifyContent="start" alignItems="start" flexDirection="column" position="relative" {...props}>
      <Heading scale="xxl" mt="12px" mb="28px" style={{ fontSize: isMobile ? '32px' : '48px' }}>
        Our Benefits
      </Heading>
      <Flex flexGrow={1} flexWrap="wrap" justifyContent="space-between" width="100%">
        <BenefitItem
          iconBackground="radial-gradient(98% 89% at 91% 45%, #0050AE 0%, #4B7CFA 72%, #DEFFFB 90%)"
          iconShadow="0px 0px 135px #2D6BDC"
          label="Utilitarian farming/staking"
          description="The more you put in liquidity/staking pools - the more your trading fees cashback and referral rewards"
        >
          <DirectBonusIcon />
        </BenefitItem>

        <BenefitItem
          iconBackground="radial-gradient(98% 89% at 91% 45%, #563EE6 0%, #826EFE 72%, #DEFFFB 90%)"
          iconShadow="0px 0px 135px #7E69FC"
          label="Binary referral system"
          description="You earn from 100 000 referral levels below you in your referral structure but not only from your own friends."
        >
          <ReferralIcon />
        </BenefitItem>

        <BenefitItem
          iconBackground="radial-gradient(98% 89% at 91% 45%, #E47F22 0%, #F3893C 72%, #DEFFFB 90%)"
          iconShadow="0px 0px 135px #F3893A"
          label="Referral rewards for every action"
          description="Invite your friends and earn a high reward every time they make a swap on Nomiswap and up to 40% from their income in Farms & Launchpools."
        >
          <EarnFillIcon />
        </BenefitItem>

        <BenefitItem
          iconBackground="radial-gradient(98% 89% at 91% 45%, #ED50DD 0%, #C76EFE 72%, #DEFFFB 90%)"
          iconShadow="0px 0px 135px #EA53E0"
          label="Trading fee cashback"
          description="Make a swap on Nomiswap at no cost. Up to 100% of the trading fee returned in NMX tokens."
        >
          <TuneIcon />
        </BenefitItem>
      </Flex>
    </SectionWrapper>
  )
}
