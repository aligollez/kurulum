import styled from 'styled-components'
import { Flex } from '@nominex/dex-uikit'

export const SectionWrapper = styled(Flex)`
  background: ${({ background }) => background ?? '#091225'};
  padding-left: 16px;
  padding-right: 16px;

  ${({ theme }) => theme.mediaQueries.md} {
    padding-left: 52px;
    padding-right: 52px;
  }
`
