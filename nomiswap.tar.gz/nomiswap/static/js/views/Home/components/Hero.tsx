import React from 'react'
import styled from 'styled-components'
import { Flex, Box, Heading, Text, Image, BoxProps, TuneIcon, Svg, useMatchBreakpoints } from '@nominex/dex-uikit'
import { GradientText } from './GradientText'
import { SectionWrapper } from './SectionWrapper'
import { CircleIconWrapper } from './CircleIconWrapper'

const StyledHero = styled.div`
  &:after {
    content: '';
    position: absolute;
    width: 100%;
    max-width: 1514px;
    height: 1010px;
    background-image: url('/images/home/hero-bg.jpg');
    background-position: center top;
    background-repeat: no-repeat;
    background-size: contain;
    right: 0px;
    top: -56px;
  }
`

interface HeroInformerProps extends BoxProps {
  label: string
  description: string
  iconBackground: string
  children: React.ReactElement<any>
  isMobile: boolean
}

const HeroInformer: React.FC<HeroInformerProps> = ({
  label,
  description,
  iconBackground,
  children,
  isMobile,
  ...props
}) => (
  <Flex {...props}>
    <CircleIconWrapper background={iconBackground} mr="28px">
      {children}
    </CircleIconWrapper>

    <Box>
      <Text fontSize={isMobile ? '32px' : '70px'} lineHeight="0.8" mb="20px" bold>
        {label}
      </Text>
      <Text fontSize={isMobile ? '14px' : '18px'}>{description}</Text>
    </Box>
  </Flex>
)

const Hero = () => {
  const { isMobile } = useMatchBreakpoints()

  return (
    <StyledHero>
      <SectionWrapper
        background="transparent"
        pb="64px"
        position="relative"
        justifyContent="start"
        alignItems="start"
        flexDirection="column"
        flexGrow={1}
      >
        <Flex
          position="relative"
          zIndex={1}
          justifyContent="start"
          alignItems="start"
          flexDirection="column"
          mt="90px"
          mb="140px"
          width="100%"
          maxWidth="640px"
        >
          <Heading as="h1" scale="xxl" mb="16px" style={{ fontSize: isMobile ? '36px' : '48px' }}>
            First DEX in DeFi space with <GradientText>0% swap fees</GradientText> and team farming
          </Heading>
          <Text fontSize="20px" color="darkGray100" mb="32px" maxWidth="555px">
            Enjoy the highest farming/trading rewards from unlimited referral levels!
          </Text>

          <a
            style={{ display: 'block', width: '100%', minWidth: '280px', maxWidth: '449px' }}
            href="https://nominex.io?utm_source=nomiswap"
            target="_blank"
            rel="noopener noreferrer"
          >
            <Image
              src="/images/home/backed-by-nmx.png"
              width={449}
              height={64}
              style={{ width: '100%', minWidth: '280px', maxWidth: '449px', minHeight: 0 }}
            />
          </a>

          {/* <Link to="/swap">
            <Button scale="lg" px="38px">
              Swap now!
            </Button>
          </Link> */}
        </Flex>

        <Flex flexWrap="wrap" position="relative" zIndex={1}>
          <HeroInformer
            iconBackground="linear-gradient(128deg, #F11471 -2%, #6A0FFF 92%)"
            label="0.1%"
            description="Lowest Trade Fee in the DeFi Space"
            mr="64px"
            mb="64px"
            isMobile={isMobile}
          >
            <Svg viewBox="0 0 24 24">
              <path
                d="M22.865 8.19713L21.657 6.57144L20.9853 11.3171C20.9238 11.7518 20.7205 12.1623 20.4127 12.4729L12.1418 20.821C11.4204 21.5492 10.4601 21.9503 9.43784 21.9503C9.13232 21.9503 8.83257 21.9137 8.54285 21.8441C8.98283 22.5384 9.75289 23 10.6283 23H20.5257C21.89 23 23 21.8797 23 20.5026V8.60579C23 8.45845 22.9526 8.31505 22.865 8.19713Z"
                fill="white"
              />
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M19.2346 11.4958L11.073 19.6574C10.597 20.1335 9.97172 20.3714 9.34648 20.3714C8.72124 20.3714 8.09596 20.1335 7.61998 19.6574L0.714012 12.7514C-0.238004 11.7995 -0.238004 10.2504 0.714012 9.29842L8.87565 1.13674C8.97753 1.03486 9.10969 0.96876 9.25232 0.948383L15.8445 0.0066169C16.052 -0.0227717 16.2613 0.0467487 16.4095 0.194979L17.8221 1.60758L15.9387 3.49107L15.4678 3.02019C15.2077 2.76017 14.7861 2.76017 14.5261 3.02019C14.266 3.28025 14.266 3.7019 14.5261 3.96191L16.4096 5.8454C16.5395 5.97543 16.71 6.04046 16.8804 6.04046C17.0508 6.04046 17.2212 5.97543 17.3512 5.8454C17.6113 5.58534 17.6113 5.16369 17.3512 4.90368L16.8803 4.43279L18.7638 2.5493L20.1764 3.96191C20.3246 4.1101 20.3944 4.31946 20.3647 4.52695L19.423 11.1191C19.4026 11.2617 19.3365 11.3939 19.2346 11.4958ZM15.7389 10.3971C15.7389 9.2956 14.8428 8.39943 13.7412 8.39943C12.6397 8.39943 11.7435 9.2956 11.7435 10.3971C11.7435 11.4987 12.6397 12.3949 13.7412 12.3949C14.8428 12.3949 15.7389 11.4987 15.7389 10.3971ZM6.20752 12.3949C5.10599 12.3949 4.20982 11.4987 4.20982 10.3971C4.20982 9.2956 5.10599 8.39943 6.20752 8.39943C7.30906 8.39943 8.20522 9.2956 8.20522 10.3971C8.20522 11.4987 7.3091 12.3949 6.20752 12.3949ZM8.19425 15.7374C8.26408 15.7607 8.33511 15.7718 8.4049 15.7718C8.68369 15.7718 8.94353 15.5952 9.03657 15.3163L12.1756 5.89893C12.2919 5.54999 12.1034 5.17292 11.7545 5.0566C11.4056 4.94034 11.0285 5.12888 10.9121 5.47777L7.77309 14.8951C7.65683 15.244 7.84537 15.6211 8.19425 15.7374Z"
              />
            </Svg>
          </HeroInformer>

          <HeroInformer
            iconBackground="linear-gradient(106deg, #27A17C 0%, #187659 100%)"
            label="Up to 100%"
            description="Exchange Fee Cashback"
            mb="64px"
            isMobile={isMobile}
          >
            <TuneIcon />
          </HeroInformer>
        </Flex>
      </SectionWrapper>
    </StyledHero>
  )
}

export default Hero
