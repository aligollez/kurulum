import React, { cloneElement } from 'react'
import { BoxProps, Flex, SvgProps } from '@nominex/dex-uikit'

interface CircleIconWrapperProps extends BoxProps {
  children: React.ReactElement<SvgProps>
  boxShadow?: string
  size?: number
}

export const CircleIconWrapper: React.FC<CircleIconWrapperProps> = ({
  children,
  background,
  boxShadow,
  size = 64,
  ...props
}) => (
  <Flex
    {...props}
    width={`${size}px`}
    height={`${size}px`}
    justifyContent="center"
    alignItems="center"
    background={background}
    borderRadius="50%"
    style={{ boxShadow }}
    flexShrink={0}
  >
    {children && cloneElement(children, { width: `${0.375 * size}px`, height: `${0.375 * size}px` })}
  </Flex>
)
