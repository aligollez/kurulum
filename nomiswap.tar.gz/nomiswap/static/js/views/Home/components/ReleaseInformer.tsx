import React from 'react'
import { Flex, Box, Text, Heading, TelegramIcon, TwitterIcon, useMatchBreakpoints } from '@nominex/dex-uikit'
import styled from 'styled-components'

const StyledReleaseInformer = styled.div<{ background: string }>`
  background: ${({ background }) => background};
  border-radius: 12px;
  position: relative;
  overflow: hidden;
  width: 100%;

  &:after {
    content: '';
    position: absolute;
    width: 100%;
    max-width: 575px;
    height: 100%;
    background-image: url('/images/home/release-informer-cover.png');
    background-position: center top;
    background-repeat: no-repeat;
    background-size: cover;
    right: 0px;
    top: 0px;
    z-index: 0;
  }
`

const ReleaseDateBadgeStyled = styled.span`
  color: #ffffff;
  background: linear-gradient(91.24deg, #44b0fe 11.86%, #c316ff 94.43%);
  border-radius: 46px;
  padding: 2px 12px;
  white-space: nowrap;
`

const SocialLinkBadgeStyled = styled.a`
  color: #ffffff;
  margin: 6px;
  display: inline-flex;
  align-items: center;
  background: linear-gradient(108.82deg, #44b0fe 33.45%, #1681ff 99.53%);
  border-radius: 46px;
  font-weight: 500;
  font-size: 18px;
  line-height: 1;
  padding: 16px;
  height: 48px;
`

export const ReleaseInformer = ({ background }) => {
  const { isMobile } = useMatchBreakpoints()

  return (
    <StyledReleaseInformer background={background}>
      <Flex
        px={isMobile ? '24px' : '40px'}
        py="44px"
        flexWrap="wrap"
        justifyContent="stretch"
        style={{ width: '100%' }}
      >
        <Flex flexGrow={1} flexDirection="column" py="14px" style={{ zIndex: 1 }}>
          <Box style={{ maxWidth: '538px' }}>
            <Heading scale={isMobile ? 'lg' : 'xl'} mb="12px" style={{ lineHeight: isMobile ? '42px' : '52px' }}>
              New Nomiswap DEX started on <ReleaseDateBadgeStyled>30 December 2021</ReleaseDateBadgeStyled>
            </Heading>
            <Text fontSize={isMobile ? '18px' : '24px'} lineHeight="34px">
              Join our news channels and do not miss the highest APR at the first times.
            </Text>
          </Box>
        </Flex>
        <Flex flexWrap="wrap" alignItems="center" py="14px" style={{ zIndex: 1 }}>
          <SocialLinkBadgeStyled href="https://t.me/nomiswap_news2" target="_blank" rel="noopener">
            <TelegramIcon color="white" mr="8px" />
            Telegram channel
          </SocialLinkBadgeStyled>
          <SocialLinkBadgeStyled href="https://t.me/nomi_swap" target="_blank" rel="noopener">
            <TelegramIcon color="white" mr="8px" />
            Telegram chat
          </SocialLinkBadgeStyled>
          <SocialLinkBadgeStyled href="https://twitter.com/Nomiswap" target="_blank" rel="noopener">
            <TwitterIcon color="white" mr="8px" />
            Twitter
          </SocialLinkBadgeStyled>
        </Flex>
      </Flex>
    </StyledReleaseInformer>
  )
}
