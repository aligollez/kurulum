import React from 'react'
import { Flex, Box } from '@nominex/dex-uikit'
import { PageMeta } from 'components/Layout/Page'
import Hero from './components/Hero'
import { SectionWrapper } from './components/SectionWrapper'
import { Benefits } from './components/Benefits'
import { GradientText } from './components/GradientText'
import { EnticingSection } from './components/EnticingSection'
import { ReleaseInformer } from './components/ReleaseInformer'

const Home: React.FC = () => {
  return (
    <Flex background="#091225">
      <Box maxWidth="1500px" mx="auto">
        <PageMeta />
        <Hero />

        <SectionWrapper mb="76px">
          <ReleaseInformer background="linear-gradient(91.24deg, #1859FF 11.86%, #C316FF 94.43%)" />
        </SectionWrapper>

        <Benefits pb="120px" />

        <SectionWrapper flexDirection="column">
          <EnticingSection
            label={
              <>
                Already getting <GradientText>maximum</GradientText> profits to your farming level?
              </>
            }
            description="Receive automatically the same maximum benefits on Nominex CEX (centralized exchange). Nominex is the official Binance broker with highest liquidity and at the same time ZERO fees trading."
            src="/images/home/comet-nmx.jpg"
            linkText="Start Farming!"
            linkHref="/farms"
          />
          <EnticingSection
            reverseDirection
            label={
              <>
                Trade anything. No registration, <GradientText>no hassle</GradientText>
              </>
            }
            description="Trade any token on Binance Smart Chain in seconds, just by connecting your wallet."
            src="/images/home/trade-widget.jpg"
            linkText="Trade now"
            linkHref="/swap"
          />
          <EnticingSection
            label={
              <>
                <GradientText>NMX</GradientText> makes our world go round
              </>
            }
            description="Trade any token on Binance Smart Chain in seconds, just by connecting your wallet."
            src="/images/home/bsc-nmx.jpg"
            linkText="Buy NMX"
            linkHref="/swap?outputCurrency=0xd32d01A43c869EdcD1117C640fBDcfCFD97d9d65"
          />
        </SectionWrapper>

        <SectionWrapper mt="48px" mb="76px">
          <ReleaseInformer background="linear-gradient(128.65deg, #F11471 -2.22%, #6A0FFF 91.69%)" />
        </SectionWrapper>
      </Box>
    </Flex>
  )
}

export default Home
