import React from 'react'
import { SpaceProps } from 'styled-system'
import { TokenPairImage } from '@nominex/dex-uikit'
import { mainnetTokens } from 'config/constants/tokens'

interface CakeVaultTokenPairImageProps extends SpaceProps {
  size: number
}

const CakeVaultTokenPairImage: React.FC<CakeVaultTokenPairImageProps> = (props) => {
  // TODO: add nmx-autorenew icon
  return <TokenPairImage primarySymbol={mainnetTokens.nmx.symbol} secondarySymbol="nmx-autorenew" {...props} />
}

export default CakeVaultTokenPairImage
