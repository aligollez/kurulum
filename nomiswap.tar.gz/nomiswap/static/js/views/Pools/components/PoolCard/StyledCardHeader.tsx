import React from 'react'
import BigNumber from 'bignumber.js'
import { Token } from '@nominex/nomiswap-sdk'
import { CardHeader, Heading, Text, Flex, TokenPairImage } from '@nominex/dex-uikit'
import styled from 'styled-components'
import { useTranslation } from 'contexts/Localization'
import { DeserializedPool } from 'state/types'
import CakeVaultTokenPairImage from '../CakeVaultCard/CakeVaultTokenPairImage'
import AprRow from './AprRow'

const Wrapper = styled(CardHeader)<{ isFinished?: boolean; background?: string }>`
  background: ${({ theme }) => theme.colors.darkGray800};
  border-radius: ${({ theme }) => `${theme.radii.card} ${theme.radii.card} 0 0`};
`

interface StyledCardHeaderProps {
  earningToken: Token
  stakingToken: Token
  pool?: DeserializedPool
  stakedBalance?: BigNumber
  isAutoVault?: boolean
  isFinished?: boolean
  isStaking?: boolean
  performanceFee?: number
}

const StyledCardHeader: React.FC<StyledCardHeaderProps> = ({
  earningToken,
  stakingToken,
  pool,
  stakedBalance,
  isFinished = false,
  isAutoVault = false,
  isStaking = false,
  performanceFee,
}) => {
  const { t } = useTranslation()
  const isCakePool = earningToken.symbol === 'NMX' && stakingToken.symbol === 'NMX'
  const background = isStaking ? 'bubblegum' : 'cardHeader'

  const getHeadingPrefix = () => {
    if (isAutoVault) {
      // vault
      return t('Auto')
    }
    if (isCakePool) {
      // manual cake
      return t('Manual')
    }
    // all other pools
    return t('Earn')
  }

  const getSubHeading = () => {
    if (isAutoVault) {
      return t('Automatic restaking')
    }
    if (isCakePool) {
      return t('Earn NMX, stake NMX')
    }
    return t('Stake %symbol%', { symbol: stakingToken.symbol })
  }

  return (
    <Wrapper isFinished={isFinished} background={background}>
      <Flex alignItems="center">
        {isAutoVault ? (
          <CakeVaultTokenPairImage size={64} />
        ) : (
          <TokenPairImage primarySymbol={earningToken.symbol} secondarySymbol={stakingToken.symbol} size={64} />
        )}
        <Flex flexDirection="column" ml="12px">
          <Heading color="white" scale="sm">
            {`${getHeadingPrefix()} ${earningToken.symbol}`}
          </Heading>
          <Text color="darkGray100" fontSize="12px">
            {getSubHeading()}
          </Text>
          <AprRow pool={pool} stakedBalance={stakedBalance} performanceFee={performanceFee} />
        </Flex>
      </Flex>
    </Wrapper>
  )
}

export default StyledCardHeader
