import { useCallback } from 'react'
import { useWeb3React } from '@web3-react/core'
import { useAppDispatch } from 'state'
import { updateUserStakedBalance, updateUserBalance } from 'state/actions'
import { stakeFarm } from 'utils/calls'
import { useStakingService } from 'hooks/useContract'
import { DeserializedPool } from 'state/types'

const useStakePool = (pool: DeserializedPool) => {
  const dispatch = useAppDispatch()
  const { account } = useWeb3React()
  const stakingServiceContract = useStakingService(pool.contractAddresses)

  const handleStake = useCallback(
    async (amount: string, decimals: number) => {
      await stakeFarm(stakingServiceContract, amount, decimals)

      dispatch(updateUserStakedBalance(pool.sousId, account))
      dispatch(updateUserBalance(pool.sousId, account))
    },
    [account, dispatch, stakingServiceContract, pool],
  )

  return { onStake: handleStake }
}

export default useStakePool
