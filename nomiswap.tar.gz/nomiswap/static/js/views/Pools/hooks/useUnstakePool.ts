import { useCallback } from 'react'
import { useWeb3React } from '@web3-react/core'
import { useAppDispatch } from 'state'
import { updateUserStakedBalance, updateUserBalance, updateUserPendingReward } from 'state/actions'
import { unstakeFarm } from 'utils/calls'
import { useStakingService } from 'hooks/useContract'
import { DeserializedPool } from 'state/types'

const useUnstakePool = (pool: DeserializedPool) => {
  const dispatch = useAppDispatch()
  const { account } = useWeb3React()
  const stakingServiceContract = useStakingService(pool.contractAddresses)

  const handleUnstake = useCallback(
    async (amount: string, decimals: number) => {
      await unstakeFarm(stakingServiceContract, amount, decimals)

      dispatch(updateUserStakedBalance(pool.sousId, account))
      dispatch(updateUserBalance(pool.sousId, account))
      dispatch(updateUserPendingReward(pool.sousId, account))
    },
    [account, dispatch, pool, stakingServiceContract],
  )

  return { onUnstake: handleUnstake }
}

export default useUnstakePool
