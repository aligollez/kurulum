import React, { useState, useEffect, isValidElement, cloneElement } from 'react'
import styled, { keyframes, css } from 'styled-components'

const rotate = keyframes`
  from {
    transform: rotate(0deg);
  }

  to {
    transform: rotate(360deg);
  }
`

const rotateAnimation = css`
  animation: ${rotate} 0.6s cubic-bezier(0.59, -0.45, 0.31, 1.46);
`

const SwitchPairWrapper = styled.div`
  position: relative;
  z-index: 10;
  height: 16px;
  width: 38px;
`

const SwitchPairTrigger = styled.button<{ clicked: boolean; clickable: boolean }>`
  position: absolute;
  left: 0;
  top: -11px;
  border: 3px solid;
  border-color: ${({ theme }) => theme.colors.backgroundAlt};
  width: 38px;
  height: 38px;
  display: flex;
  justify-content: center;
  align-items: center;
  background: ${({ theme }) => theme.colors.gradients.accent};
  border-radius: 19px;
  cursor: ${({ clickable }) => clickable && 'pointer'};

  & > * {
    ${({ clicked, clickable }) => clickable && clicked && rotateAnimation};
    fill: ${({ theme }) => theme.colors.placeholder};
  }

  & path {
    transition: fill 0.2s ease;
  }

  &:hover > * {
    fill: ${({ clickable, theme }) => clickable && theme.colors.text};
  }
`

interface SwitchPairProps {
  children: React.ReactNode
  clickable?: boolean
  onClick?: () => any
}

export default function SwitchPair({ children, clickable, onClick }: SwitchPairProps) {
  const [clicked, setstate] = useState(false)

  useEffect(() => {
    let timer: NodeJS.Timeout | undefined

    if (clicked) {
      timer = setTimeout(() => {
        setstate(false)
      }, 600)
    } else {
      timer = undefined
    }

    return () => timer && clearTimeout(timer)
  })

  return (
    <SwitchPairWrapper>
      <SwitchPairTrigger
        onClick={() => {
          if (onClick) {
            setstate(true)
            onClick()
          }
        }}
        clicked={clicked}
        clickable={clickable}
      >
        {isValidElement(children) &&
          cloneElement(children, {
            color: 'currentColor',
          })}
      </SwitchPairTrigger>
    </SwitchPairWrapper>
  )
}
