import React, { isValidElement, cloneElement, HTMLAttributes } from 'react'
import styled from 'styled-components'

const StyledExpertModeButton = styled.button`
  border: 3px solid;
  border-color: ${({ theme }) => theme.colors.backgroundAlt};
  padding-right: 8px;
  height: 38px;
  display: flex;
  justify-content: center;
  align-items: center;
  background: ${({ theme }) => theme.colors.gradients.accent};
  border-radius: 19px;
  cursor: pointer;
  color: ${({ theme }) => theme.colors.placeholder};
  font-weight: 600;

  &:hover {
    color: ${({ theme }) => theme.colors.text};
  }

  & > * {
    fill: ${({ theme }) => theme.colors.placeholder};
  }

  &:hover > * {
    fill: ${({ theme }) => theme.colors.text};
  }
`

interface ExpertModeProps extends HTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode
  text?: string
  onClick?: () => any
}

export default function ExpertModeButton({ children, text, onClick, ...rest }: ExpertModeProps) {
  return (
    <StyledExpertModeButton
      onClick={() => {
        if (onClick) {
          onClick()
        }
      }}
      {...rest}
    >
      {isValidElement(children) &&
        cloneElement(children, {
          color: 'currentColor',
        })}
      {text}
    </StyledExpertModeButton>
  )
}
