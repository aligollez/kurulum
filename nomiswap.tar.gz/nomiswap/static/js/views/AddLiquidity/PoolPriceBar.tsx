import React from 'react'
import { Currency, Percent, Price } from '@nominex/nomiswap-sdk'
import { Text, Box } from '@nominex/dex-uikit'
import { useTranslation } from 'contexts/Localization'
import { AutoColumn } from '../../components/Layout/Column'
import { AutoRow, RowBetween } from '../../components/Layout/Row'
import { ONE_BIPS } from '../../config/constants'
import { Field } from '../../state/mint/actions'

function PoolPriceBar({
  currencies,
  noLiquidity,
  poolTokenPercentage,
  price,
}: {
  currencies: { [field in Field]?: Currency }
  noLiquidity?: boolean
  poolTokenPercentage?: Percent
  price?: Price
}) {
  const { t } = useTranslation()
  return (
    <Box borderRadius="12px" background="rgba(0, 160, 255, 0.1)">
      <RowBetween padding="14px 16px 12px 16px" borderBottom="1px solid rgba(0, 160, 255, 0.1)">
        <Text fontWeight="500" fontSize="14px">
          {noLiquidity ? t('Initial prices and pool share') : t('Prices and pool share')}
        </Text>
      </RowBetween>
      <AutoColumn style={{ padding: '12px 42px' }} gap="md">
        <AutoRow justify="space-between" gap="4px">
          <AutoColumn justify="center">
            <Text fontSize="16px" fontWeight="600">
              {price?.toSignificant(6) ?? '-'}
            </Text>
            <Text color="placeholder" fontSize="12px" pt={1}>
              {t('%assetA% per %assetB%', {
                assetA: currencies[Field.CURRENCY_B]?.symbol ?? '',
                assetB: currencies[Field.CURRENCY_A]?.symbol ?? '',
              })}
            </Text>
          </AutoColumn>
          <AutoColumn justify="center">
            <Text fontSize="16px" fontWeight="600">
              {price?.invert()?.toSignificant(6) ?? '-'}
            </Text>
            <Text color="placeholder" fontSize="12px" pt={1}>
              {t('%assetA% per %assetB%', {
                assetA: currencies[Field.CURRENCY_A]?.symbol ?? '',
                assetB: currencies[Field.CURRENCY_B]?.symbol ?? '',
              })}
            </Text>
          </AutoColumn>
          <AutoColumn justify="center">
            <Text fontSize="16px" fontWeight="600">
              {noLiquidity && price
                ? '100'
                : (poolTokenPercentage?.lessThan(ONE_BIPS) ? '<0.01' : poolTokenPercentage?.toFixed(2)) ?? '0'}
              %
            </Text>
            <Text color="placeholder" fontSize="12px" pt={1}>
              {t('Share of Pool')}
            </Text>
          </AutoColumn>
        </AutoRow>
      </AutoColumn>
    </Box>
  )
}

export default PoolPriceBar
