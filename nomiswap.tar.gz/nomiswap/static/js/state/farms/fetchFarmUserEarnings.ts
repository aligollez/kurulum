import BigNumber from 'bignumber.js'
import { SerializedFarmConfig } from 'config/constants/types'
import { getAddress } from 'utils/addressHelpers'
import { getStakingServiceContract } from 'utils/contractHelpers'

export const fetchFarmUserEarnings = async (account: string, farmsToFetch: SerializedFarmConfig[]) => {
  const calls = farmsToFetch.map((farm) => {
    const contractAddress = getAddress(farm.contractAddresses)
    const contract = getStakingServiceContract(contractAddress)

    return contract.getReward({ from: account })
  })

  const rawEarningBalances = await Promise.all(calls)

  const parsedEarningBalances = rawEarningBalances.map((earned) => {
    return new BigNumber(earned._hex).toJSON()
  })

  return parsedEarningBalances
}
