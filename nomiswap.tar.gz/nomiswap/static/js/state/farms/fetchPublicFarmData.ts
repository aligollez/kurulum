import BigNumber from 'bignumber.js'
import { DEFAULT_TOKEN_DECIMAL } from 'config'
import erc20 from 'config/abi/erc20.json'
import { getAddress } from 'utils/addressHelpers'
import { BIG_TEN } from 'utils/bigNumber'
import { getFarmingHelperContract, getStakingServiceContract } from 'utils/contractHelpers'
import multicall from 'utils/multicall'
import { SerializedFarm, SerializedBigNumber } from '../types'

type PublicFarmData = {
  tokenAmountTotal: SerializedBigNumber
  lpTotalInQuoteToken: SerializedBigNumber
  lpTotalSupply: SerializedBigNumber
  tokenPriceVsQuote: SerializedBigNumber
  tokensPerSec: SerializedBigNumber
  multiplier: string
}

const fetchFarm = async (farm: SerializedFarm): Promise<PublicFarmData> => {
  const { lpAddresses, token, quoteToken, contractAddresses } = farm
  const lpAddress = getAddress(lpAddresses)
  const contractAddress = getAddress(contractAddresses)

  const calls = [
    // Balance of token in the LP contract
    {
      address: token.address,
      name: 'balanceOf',
      params: [lpAddress],
    },
    // Balance of quote token on LP contract
    {
      address: quoteToken.address,
      name: 'balanceOf',
      params: [lpAddress],
    },
    // Total supply of LP tokens
    {
      address: lpAddress,
      name: 'totalSupply',
    },
    // Token decimals
    {
      address: token.address,
      name: 'decimals',
    },
    // Quote token decimals
    {
      address: quoteToken.address,
      name: 'decimals',
    },
  ]

  const [tokenBalanceLP, quoteTokenBalanceLP, lpTotalSupply, tokenDecimals, quoteTokenDecimals] = await multicall(
    erc20,
    calls,
  )

  const farmingHelperContract = getFarmingHelperContract()
  const stakingServiceContract = getStakingServiceContract(contractAddress)
  const lpTokenBalanceMC = await stakingServiceContract.totalStaked()
  const tokensPerSecRaw = await farmingHelperContract.currentSupplyRate(contractAddress)

  // Ratio in % of LP tokens that are staked in the MC, vs the total number in circulation
  const lpTokenRatio = new BigNumber(lpTokenBalanceMC._hex).div(new BigNumber(lpTotalSupply))
  // Raw amount of token in the LP, including those not staked
  const tokenAmountTotal = new BigNumber(tokenBalanceLP).div(BIG_TEN.pow(tokenDecimals))
  const quoteTokenAmountTotal = new BigNumber(quoteTokenBalanceLP).div(BIG_TEN.pow(quoteTokenDecimals))

  // Amount of quoteToken in the LP that are staked in the MC
  const quoteTokenAmountMc = quoteTokenAmountTotal.times(lpTokenRatio)

  // Total staked in LP, in quote token value
  const lpTotalInQuoteToken = quoteTokenAmountMc.times(new BigNumber(2))

  return {
    tokenAmountTotal: tokenAmountTotal.toJSON(),
    lpTotalSupply: new BigNumber(lpTotalSupply).toJSON(),
    lpTotalInQuoteToken: lpTotalInQuoteToken.toJSON(),
    tokenPriceVsQuote: quoteTokenAmountTotal.div(tokenAmountTotal).toJSON(),
    tokensPerSec: new BigNumber(tokensPerSecRaw._hex).div(BIG_TEN.pow(DEFAULT_TOKEN_DECIMAL)).toJSON(),
    multiplier: `1X`,
  }
}

export default fetchFarm
