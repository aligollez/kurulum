import BigNumber from 'bignumber.js'
import { DEFAULT_TOKEN_DECIMAL } from 'config'
import { Address } from 'config/constants/types'
import { getAddress, getFarmingHelperAddress } from 'utils/addressHelpers'
import { BIG_TEN } from 'utils/bigNumber'
import multicall, { Call } from 'utils/multicall'
import farmingHalperAbi from 'config/abi/farmingHalper.json'

export const fetchPoolsAllocation = async (pools: { pid: number; contractAddresses: Address }[]) => {
  const calls = pools.map((pool) => {
    const poolAddress = getAddress(pool.contractAddresses)
    const farmingHelperAddress = getFarmingHelperAddress()

    const call: Call = {
      address: farmingHelperAddress,
      name: 'currentSupplyRate',
      params: [poolAddress],
    }

    return call
  })

  const responce = await multicall(farmingHalperAbi, calls)

  return pools.map((pool, index) => {
    const poolsAllocationRaw = responce[index]

    return {
      tokensPerSec: new BigNumber(poolsAllocationRaw).div(BIG_TEN.pow(DEFAULT_TOKEN_DECIMAL)),
      pid: pool.pid,
    }
  })
}
