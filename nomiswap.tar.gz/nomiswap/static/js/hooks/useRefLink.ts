import { REFERRER_QUERY_NAME, REFERRER_LS_KEY } from 'config/constants/referrals'

const useRefLink = () => {
  const query = new URLSearchParams(window.location.search)
  const referrerId = query.get(REFERRER_QUERY_NAME)

  if (referrerId) {
    localStorage.setItem(REFERRER_LS_KEY, referrerId)
  }
}

export default useRefLink
