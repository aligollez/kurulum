import { ChainId, Currency, currencyEquals, JSBI, Price, Token } from '@nominex/nomiswap-sdk'
import { useMemo } from 'react'
import useActiveWeb3React from 'hooks/useActiveWeb3React'
import tokens, { mainnetTokens, testnetTokens } from 'config/constants/tokens'
import { PairState, usePairs } from './usePairs'
import { wrappedCurrency } from '../utils/wrappedCurrency'

const { wbnb: WBNB } = tokens

const useBusdToken = (): Token | undefined => {
  const { chainId } = useActiveWeb3React()

  return useMemo(() => {
    switch (chainId) {
      case ChainId.MAINNET:
        return mainnetTokens.busd
      case ChainId.TESTNET:
        return testnetTokens.busd

      default:
        return undefined
    }
  }, [chainId])
}

/**
 * Returns the price in BUSD of the input currency
 * @param currency currency to compute the BUSD price of
 */
export default function useBusdPrice(currency?: Currency): Price | undefined {
  const { chainId } = useActiveWeb3React()
  const busdToken = useBusdToken()
  const wrapped = wrappedCurrency(currency, chainId)
  const tokenPairs: [Currency | undefined, Currency | undefined][] = useMemo(
    () => [
      [chainId && wrapped && currencyEquals(WBNB, wrapped) ? undefined : currency, chainId ? WBNB : undefined],
      [wrapped?.equals(busdToken) ? undefined : wrapped, busdToken],
      [chainId ? WBNB : undefined, busdToken],
    ],
    [chainId, currency, wrapped, busdToken],
  )
  const [[ethPairState, ethPair], [busdPairState, busdPair], [busdEthPairState, busdEthPair]] = usePairs(tokenPairs)

  return useMemo(() => {
    if (!currency || !wrapped || !chainId) {
      return undefined
    }
    // handle WBNB/BNB
    if (wrapped.equals(WBNB)) {
      if (busdPair) {
        const price = busdPair.priceOf(WBNB)
        return new Price(currency, busdToken, price.denominator, price.numerator)
      }
      return undefined
    }
    // handle busd
    if (wrapped.equals(busdToken)) {
      return new Price(busdToken, busdToken, '1', '1')
    }

    const ethPairETHAmount = ethPair?.reserveOf(WBNB)
    const ethPairETHBUSDValue: JSBI =
      ethPairETHAmount && busdEthPair ? busdEthPair.priceOf(WBNB).quote(ethPairETHAmount).raw : JSBI.BigInt(0)

    // all other tokens
    // first try the busd pair
    if (
      busdPairState === PairState.EXISTS &&
      busdPair &&
      busdPair.reserveOf(busdToken).greaterThan(ethPairETHBUSDValue)
    ) {
      const price = busdPair.priceOf(wrapped)
      return new Price(currency, busdToken, price.denominator, price.numerator)
    }
    if (ethPairState === PairState.EXISTS && ethPair && busdEthPairState === PairState.EXISTS && busdEthPair) {
      if (busdEthPair.reserveOf(busdToken).greaterThan('0') && ethPair.reserveOf(WBNB).greaterThan('0')) {
        const ethBusdPrice = busdEthPair.priceOf(busdToken)
        const currencyEthPrice = ethPair.priceOf(WBNB)
        const busdPrice = ethBusdPrice.multiply(currencyEthPrice).invert()
        return new Price(currency, busdToken, busdPrice.denominator, busdPrice.numerator)
      }
    }

    return undefined
  }, [
    chainId,
    currency,
    ethPair,
    ethPairState,
    busdEthPair,
    busdEthPairState,
    busdPair,
    busdPairState,
    wrapped,
    busdToken,
  ])
}

export const useNmxUsdtPrice = (): Price | undefined => {
  const nmxUsdtPrice = useBusdPrice(tokens.nmx)
  return nmxUsdtPrice
}

export const useBNBUsdtPrice = (): Price | undefined => {
  const bnbUsdtPrice = useBusdPrice(tokens.wbnb)
  return bnbUsdtPrice
}
