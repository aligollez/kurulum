import { serializeTokens } from './tokens'
import { SerializedFarmConfig } from './types'

const serializedTokens = serializeTokens()

const farms: SerializedFarmConfig[] = [
  /**
   * These 3 farms (PID 0, 1, 2) should always be at the top of the file.
   */
  // {
  //   pid: 1,
  //   lpSymbol: 'NMX-USDT LP',
  //   lpAddresses: {
  //     97: '0xd4d7512c7e2873db00ac956303c397843bed9780',
  //     56: '0x0eD7e52944161450477ee417DE9Cd3a859b14fD0',
  //   },
  //   contractAddresses: {
  //     97: '0x9e694AaC95EE8a6C4051706926eb5365e0050dd4',
  //     56: '',
  //   },
  //   token: serializedTokens.nmx,
  //   quoteToken: serializedTokens.usdt,
  // },
  {
    pid: 2,
    lpSymbol: 'NMX-BNB LP',
    lpAddresses: {
      97: '',
      56: '0x596f619600Da38acE164C9FAceE730c6dbE83C86',
    },
    contractAddresses: {
      97: '',
      56: '0x5cd67d65Ff07D5BE2488E51F1a8C69273D258338',
    },
    token: serializedTokens.nmx,
    quoteToken: serializedTokens.bnb,
  },
  {
    pid: 3,
    lpSymbol: 'NMX-BUSD LP',
    lpAddresses: {
      97: '',
      56: '0x01Ddfc73488eEBBf6D57EdAb4697a23897b93Ca2',
    },
    contractAddresses: {
      97: '',
      56: '0x857083580AeD7b5726860937EF030ED8072BC9aB',
    },
    token: serializedTokens.nmx,
    quoteToken: serializedTokens.busd,
  },
  /**
   * V3 by order of release (some may be out of PID order due to multiplier boost)
   */
  {
    pid: 100,
    lpSymbol: 'BNB-USDT LP',
    lpAddresses: {
      97: '',
      56: '0xe2Bbf54Dc0ccDD0Cf6270f2aF2f62FF79903Bb27',
    },
    contractAddresses: {
      97: '',
      56: '0x8326E22a36486ae7D4B85e8DFA732527b962805c',
    },
    token: serializedTokens.bnb,
    quoteToken: serializedTokens.usdt,
  },
  {
    pid: 101,
    lpSymbol: 'BUSD-USDT LP',
    lpAddresses: {
      97: '',
      56: '0x8E50d726e2ea87a27fA94760D4e65d58C3aD8b44',
    },
    contractAddresses: {
      97: '',
      56: '0x281e60407b095b956a6A5ac98EE217BEf3144928',
    },
    token: serializedTokens.busd,
    quoteToken: serializedTokens.usdt,
  },
  {
    pid: 102,
    lpSymbol: 'USDC-USDT LP',
    lpAddresses: {
      97: '',
      56: '0xfC3a2AEfF7141D6ce7C2AfB2db6a9e676C2E18A7',
    },
    contractAddresses: {
      97: '',
      56: '0xd8925c88B94513be760AD88BC10D780d58fA001D',
    },
    token: serializedTokens.usdc,
    quoteToken: serializedTokens.usdt,
  },
  {
    pid: 103,
    lpSymbol: 'BTCB-USDT LP',
    lpAddresses: {
      97: '',
      56: '0xa830F3A087c9A642694f6eEa98778e1c70097754',
    },
    contractAddresses: {
      97: '',
      56: '0xA937Eddfd12930F758788BcC936B4762BDE9d54C',
    },
    token: serializedTokens.btcb,
    quoteToken: serializedTokens.usdt,
  },
  {
    pid: 104,
    lpSymbol: 'ETH-BNB LP',
    lpAddresses: {
      97: '',
      56: '0x13dE257cb86a08753Df938b6ad30d1A456A863e6',
    },
    contractAddresses: {
      97: '',
      56: '0xab2f4297E7e31638eBE8362471b3038018A106D8',
    },
    token: serializedTokens.eth,
    quoteToken: serializedTokens.bnb,
  },
  {
    pid: 105,
    lpSymbol: 'TONCOIN-USDC LP',
    lpAddresses: {
      97: '',
      56: '0xDeB1ceFa9bb596A189f76C94FDB0352D5aC736b9',
    },
    contractAddresses: {
      97: '',
      56: '0x5c317770bf9A7d7cC88974A97fFA92C209669bFE',
    },
    token: serializedTokens.toncoin,
    quoteToken: serializedTokens.usdc,
  },
  {
    pid: 106,
    lpSymbol: 'SOL-USDC LP',
    lpAddresses: {
      97: '',
      56: '0x5C551CA8F00E09888F0FD57C7f91CB420ad29999',
    },
    contractAddresses: {
      97: '',
      56: '0x26804231a528c894AB6790530b237449a817da6A',
    },
    token: serializedTokens.sol,
    quoteToken: serializedTokens.usdc,
  },
  {
    pid: 107,
    lpSymbol: 'MATIC-USDT LP',
    lpAddresses: {
      97: '',
      56: '0x996B28Dda11381466C9e410D0b63a313a0f31c6B',
    },
    contractAddresses: {
      97: '',
      56: '0x63A81d936cb14fA3649A4D071608758cFFb3Bd94',
    },
    token: serializedTokens.matic,
    quoteToken: serializedTokens.usdt,
  },
  {
    pid: 108,
    lpSymbol: 'DOGE-USDT LP',
    lpAddresses: {
      97: '',
      56: '0xDCbc1D9D48016b8d5F3B0F9045Eb3B72F38E6B93',
    },
    contractAddresses: {
      97: '',
      56: '0xA0F2C13e20A11e00acF4e7B47604b24ca8908797',
    },
    token: serializedTokens.doge,
    quoteToken: serializedTokens.usdt,
  },
  {
    pid: 109,
    lpSymbol: 'SHIB-BUSD LP',
    lpAddresses: {
      97: '',
      56: '0x943B50018F1A8aa16ce24503eef3E53115103fb6',
    },
    contractAddresses: {
      97: '',
      56: '0x03868d2e45a9b579Cc68B7addd65Cf78Ddb62a68',
    },
    token: serializedTokens.shib,
    quoteToken: serializedTokens.busd,
  },
]

export default farms
