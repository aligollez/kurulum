import { serializeTokens } from './tokens'
import { SerializedPoolConfig, PoolCategory } from './types'

const serializedTokens = serializeTokens()

const pools: SerializedPoolConfig[] = [
  {
    sousId: 0,
    stakingToken: serializedTokens.nmx,
    earningToken: serializedTokens.nmx,
    contractAddresses: {
      97: '',
      56: '0xdbf1b10fe3e05397cd454163f6f1ed0c1181c3b3',
    },
    poolCategory: PoolCategory.CORE,
    harvest: true,
    sortOrder: 1,
    isFinished: false,
    isAutoVault: false,
  },
]

export default pools
