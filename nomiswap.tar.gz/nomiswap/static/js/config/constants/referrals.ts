export const REFERRER_QUERY_NAME = 'r'
export const REFERRER_LS_KEY = 'r'
