import { ChainId, Token } from '@nominex/nomiswap-sdk'
import { serializeToken } from 'state/user/hooks/helpers'
import { SerializedToken } from './types'

const { MAINNET, TESTNET } = ChainId

interface TokenList {
  [symbol: string]: Token
}

interface SerializedTokenList {
  [symbol: string]: SerializedToken
}

export const mainnetTokens = {
  // bnb here points to the wbnb contract. Wherever the currency BNB is required, conditional checks for the symbol 'BNB' can be used
  bnb: new Token(MAINNET, '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c', 18, 'BNB', 'BNB', 'https://www.binance.com/'),
  btcb: new Token(
    MAINNET,
    '0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c',
    18,
    'BTCB',
    'Binance-Peg BTCB Token',
    'https://bitcoin.org/',
  ),
  busd: new Token(
    MAINNET,
    '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56',
    18,
    'BUSD',
    'Binance USD',
    'https://paxos.com/busd/',
  ),
  doge: new Token(
    MAINNET,
    '0xbA2aE424d960c26247Dd6c32edC70B295c744C43',
    8,
    'DOGE',
    'Binance-Peg Dogecoin',
    'https://dogecoin.com/',
  ),
  eth: new Token(
    MAINNET,
    '0x2170Ed0880ac9A755fd29B2688956BD959F933F8',
    18,
    'ETH',
    'Binance-Peg Ethereum Token',
    'https://ethereum.org/en/',
  ),
  matic: new Token(
    MAINNET,
    '0xCC42724C6683B7E57334c4E856f4c9965ED682bD',
    18,
    'MATIC',
    'Polygon',
    'https://polygon.technology/',
  ),
  nmx: new Token(
    MAINNET,
    '0xd32d01A43c869EdcD1117C640fBDcfCFD97d9d65',
    18,
    'NMX',
    'Nominex Token',
    'https://nominex.io/',
  ),
  shib: new Token(
    MAINNET,
    '0x2859e4544C4bB03966803b044A93563Bd2D0DD4D',
    18,
    'SHIB',
    'Binance-Peg SHIBA INU',
    'https://shibatoken.com/',
  ),
  sol: new Token(MAINNET, '0x570A5D26f7765Ecb712C0924E4De545B89fD43dF', 18, 'SOL', 'Solana', 'https://solana.com/'),
  toncoin: new Token(
    MAINNET,
    '0x76A797A59Ba2C17726896976B7B3747BfD1d220f',
    9,
    'TONCOIN',
    'Toncoin',
    'https://ton.org/',
  ),
  usdc: new Token(
    MAINNET,
    '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d',
    18,
    'USDC',
    'Binance-Peg USD Coin',
    'https://www.centre.io/usdc',
  ),
  usdt: new Token(
    MAINNET,
    '0x55d398326f99059fF775485246999027B3197955',
    18,
    'USDT',
    'Tether USD',
    'https://tether.to/',
  ),
  wbnb: new Token(
    MAINNET,
    '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    18,
    'WBNB',
    'Wrapped BNB',
    'https://www.binance.com/',
  ),
}

export const testnetTokens = {
  // bnb here points to the wbnb contract. Wherever the currency BNB is required, conditional checks for the symbol 'BNB' can be used
  bnb: new Token(TESTNET, '0xae13d989dac2f0debff460ac112a837c89baa7cd', 18, 'BNB', 'BNB', 'https://www.binance.com/'),
  wbnb: new Token(
    TESTNET,
    '0xae13d989dac2f0debff460ac112a837c89baa7cd',
    18,
    'WBNB',
    'Wrapped BNB',
    'https://www.binance.com/',
  ),
  nmx: new Token(
    TESTNET,
    '0xea62868e68d1Ac0c9d312C9f00a81B5295da5ebD',
    18,
    'NMX',
    'Nominex Token',
    'https://nominex.io/',
  ),
  busd: new Token(
    TESTNET,
    '0xD4D7512C7E2873DB00ac956303c397843bEd9780',
    18,
    'BUSD',
    'Binance USD',
    'https://www.paxos.com/busd/',
  ),
}

const tokens = (): TokenList => {
  const chainId = process.env.REACT_APP_CHAIN_ID

  // If testnet - return list comprised of testnetTokens wherever they exist, and mainnetTokens where they don't
  if (parseInt(chainId, 10) === TESTNET) {
    return Object.keys(mainnetTokens).reduce((accum, key) => {
      return { ...accum, [key]: testnetTokens[key] || mainnetTokens[key] }
    }, {})
  }

  return mainnetTokens
}

export const serializeTokens = (): SerializedTokenList => {
  const unserializedTokens = tokens()
  const serializedTokens = Object.keys(unserializedTokens).reduce((accum, key) => {
    return { ...accum, [key]: serializeToken(unserializedTokens[key]) }
  }, {})

  return serializedTokens
}

export default tokens()
