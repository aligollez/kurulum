import React, { lazy, useState } from 'react'
import { Route, Switch } from 'react-router-dom'

import SuspenseWithChunkError from './components/SuspenseWithChunkError'
import PageLoader from './components/Loader/PageLoader'

// Views included in the main bundle because they are the most visited pages
import Home from './views/Home'
import Pools from './views/Pools'
import Swap from './views/Swap'
import { RedirectDuplicateTokenIds, RedirectOldAddLiquidityPathStructure } from './views/AddLiquidity/redirects'
import RedirectOldRemoveLiquidityPathStructure from './views/RemoveLiquidity/redirects'
import { RedirectToSwap } from './views/Swap/redirects'
import Menu from './components/Menu'
import Aside from './components/ProSidebar'

// Route-based code splitting

const Farms = lazy(() => import('./views/Farms'))
const AddLiquidity = lazy(() => import('./views/AddLiquidity'))
const Liquidity = lazy(() => import('./views/Pool'))
const PoolFinder = lazy(() => import('./views/PoolFinder'))
const RemoveLiquidity = lazy(() => import('./views/RemoveLiquidity'))
const Referrals = lazy(() => import('./views/Referrals'))
const NotFound = lazy(() => import('./views/NotFound'))

// const FarmAuction = lazy(() => import('./views/FarmAuction'))
// const Lottery = lazy(() => import('./views/Lottery'))
// const Ifos = lazy(() => import('./views/Ifos'))
// const Teams = lazy(() => import('./views/Teams'))
// const Team = lazy(() => import('./views/Teams/Team'))
// const TradingCompetition = lazy(() => import('./views/TradingCompetition'))
// const Predictions = lazy(() => import('./views/Predictions'))
// const PredictionsLeaderboard = lazy(() => import('./views/Predictions/Leaderboard'))
// const Voting = lazy(() => import('./views/Voting'))
// const Proposal = lazy(() => import('./views/Voting/Proposal'))
// const CreateProposal = lazy(() => import('./views/Voting/CreateProposal'))
// const Info = lazy(() => import('./views/Info'))
// const NftMarket = lazy(() => import('./views/Nft/market'))
// const ProfileCreation = lazy(() => import('./views/ProfileCreation'))
// const PancakeSquad = lazy(() => import('./views/PancakeSquad'))

const Layout: React.FC = () => {
  const [collapsed, setCollapsed] = useState(false)
  const [toggled, setToggled] = useState(false)

  const handleCollapsedChange = () => {
    setCollapsed(!collapsed)
  }

  const handleToggleSidebar = () => {
    setToggled(!toggled)
  }

  return (
    <div style={{ display: 'flex' }}>
      <Aside
        collapsed={collapsed}
        toggled={toggled}
        handleCollapsedChange={handleCollapsedChange}
        handleToggleSidebar={handleToggleSidebar}
      />
      <Menu handleToggleSidebar={handleToggleSidebar}>
        <SuspenseWithChunkError fallback={<PageLoader />}>
          <Switch>
            <Route path="/" exact>
              <Home />
            </Route>
            {/* <Route exact path="/farms/auction">
              <FarmAuction />
            </Route> */}
            <Route path="/farms">
              <Farms />
            </Route>
            <Route path="/pools">
              <Pools />
            </Route>
            <Route path="/referrals">
              <Referrals />
            </Route>
            {/* <Route path="/lottery">
              <Lottery />
            </Route>
          {/* <Route path="/ifo">
              <Ifos />
            </Route> */}
            {/* <Route exact path="/teams">
              <Teams />
            </Route> */}
            {/* <Route path="/teams/:id">
              <Team />
            </Route> */}
            {/* <Route path="/create-profile">
              <ProfileCreation />
            </Route> */}
            {/* <Route path="/competition">
              <TradingCompetition />
            </Route> */}
            {/* <Route exact path="/prediction">
              <Predictions />
            </Route> */}
            {/* <Route path="/prediction/leaderboard">
              <PredictionsLeaderboard />
            </Route> */}
            {/* <Route exact path="/voting">
              <Voting />
            </Route> */}
            {/* <Route exact path="/voting/proposal/create">
              <CreateProposal />
            </Route> */}
            {/* <Route path="/voting/proposal/:id">
              <Proposal />
            </Route> */}

            {/* NFT */}
            {/* <Route path="/nfts">
              <NftMarket />
            </Route> */}

            {/* <Route path="/pancake-squad">
              <PancakeSquad />
            </Route> */}

            {/* Info pages */}
            {/* <Route path="/info">
              <Info />
            </Route> */}

            {/* Using this format because these components use routes injected props. We need to rework them with hooks */}
            <Route exact strict path="/swap" component={Swap} />
            <Route exact strict path="/swap/:outputCurrency" component={RedirectToSwap} />
            <Route exact strict path="/liquidity" component={Liquidity} />
            <Route exact path="/liquidity/find" component={PoolFinder} />
            <Route exact path="/liquidity/add" component={AddLiquidity} />
            <Route exact path="/liquidity/add/:currencyIdA" component={RedirectOldAddLiquidityPathStructure} />
            <Route exact path="/liquidity/add/:currencyIdA/:currencyIdB" component={RedirectDuplicateTokenIds} />
            <Route exact strict path="/liquidity/remove/:tokens" component={RedirectOldRemoveLiquidityPathStructure} />
            <Route exact strict path="/liquidity/remove/:currencyIdA/:currencyIdB" component={RemoveLiquidity} />

            {/* 404 */}
            <Route component={NotFound} />
          </Switch>
        </SuspenseWithChunkError>
      </Menu>
    </div>
  )
}

export default Layout
