(this["webpackJsonpnomiswap-frontend"] = this["webpackJsonpnomiswap-frontend"] || []).push([
    [7], {
        1170: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, "default", (function() {
                return Tn
            }));
            var r, a, i, c, s, o, l, d, b, j, u, p, x, O, m, h, f, g, v, y, k, w, S, C, T, A, D, q, B, N, R, P, z, L, F, J, E, U, Q, M, I, W, H, G, X, V, Y, Z, _, K, $, ee, te, ne, re = n(4),
                ae = n(11),
                ie = n(9),
                ce = n(0),
                se = n.n(ce),
                oe = n(73),
                le = n(19),
                de = n.n(le),
                be = n(59),
                je = n(2),
                ue = n(7),
                pe = n(5),
                xe = n(155),
                Oe = n(184),
                me = n(434),
                he = n(430),
                fe = n(15),
                ge = n(48),
                ve = n(386),
                ye = n(93),
                ke = n(385),
                we = n(351),
                Se = n(438),
                Ce = n(431),
                Te = function(e, t) {
                    var n = Object(ce.useState)(!1),
                        r = Object(ae.a)(n, 2),
                        a = r[0],
                        i = r[1];
                    return Object(ce.useEffect)((function() {
                        var n;
                        return e && !a ? i(!0) : !e && a && (n = setTimeout((function() {
                                return i(!1)
                            }), t)),
                            function() {
                                return clearTimeout(n)
                            }
                    }), [e, t, a]), a
                },
                Ae = n(1),
                De = function(e) {
                    var t = e.variant,
                        n = e.displayApr;
                    return Object(Ae.jsxs)(je.O, {
                        alignItems: "center",
                        children: [n, "%", "text-and-button" === t && !1]
                    })
                },
                qe = n(71),
                Be = n(41),
                Ne = function(e) {
                    var t = e.quoteTokenAddress,
                        n = e.tokenAddress,
                        r = Be.a.wbnb.address,
                        a = n && n !== r ? n : "BNB";
                    return "".concat(t && t !== r ? t : "BNB", "/").concat(a)
                },
                Re = pe.e.div(r || (r = Object(ie.a)(["\n  display: flex;\n  align-items: center;\n  color: ", ";\n\n  button {\n    width: 20px;\n    height: 20px;\n\n    svg {\n      path {\n        fill: ", ";\n      }\n    }\n  }\n"])), (function(e) {
                    return e.theme.colors.text
                }), (function(e) {
                    return e.theme.colors.textSubtle
                })),
                Pe = pe.e.div(a || (a = Object(ie.a)(["\n  min-width: 60px;\n  text-align: left;\n"]))),
                ze = function(e) {
                    var t = e.value,
                        n = e.pid,
                        r = e.lpLabel,
                        a = e.lpSymbol,
                        i = e.multiplier,
                        c = e.tokenAddress,
                        s = e.quoteTokenAddress,
                        o = e.nmxPrice,
                        l = e.originalValue,
                        d = e.hideButton,
                        b = void 0 !== d && d,
                        j = Ne({
                            quoteTokenAddress: s,
                            tokenAddress: c
                        }),
                        u = "".concat(qe.a, "/").concat(j);
                    return 0 !== l ? Object(Ae.jsx)(Re, {
                        children: l ? Object(Ae.jsx)(De, {
                            variant: b ? "text" : "text-and-button",
                            pid: n,
                            lpSymbol: a,
                            lpLabel: r,
                            multiplier: i,
                            cakePrice: o,
                            apr: l,
                            displayApr: t,
                            addLiquidityUrl: u
                        }) : Object(Ae.jsx)(Pe, {
                            children: Object(Ae.jsx)(je.Bb, {
                                width: 60
                            })
                        })
                    }) : Object(Ae.jsx)(Re, {
                        children: Object(Ae.jsxs)(Pe, {
                            children: [l, "%"]
                        })
                    })
                },
                Le = pe.e.div(i || (i = Object(ie.a)(["\n  padding-left: 16px;\n  display: flex;\n  align-items: center;\n\n  ", " {\n    padding-left: 32px;\n  }\n"])), (function(e) {
                    return e.theme.mediaQueries.sm
                })),
                Fe = function(e) {
                    var t = e.token,
                        n = e.quoteToken,
                        r = e.label,
                        a = e.pid,
                        i = Object(Oe.a)(a).stakedBalance,
                        c = Object(fe.b)().t,
                        s = Object(ge.d)(i);
                    return Object(Ae.jsxs)(Le, {
                        children: [Object(Ae.jsx)(je.Nb, {
                            variant: "inverted",
                            primarySymbol: t.symbol,
                            secondarySymbol: n.symbol,
                            size: 40,
                            mr: "8px"
                        }), Object(Ae.jsxs)("div", {
                            children: [s ? Object(Ae.jsx)(je.Jb, {
                                color: "primary",
                                fontSize: "12px",
                                bold: !0,
                                textTransform: "uppercase",
                                children: c("Farming")
                            }) : null, Object(Ae.jsx)(je.Jb, {
                                bold: !0,
                                children: r
                            })]
                        })]
                    })
                },
                Je = pe.e.span(c || (c = Object(ie.a)(["\n  color: ", ";\n  display: flex;\n  align-items: center;\n"])), (function(e) {
                    var t = e.earned,
                        n = e.theme;
                    return t ? n.colors.text : n.colors.textDisabled
                })),
                Ee = function(e) {
                    var t = e.earnings;
                    return e.userDataReady ? Object(Ae.jsx)(Je, {
                        earned: t,
                        children: t.toLocaleString()
                    }) : Object(Ae.jsx)(Je, {
                        earned: 0,
                        children: Object(Ae.jsx)(je.Bb, {
                            width: 60
                        })
                    })
                },
                Ue = pe.e.div(s || (s = Object(ie.a)(["\n  display: flex;\n  width: 100%;\n  justify-content: flex-end;\n  padding-right: 8px;\n  color: ", ";\n\n  ", " {\n    padding-right: 0px;\n  }\n"])), (function(e) {
                    return e.theme.colors.primary
                }), (function(e) {
                    return e.theme.mediaQueries.sm
                })),
                Qe = Object(pe.e)(je.A)(o || (o = Object(ie.a)(["\n  transform: ", ";\n  height: 20px;\n"])), (function(e) {
                    return e.toggled ? "rotate(180deg)" : "rotate(0)"
                })),
                Me = function(e) {
                    var t = e.actionPanelToggled,
                        n = Object(fe.b)().t,
                        r = Object(je.bc)().isDesktop;
                    return Object(Ae.jsxs)(Ue, {
                        children: [!r && n("Details"), Object(Ae.jsx)(Qe, {
                            color: "primary",
                            toggled: t
                        })]
                    })
                },
                Ie = pe.e.div(l || (l = Object(ie.a)(["\n  display: inline-block;\n"]))),
                We = pe.e.div(d || (d = Object(ie.a)(["\n  min-width: 110px;\n  font-weight: 600;\n  text-align: right;\n  margin-right: 14px;\n\n  ", " {\n    text-align: left;\n    margin-right: 0;\n  }\n"])), (function(e) {
                    return e.theme.mediaQueries.lg
                })),
                He = pe.e.div(b || (b = Object(ie.a)(["\n  display: flex;\n  align-items: center;\n"]))),
                Ge = function(e) {
                    var t = e.liquidity,
                        n = t && t.gt(0) ? "$".concat(Number(t).toLocaleString(void 0, {
                            maximumFractionDigits: 0
                        })) : Object(Ae.jsx)(je.Bb, {
                            width: 60
                        }),
                        r = Object(fe.b)().t,
                        a = Object(je.ec)(r("Total value of the funds in this farm\u2019s liquidity pool"), {
                            placement: "top-end",
                            tooltipOffset: [20, 10]
                        }),
                        i = a.targetRef,
                        c = a.tooltip,
                        s = a.tooltipVisible;
                    return Object(Ae.jsxs)(He, {
                        children: [Object(Ae.jsx)(We, {
                            children: Object(Ae.jsx)(je.Jb, {
                                children: n
                            })
                        }), Object(Ae.jsx)(Ie, {
                            ref: i,
                            children: Object(Ae.jsx)(je.R, {
                                color: "textSubtle"
                            })
                        }), s && c]
                    })
                },
                Xe = n(33),
                Ve = n(36),
                Ye = function(e) {
                    var t = Object(fe.b)().t;
                    return Object(Ae.jsx)(je.Hb, Object(re.a)(Object(re.a)({
                        variant: "primary",
                        startIcon: Object(Ae.jsx)(je.Ub, {
                            width: "18px",
                            color: "primary",
                            mr: "4px"
                        })
                    }, e), {}, {
                        children: t("Core")
                    }))
                },
                Ze = function(e) {
                    var t = Object(fe.b)().t;
                    return Object(Ae.jsx)(je.Hb, Object(re.a)(Object(re.a)({
                        variant: "failure",
                        outline: !0,
                        startIcon: Object(Ae.jsx)(je.G, {
                            width: "18px",
                            color: "failure",
                            mr: "4px"
                        })
                    }, e), {}, {
                        children: t("Community")
                    }))
                },
                _e = function(e) {
                    var t = Object(fe.b)().t;
                    return Object(Ae.jsx)(je.Hb, Object(re.a)(Object(re.a)({
                        variant: "textSubtle",
                        outline: !0
                    }, e), {}, {
                        children: t("Dual")
                    }))
                },
                Ke = n(3),
                $e = n.n(Ke),
                et = n(10),
                tt = n(119),
                nt = n(35),
                rt = n(70),
                at = n(111),
                it = n(107),
                ct = n(190),
                st = n(49),
                ot = function(e) {
                    var t = Object(st.j)(e.contractAddresses);
                    return {
                        onReward: Object(ce.useCallback)(Object(et.a)($e.a.mark((function e() {
                            return $e.a.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.next = 2, Object(ct.a)(t);
                                    case 2:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        }))), [t])
                    }
                },
                lt = pe.e.div(j || (j = Object(ie.a)(["\n  padding: 16px;\n  background: ", ";\n  border-radius: 16px;\n  flex-grow: 1;\n  flex-basis: 0;\n  margin-bottom: 16px;\n\n  ", " {\n    margin-left: 12px;\n    margin-right: 12px;\n    margin-bottom: 0;\n    max-height: 100px;\n  }\n\n  ", " {\n    margin-left: 48px;\n    margin-right: 0;\n    margin-bottom: 0;\n    max-height: 100px;\n  }\n"])), (function(e) {
                    return e.theme.colors.darkGray500
                }), (function(e) {
                    return e.theme.mediaQueries.sm
                }), (function(e) {
                    return e.theme.mediaQueries.xl
                })),
                dt = pe.e.div(u || (u = Object(ie.a)(["\n  display: flex;\n  margin-bottom: 7px;\n"]))),
                bt = pe.e.div(p || (p = Object(ie.a)(["\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n"]))),
                jt = function(e) {
                    var t = e.pid,
                        n = e.userData,
                        r = e.userDataReady,
                        a = Object(it.a)(),
                        i = a.toastSuccess,
                        c = a.toastError,
                        s = new de.a(n.earnings),
                        o = Object(Oe.g)(),
                        l = nt.c,
                        d = 0,
                        b = r ? l.toLocaleString() : Object(Ae.jsx)(je.Bb, {
                            width: 60
                        });
                    s.isZero() || (d = (l = Object(ge.c)(s)).multipliedBy(o).toNumber(), b = l.toFixed(3, de.a.ROUND_DOWN));
                    var j = Object(ce.useState)(!1),
                        u = Object(ae.a)(j, 2),
                        p = u[0],
                        x = u[1],
                        O = ot(e).onReward,
                        m = Object(fe.b)().t,
                        h = Object(rt.b)(),
                        f = Object(be.c)().account;
                    return Object(Ae.jsxs)(lt, {
                        children: [Object(Ae.jsx)(dt, {
                            children: Object(Ae.jsxs)(je.Jb, {
                                bold: !0,
                                textTransform: "uppercase",
                                color: "white",
                                fontSize: "12px",
                                children: ["NMX ", m("Earned")]
                            })
                        }), Object(Ae.jsxs)(bt, {
                            children: [Object(Ae.jsxs)("div", {
                                children: [Object(Ae.jsx)(je.Q, {
                                    children: b
                                }), d > 0 && Object(Ae.jsx)(tt.a, {
                                    fontSize: "12px",
                                    color: "textSubtle",
                                    decimals: 2,
                                    value: d,
                                    unit: " USD",
                                    prefix: "~"
                                })]
                            }), Object(Ae.jsx)(je.o, {
                                disabled: l.eq(0) || p || !r,
                                onClick: Object(et.a)($e.a.mark((function e() {
                                    return $e.a.wrap((function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                            case 0:
                                                return x(!0), e.prev = 1, e.next = 4, O();
                                            case 4:
                                                i("".concat(m("Harvested"), "!"), m("Your %symbol% earnings have been sent to your wallet!", {
                                                    symbol: "NMX"
                                                })), e.next = 11;
                                                break;
                                            case 7:
                                                e.prev = 7, e.t0 = e.catch(1), c(m("Error"), m("Please try again. Confirm the transaction and make sure you are paying enough gas!")), console.error(e.t0);
                                            case 11:
                                                return e.prev = 11, x(!1), e.finish(11);
                                            case 14:
                                                h(Object(at.b)({
                                                    account: f,
                                                    pids: [t]
                                                }));
                                            case 15:
                                            case "end":
                                                return e.stop()
                                        }
                                    }), e, null, [
                                        [1, 7, 11, 14]
                                    ])
                                }))),
                                ml: "4px",
                                children: m(p ? "Harvesting" : "Harvest")
                            })]
                        })]
                    })
                },
                ut = n(130),
                pt = function(e) {
                    var t = Object(st.j)(e.contractAddresses);
                    return {
                        onUnstake: Object(ce.useCallback)(function() {
                            var e = Object(et.a)($e.a.mark((function e(n) {
                                return $e.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.next = 2, Object(ct.c)(t, n);
                                        case 2:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })));
                            return function(t) {
                                return e.apply(this, arguments)
                            }
                        }(), [t])
                    }
                },
                xt = pe.e.div(x || (x = Object(ie.a)(["\n  height: ", "px;\n  width: ", "px;\n"])), (function(e) {
                    return e.size
                }), (function(e) {
                    return e.size
                })),
                Ot = function(e) {
                    var t, n = e.size,
                        r = void 0 === n ? "md" : n,
                        a = Object(ce.useContext)(pe.a).spacing;
                    switch (r) {
                        case "lg":
                            t = a[6];
                            break;
                        case "sm":
                            t = a[2];
                            break;
                        case "md":
                        default:
                            t = a[4]
                    }
                    return Object(Ae.jsx)(xt, {
                        size: t
                    })
                },
                mt = pe.e.div(O || (O = Object(ie.a)(["\n  align-items: center;\n  background-color: ", "00;\n  display: flex;\n  margin: 0;\n  padding: ", "px 0;\n"])), (function(e) {
                    return e.theme.colors.primaryDark
                }), (function(e) {
                    return e.theme.spacing[4]
                })),
                ht = pe.e.div(m || (m = Object(ie.a)(["\n  flex: 1;\n"]))),
                ft = function(e) {
                    var t = e.children,
                        n = se.a.Children.toArray(t).length;
                    return Object(Ae.jsx)(mt, {
                        children: se.a.Children.map(t, (function(e, t) {
                            return Object(Ae.jsxs)(Ae.Fragment, {
                                children: [Object(Ae.jsx)(ht, {
                                    children: e
                                }), t < n - 1 && Object(Ae.jsx)(Ot, {})]
                            })
                        }))
                    })
                },
                gt = n(63),
                vt = pe.e.div(h || (h = Object(ie.a)(["\n  display: flex;\n  flex-direction: column;\n  background-color: ", ";\n  border-radius: 16px;\n  box-shadow: ", ";\n  color: ", ";\n  padding: 8px 16px 8px 0;\n  width: 100%;\n"])), (function(e) {
                    return e.theme.colors.input
                }), (function(e) {
                    var t = e.isWarning,
                        n = void 0 !== t && t,
                        r = e.theme;
                    return n ? r.shadows.warning : r.shadows.inset
                }), (function(e) {
                    return e.theme.colors.text
                })),
                yt = Object(pe.e)(je.W)(f || (f = Object(ie.a)(["\n  box-shadow: none;\n  width: 60px;\n  margin: 0 8px;\n  padding: 0 8px;\n  border: none;\n\n  ", " {\n    width: 80px;\n  }\n\n  ", " {\n    width: auto;\n  }\n"])), (function(e) {
                    return e.theme.mediaQueries.xs
                }), (function(e) {
                    return e.theme.mediaQueries.sm
                })),
                kt = Object(pe.e)(je.Jb)(g || (g = Object(ie.a)(["\n  position: absolute;\n  bottom: -22px;\n  a {\n    display: inline;\n  }\n"]))),
                wt = function(e) {
                    var t = e.max,
                        n = e.symbol,
                        r = e.onChange,
                        a = e.onSelectMax,
                        i = e.value,
                        c = e.addLiquidityUrl,
                        s = e.inputTitle,
                        o = e.decimals,
                        l = void 0 === o ? 18 : o,
                        d = Object(fe.b)().t,
                        b = "0" === t || !t;
                    return Object(Ae.jsxs)("div", {
                        style: {
                            position: "relative"
                        },
                        children: [Object(Ae.jsxs)(vt, {
                            isWarning: b,
                            children: [Object(Ae.jsxs)(je.O, {
                                justifyContent: "space-between",
                                pl: "16px",
                                children: [Object(Ae.jsx)(je.Jb, {
                                    fontSize: "14px",
                                    children: s
                                }), Object(Ae.jsx)(je.Jb, {
                                    fontSize: "14px",
                                    children: d("Balance: %balance%", {
                                        balance: function(e) {
                                            if (b) return "0";
                                            var t = Object(gt.parseUnits)(e, l);
                                            return Object(ge.a)(t, l, l)
                                        }(t)
                                    })
                                })]
                            }), Object(Ae.jsxs)(je.O, {
                                alignItems: "flex-end",
                                justifyContent: "space-around",
                                children: [Object(Ae.jsx)(yt, {
                                    pattern: "^[0-9]*[.,]?[0-9]{0,".concat(l, "}$"),
                                    inputMode: "decimal",
                                    step: "any",
                                    min: "0",
                                    onChange: r,
                                    placeholder: "0",
                                    value: i
                                }), Object(Ae.jsx)(je.o, {
                                    scale: "sm",
                                    onClick: a,
                                    mr: "8px",
                                    children: d("Max")
                                }), Object(Ae.jsx)(je.Jb, {
                                    fontSize: "16px",
                                    children: n
                                })]
                            })]
                        }), b && Object(Ae.jsxs)(kt, {
                            fontSize: "14px",
                            color: "failure",
                            children: [d("No tokens to stake"), ":", " ", Object(Ae.jsx)(je.Y, {
                                fontSize: "14px",
                                bold: !1,
                                href: c,
                                external: !0,
                                color: "failure",
                                children: d("Get %symbol%", {
                                    symbol: n
                                })
                            })]
                        })]
                    })
                },
                St = n(436),
                Ct = function(e) {
                    var t = e.max,
                        n = e.stakedBalance,
                        r = e.onConfirm,
                        a = e.onDismiss,
                        i = e.tokenName,
                        c = void 0 === i ? "" : i,
                        s = e.multiplier,
                        o = e.displayApr,
                        l = e.lpPrice,
                        d = e.lpLabel,
                        b = e.apr,
                        j = e.addLiquidityUrl,
                        u = e.cakePrice,
                        p = Object(ce.useState)(""),
                        x = Object(ae.a)(p, 2),
                        O = x[0],
                        m = x[1],
                        h = Object(it.a)(),
                        f = h.toastSuccess,
                        g = h.toastError,
                        v = Object(ce.useState)(!1),
                        y = Object(ae.a)(v, 2),
                        k = y[0],
                        w = y[1],
                        S = Object(ce.useState)(!1),
                        C = Object(ae.a)(S, 2),
                        T = C[0],
                        A = C[1],
                        D = Object(fe.b)().t,
                        q = Object(ce.useMemo)((function() {
                            return Object(ge.f)(t)
                        }), [t]),
                        B = new de.a(O),
                        N = new de.a(q),
                        R = Object(ce.useCallback)((function(e) {
                            e.currentTarget.validity.valid && m(e.currentTarget.value.replace(/,/g, "."))
                        }), [m]),
                        P = Object(ce.useCallback)((function() {
                            m(q)
                        }), [q, m]);
                    return T ? Object(Ae.jsx)(St.a, {
                        linkLabel: D("Get %symbol%", {
                            symbol: d
                        }),
                        stakingTokenBalance: n.plus(t),
                        stakingTokenSymbol: c,
                        stakingTokenPrice: l.toNumber(),
                        earningTokenPrice: u.toNumber(),
                        apr: b,
                        multiplier: s,
                        displayApr: o,
                        linkHref: j,
                        isFarm: !0,
                        initialValue: O,
                        onBack: function() {
                            return A(!1)
                        }
                    }) : Object(Ae.jsxs)(je.jb, {
                        title: D("Stake LP tokens"),
                        onDismiss: a,
                        children: [Object(Ae.jsx)(wt, {
                            value: O,
                            onSelectMax: P,
                            onChange: R,
                            max: q,
                            symbol: c,
                            addLiquidityUrl: j,
                            inputTitle: D("Stake")
                        }), Object(Ae.jsxs)(ft, {
                            children: [Object(Ae.jsx)(je.o, {
                                variant: "secondary",
                                onClick: a,
                                width: "100%",
                                disabled: k,
                                children: D("Cancel")
                            }), Object(Ae.jsx)(je.o, {
                                width: "100%",
                                disabled: k || !B.isFinite() || B.eq(0) || B.gt(N),
                                onClick: Object(et.a)($e.a.mark((function e() {
                                    return $e.a.wrap((function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                            case 0:
                                                return w(!0), e.prev = 1, e.next = 4, r(O);
                                            case 4:
                                                f(D("Staked!"), D("Your funds have been staked in the farm")), a(), e.next = 12;
                                                break;
                                            case 8:
                                                e.prev = 8, e.t0 = e.catch(1), g(D("Error"), D("Please try again. Confirm the transaction and make sure you are paying enough gas!")), console.error(e.t0);
                                            case 12:
                                                return e.prev = 12, w(!1), e.finish(12);
                                            case 15:
                                            case "end":
                                                return e.stop()
                                        }
                                    }), e, null, [
                                        [1, 8, 12, 15]
                                    ])
                                }))),
                                children: D(k ? "Confirming" : "Confirm")
                            })]
                        }), Object(Ae.jsx)(je.Z, {
                            href: j,
                            style: {
                                alignSelf: "center"
                            },
                            children: D("Get %symbol%", {
                                symbol: c
                            })
                        })]
                    })
                },
                Tt = function(e) {
                    var t = e.onConfirm,
                        n = e.onDismiss,
                        r = e.max,
                        a = e.tokenName,
                        i = void 0 === a ? "" : a,
                        c = Object(ce.useState)(""),
                        s = Object(ae.a)(c, 2),
                        o = s[0],
                        l = s[1],
                        d = Object(it.a)(),
                        b = d.toastSuccess,
                        j = d.toastError,
                        u = Object(ce.useState)(!1),
                        p = Object(ae.a)(u, 2),
                        x = p[0],
                        O = p[1],
                        m = Object(fe.b)().t,
                        h = Object(ce.useMemo)((function() {
                            return Object(ge.f)(r)
                        }), [r]),
                        f = new de.a(o),
                        g = new de.a(h),
                        v = Object(ce.useCallback)((function(e) {
                            e.currentTarget.validity.valid && l(e.currentTarget.value.replace(/,/g, "."))
                        }), [l]),
                        y = Object(ce.useCallback)((function() {
                            l(h)
                        }), [h, l]);
                    return Object(Ae.jsxs)(je.jb, {
                        title: m("Unstake LP tokens"),
                        onDismiss: n,
                        children: [Object(Ae.jsx)(wt, {
                            onSelectMax: y,
                            onChange: v,
                            value: o,
                            max: h,
                            symbol: i,
                            inputTitle: m("Unstake")
                        }), Object(Ae.jsxs)(ft, {
                            children: [Object(Ae.jsx)(je.o, {
                                variant: "secondary",
                                onClick: n,
                                width: "100%",
                                disabled: x,
                                children: m("Cancel")
                            }), Object(Ae.jsx)(je.o, {
                                disabled: x || !f.isFinite() || f.eq(0) || f.gt(g),
                                onClick: Object(et.a)($e.a.mark((function e() {
                                    return $e.a.wrap((function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                            case 0:
                                                return O(!0), e.prev = 1, e.next = 4, t(o);
                                            case 4:
                                                b(m("Unstaked!"), m("Your earnings have also been harvested to your wallet")), n(), e.next = 12;
                                                break;
                                            case 8:
                                                e.prev = 8, e.t0 = e.catch(1), j(m("Error"), m("Please try again. Confirm the transaction and make sure you are paying enough gas!")), console.error(e.t0);
                                            case 12:
                                                return e.prev = 12, O(!1), e.finish(12);
                                            case 15:
                                            case "end":
                                                return e.stop()
                                        }
                                    }), e, null, [
                                        [1, 8, 12, 15]
                                    ])
                                }))),
                                width: "100%",
                                children: m(x ? "Confirming" : "Confirm")
                            })]
                        })]
                    })
                },
                At = function(e) {
                    var t = Object(st.j)(e.contractAddresses);
                    return {
                        onStake: Object(ce.useCallback)(function() {
                            var e = Object(et.a)($e.a.mark((function e(n) {
                                var r;
                                return $e.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.next = 2, Object(ct.b)(t, n);
                                        case 2:
                                            r = e.sent, console.info(r);
                                        case 4:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })));
                            return function(t) {
                                return e.apply(this, arguments)
                            }
                        }(), [t])
                    }
                },
                Dt = n(54),
                qt = n(175),
                Bt = function(e) {
                    var t = Object(qt.a)().callWithGasPrice,
                        n = Object(Xe.a)(e.lpAddresses),
                        r = Object(Xe.a)(e.contractAddresses),
                        a = Object(st.f)(n);
                    return {
                        onApprove: Object(ce.useCallback)(Object(et.a)($e.a.mark((function e() {
                            var n, i;
                            return $e.a.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.next = 2, t(a, "approve", [r, Dt.a.constants.MaxUint256]);
                                    case 2:
                                        return n = e.sent, e.next = 5, n.wait();
                                    case 5:
                                        return i = e.sent, e.abrupt("return", i.status);
                                    case 7:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        }))), [a, t, r])
                    }
                },
                Nt = pe.e.div(v || (v = Object(ie.a)(["\n  display: flex;\n"]))),
                Rt = function(e) {
                    var t = e.pid,
                        n = e.apr,
                        r = e.multiplier,
                        a = e.lpSymbol,
                        i = e.lpLabel,
                        c = e.quoteToken,
                        s = e.token,
                        o = e.userDataReady,
                        l = e.displayApr,
                        d = Object(fe.b)().t,
                        b = Object(it.a)().toastError,
                        j = Object(be.c)().account,
                        u = Object(ce.useState)(!1),
                        p = Object(ae.a)(u, 2),
                        x = p[0],
                        O = p[1],
                        m = Object(Oe.a)(t),
                        h = m.allowance,
                        f = m.tokenBalance,
                        g = m.stakedBalance,
                        v = At(e).onStake,
                        y = pt(e).onUnstake,
                        k = Object(oe.g)(),
                        w = Object(Oe.c)(a),
                        S = Object(Oe.g)(),
                        C = j && h && h.isGreaterThan(0),
                        T = Ne({
                            quoteTokenAddress: c.address,
                            tokenAddress: s.address
                        }),
                        A = "".concat(qe.a, "/").concat(T),
                        D = function() {
                            var e = Object(et.a)($e.a.mark((function e(n) {
                                return $e.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.next = 2, v(n);
                                        case 2:
                                            L(Object(at.b)({
                                                account: j,
                                                pids: [t]
                                            }));
                                        case 3:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })));
                            return function(t) {
                                return e.apply(this, arguments)
                            }
                        }(),
                        q = function() {
                            var e = Object(et.a)($e.a.mark((function e(n) {
                                return $e.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.next = 2, y(n);
                                        case 2:
                                            L(Object(at.b)({
                                                account: j,
                                                pids: [t]
                                            }));
                                        case 3:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })));
                            return function(t) {
                                return e.apply(this, arguments)
                            }
                        }(),
                        B = Object(ce.useCallback)((function() {
                            var e = Object(ge.c)(g);
                            return e.gt(0) && e.lt(1e-7) ? e.toFixed(10, le.BigNumber.ROUND_DOWN) : e.gt(0) && e.lt(1e-4) ? Object(ge.f)(g).toLocaleString() : e.toFixed(3, le.BigNumber.ROUND_DOWN)
                        }), [g]),
                        N = Object(je.cc)(Object(Ae.jsx)(Ct, {
                            max: f,
                            lpPrice: w,
                            lpLabel: i,
                            apr: n,
                            displayApr: l,
                            stakedBalance: g,
                            onConfirm: D,
                            tokenName: a,
                            multiplier: r,
                            addLiquidityUrl: A,
                            cakePrice: S
                        })),
                        R = Object(ae.a)(N, 1)[0],
                        P = Object(je.cc)(Object(Ae.jsx)(Tt, {
                            max: g,
                            onConfirm: q,
                            tokenName: a
                        })),
                        z = Object(ae.a)(P, 1)[0],
                        L = Object(rt.b)(),
                        F = Bt(e).onApprove,
                        J = Object(ce.useCallback)(Object(et.a)($e.a.mark((function e() {
                            return $e.a.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.prev = 0, O(!0), e.next = 4, F();
                                    case 4:
                                        L(Object(at.b)({
                                            account: j,
                                            pids: [t]
                                        })), e.next = 11;
                                        break;
                                    case 7:
                                        e.prev = 7, e.t0 = e.catch(0), b(d("Error"), d("Please try again. Confirm the transaction and make sure you are paying enough gas!")), console.error(e.t0);
                                    case 11:
                                        return e.prev = 11, O(!1), e.finish(11);
                                    case 14:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, null, [
                                [0, 7, 11, 14]
                            ])
                        }))), [F, L, j, t, d, b]);
                    return j ? C ? g.gt(0) ? Object(Ae.jsxs)(lt, {
                        children: [Object(Ae.jsxs)(dt, {
                            children: [Object(Ae.jsx)(je.Jb, {
                                bold: !0,
                                textTransform: "uppercase",
                                color: "primary",
                                fontSize: "12px",
                                pr: "4px",
                                children: a
                            }), Object(Ae.jsx)(je.Jb, {
                                bold: !0,
                                textTransform: "uppercase",
                                color: "white",
                                fontSize: "12px",
                                children: d("Staked")
                            })]
                        }), Object(Ae.jsxs)(bt, {
                            children: [Object(Ae.jsxs)("div", {
                                children: [Object(Ae.jsx)(je.Q, {
                                    children: B()
                                }), g.gt(0) && w.gt(0) && Object(Ae.jsx)(tt.a, {
                                    fontSize: "12px",
                                    color: "textSubtle",
                                    decimals: 2,
                                    value: Object(ge.d)(w.times(g)),
                                    unit: " USD",
                                    prefix: "~"
                                })]
                            }), Object(Ae.jsxs)(Nt, {
                                children: [Object(Ae.jsx)(je.U, {
                                    variant: "secondary",
                                    onClick: z,
                                    mr: "6px",
                                    children: Object(Ae.jsx)(je.ib, {
                                        color: "primary",
                                        width: "14px"
                                    })
                                }), Object(Ae.jsx)(je.U, {
                                    variant: "secondary",
                                    onClick: R,
                                    disabled: ["history", "archived"].some((function(e) {
                                        return k.pathname.includes(e)
                                    })),
                                    children: Object(Ae.jsx)(je.a, {
                                        color: "primary",
                                        width: "14px"
                                    })
                                })]
                            })]
                        })]
                    }) : Object(Ae.jsxs)(lt, {
                        children: [Object(Ae.jsxs)(dt, {
                            children: [Object(Ae.jsx)(je.Jb, {
                                bold: !0,
                                textTransform: "uppercase",
                                color: "white",
                                fontSize: "12px",
                                pr: "4px",
                                children: d("Stake")
                            }), Object(Ae.jsx)(je.Jb, {
                                bold: !0,
                                textTransform: "uppercase",
                                color: "primary",
                                fontSize: "12px",
                                children: a
                            })]
                        }), Object(Ae.jsx)(bt, {
                            children: Object(Ae.jsx)(je.o, {
                                width: "100%",
                                onClick: R,
                                variant: "primary",
                                disabled: ["history", "archived"].some((function(e) {
                                    return k.pathname.includes(e)
                                })),
                                children: d("Stake LP")
                            })
                        })]
                    }) : o ? Object(Ae.jsxs)(lt, {
                        children: [Object(Ae.jsx)(dt, {
                            children: Object(Ae.jsx)(je.Jb, {
                                bold: !0,
                                textTransform: "uppercase",
                                color: "textSubtle",
                                fontSize: "12px",
                                children: d("Enable Farm")
                            })
                        }), Object(Ae.jsx)(bt, {
                            children: Object(Ae.jsx)(je.o, {
                                width: "100%",
                                disabled: x,
                                onClick: J,
                                variant: "secondary",
                                children: d("Enable")
                            })
                        })]
                    }) : Object(Ae.jsxs)(lt, {
                        children: [Object(Ae.jsx)(dt, {
                            children: Object(Ae.jsx)(je.Jb, {
                                bold: !0,
                                textTransform: "uppercase",
                                color: "textSubtle",
                                fontSize: "12px",
                                children: d("Start Farming")
                            })
                        }), Object(Ae.jsx)(bt, {
                            children: Object(Ae.jsx)(je.Bb, {
                                width: 180,
                                marginBottom: 28,
                                marginTop: 14
                            })
                        })]
                    }) : Object(Ae.jsxs)(lt, {
                        children: [Object(Ae.jsx)(dt, {
                            children: Object(Ae.jsx)(je.Jb, {
                                bold: !0,
                                textTransform: "uppercase",
                                color: "textSubtle",
                                fontSize: "12px",
                                children: d("Start Farming")
                            })
                        }), Object(Ae.jsx)(bt, {
                            children: Object(Ae.jsx)(ut.a, {
                                width: "100%"
                            })
                        })]
                    })
                },
                Pt = Object(pe.f)(y || (y = Object(ie.a)(["\n  from {\n    max-height: 0;\n  }\n  to {\n    max-height: 500px;\n  }\n"]))),
                zt = Object(pe.f)(k || (k = Object(ie.a)(["\n  from {\n    max-height: 500px;\n  }\n  to {\n    max-height: 0;\n  }\n"]))),
                Lt = pe.e.div(w || (w = Object(ie.a)(["\n  animation: ", ";\n  overflow: hidden;\n  background: ", ";\n  display: flex;\n  flex-direction: column-reverse;\n  padding: 24px;\n  margin: 8px;\n  border-radius: 6px;\n\n  ", " {\n    flex-direction: row;\n    padding: 16px 32px;\n    margin: 16px;\n  }\n"])), (function(e) {
                    return e.expanded ? Object(pe.d)(S || (S = Object(ie.a)(["\n          ", " 300ms linear forwards\n        "])), Pt) : Object(pe.d)(C || (C = Object(ie.a)(["\n          ", " 300ms linear forwards\n        "])), zt)
                }), (function(e) {
                    var t = e.theme;
                    return "".concat(t.colors.primary, "29")
                }), (function(e) {
                    return e.theme.mediaQueries.lg
                })),
                Ft = Object(pe.e)(je.Z)(T || (T = Object(ie.a)(["\n  font-weight: 400;\n"]))),
                Jt = pe.e.div(A || (A = Object(ie.a)(["\n  color: ", ";\n  align-items: center;\n  display: flex;\n  justify-content: space-between;\n\n  ", " {\n    justify-content: flex-start;\n  }\n"])), (function(e) {
                    return e.theme.colors.text
                }), (function(e) {
                    return e.theme.mediaQueries.sm
                })),
                Et = pe.e.div(D || (D = Object(ie.a)(["\n  display: flex;\n  align-items: center;\n  margin-top: 25px;\n\n  ", " {\n    margin-top: 16px;\n  }\n\n  > div {\n    height: 24px;\n    padding: 0 6px;\n    font-size: 14px;\n    margin-right: 4px;\n\n    svg {\n      width: 14px;\n    }\n  }\n"])), (function(e) {
                    return e.theme.mediaQueries.sm
                })),
                Ut = pe.e.div(q || (q = Object(ie.a)(["\n  display: flex;\n  flex-direction: column;\n\n  ", " {\n    flex-direction: row;\n    align-items: center;\n    flex-grow: 1;\n    flex-basis: 0;\n  }\n"])), (function(e) {
                    return e.theme.mediaQueries.sm
                })),
                Qt = pe.e.div(B || (B = Object(ie.a)(["\n  min-width: 200px;\n"]))),
                Mt = pe.e.div(N || (N = Object(ie.a)(["\n  display: block;\n\n  ", " {\n    display: none;\n  }\n"])), (function(e) {
                    return e.theme.mediaQueries.lg
                })),
                It = pe.e.div(R || (R = Object(ie.a)(["\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin: 4px 0;\n"]))),
                Wt = function(e) {
                    var t = e.details,
                        n = e.apr,
                        r = e.liquidity,
                        a = e.userDataReady,
                        i = e.expanded,
                        c = t,
                        s = Object(fe.b)().t,
                        o = "0X" !== c.multiplier,
                        l = c.quoteToken,
                        d = c.token,
                        b = c.dual,
                        j = c.lpSymbol && c.lpSymbol.toUpperCase().replace("PANCAKE", ""),
                        u = Ne({
                            quoteTokenAddress: l.address,
                            tokenAddress: d.address
                        }),
                        p = Object(Xe.a)(c.lpAddresses),
                        x = Object(Ve.e)(p, "address");
                    return Object(Ae.jsxs)(Lt, {
                        expanded: i,
                        children: [Object(Ae.jsxs)(Qt, {
                            children: [o && Object(Ae.jsx)(Jt, {
                                children: Object(Ae.jsx)(Ft, {
                                    href: "/liquidity/add/".concat(u),
                                    children: s("Get %symbol%", {
                                        symbol: j
                                    })
                                })
                            }), Object(Ae.jsx)(Ft, {
                                href: x,
                                children: s("View Contract")
                            }), Object(Ae.jsxs)(Et, {
                                children: [c.isCommunity ? Object(Ae.jsx)(Ze, {}) : Object(Ae.jsx)(Ye, {}), b ? Object(Ae.jsx)(_e, {}) : null]
                            })]
                        }), Object(Ae.jsxs)(Mt, {
                            children: [Object(Ae.jsxs)(It, {
                                children: [Object(Ae.jsx)(je.Jb, {
                                    children: s("APR")
                                }), Object(Ae.jsx)(ze, Object(re.a)({}, n))]
                            }), Object(Ae.jsxs)(It, {
                                children: [Object(Ae.jsx)(je.Jb, {
                                    children: s("Liquidity")
                                }), Object(Ae.jsx)(Ge, Object(re.a)({}, r))]
                            })]
                        }), Object(Ae.jsxs)(Ut, {
                            children: [Object(Ae.jsx)(jt, Object(re.a)(Object(re.a)({}, c), {}, {
                                userDataReady: a
                            })), Object(Ae.jsx)(Rt, Object(re.a)(Object(re.a)({}, c), {}, {
                                userDataReady: a,
                                lpLabel: j,
                                displayApr: n.value
                            }))]
                        })]
                    })
                },
                Ht = pe.e.div(P || (P = Object(ie.a)(["\n  font-size: 12px;\n  color: ", ";\n  text-align: left;\n"])), (function(e) {
                    return e.theme.colors.textSubtle
                })),
                Gt = pe.e.div(z || (z = Object(ie.a)(["\n  min-height: 24px;\n  display: flex;\n  align-items: center;\n"]))),
                Xt = function(e) {
                    var t = e.label,
                        n = void 0 === t ? "" : t,
                        r = e.children;
                    return Object(Ae.jsxs)("div", {
                        children: [n && Object(Ae.jsx)(Ht, {
                            children: n
                        }), Object(Ae.jsx)(Gt, {
                            children: r
                        })]
                    })
                },
                Vt = [{
                    id: 1,
                    name: "farm",
                    sortable: !0,
                    label: ""
                }, {
                    id: 2,
                    name: "earned",
                    sortable: !0,
                    label: "Earned"
                }, {
                    id: 3,
                    name: "apr",
                    sortable: !0,
                    label: "APR"
                }, {
                    id: 6,
                    name: "details",
                    sortable: !0,
                    label: ""
                }],
                Yt = [{
                    id: 1,
                    name: "farm",
                    sortable: !0,
                    label: ""
                }, {
                    id: 2,
                    name: "earned",
                    sortable: !0,
                    label: "Earned"
                }, {
                    id: 3,
                    name: "apr",
                    sortable: !0,
                    label: "APR"
                }, {
                    id: 4,
                    name: "liquidity",
                    sortable: !0,
                    label: "Liquidity"
                }, {
                    id: 6,
                    name: "details",
                    sortable: !0,
                    label: ""
                }],
                Zt = {
                    apr: ze,
                    farm: Fe,
                    earned: Ee,
                    details: Me,
                    liquidity: Ge
                },
                _t = pe.e.div(L || (L = Object(ie.a)(["\n  padding: 24px 0;\n  display: flex;\n  width: 100%;\n  align-items: center;\n  padding-right: 8px;\n\n  ", " {\n    padding-right: 32px;\n  }\n"])), (function(e) {
                    return e.theme.mediaQueries.xl
                })),
                Kt = pe.e.tr(F || (F = Object(ie.a)(["\n  cursor: pointer;\n  border-bottom: 1px solid ", ";\n"])), (function(e) {
                    return e.theme.colors.cardBorder
                })),
                $t = pe.e.td(J || (J = Object(ie.a)(["\n  padding: 16px 0 24px 16px;\n"]))),
                en = pe.e.td(E || (E = Object(ie.a)(["\n  padding-top: 16px;\n  padding-bottom: 24px;\n"]))),
                tn = pe.e.td(U || (U = Object(ie.a)(["\n  padding-top: 24px;\n"]))),
                nn = function(e) {
                    var t = e.details,
                        n = e.userDataReady,
                        r = !!Object(Oe.a)(t.pid).stakedBalance.toNumber(),
                        a = Object(ce.useState)(r),
                        i = Object(ae.a)(a, 2),
                        c = i[0],
                        s = i[1],
                        o = Te(c, 300),
                        l = Object(fe.b)().t,
                        d = function() {
                            s(!c)
                        };
                    Object(ce.useEffect)((function() {
                        s(r)
                    }), [r]);
                    var b = Object(je.bc)(),
                        j = b.isDesktop,
                        u = b.isMobile,
                        p = !j,
                        x = p ? Vt : Yt,
                        O = x.map((function(e) {
                            return e.name
                        }));
                    return Object(Ae.jsxs)(Ae.Fragment, {
                        children: [u ? Object(Ae.jsxs)(Kt, {
                            onClick: d,
                            children: [Object(Ae.jsxs)("td", {
                                children: [Object(Ae.jsx)("tr", {
                                    children: Object(Ae.jsx)(tn, {
                                        children: Object(Ae.jsx)(Xt, {
                                            children: Object(Ae.jsx)(Fe, Object(re.a)({}, e.farm))
                                        })
                                    })
                                }), Object(Ae.jsxs)("tr", {
                                    children: [Object(Ae.jsx)($t, {
                                        children: Object(Ae.jsx)(Xt, {
                                            label: l("Earned"),
                                            children: Object(Ae.jsx)(Ee, Object(re.a)(Object(re.a)({}, e.earned), {}, {
                                                userDataReady: n
                                            }))
                                        })
                                    }), Object(Ae.jsx)(en, {
                                        children: Object(Ae.jsx)(Xt, {
                                            label: l("APR"),
                                            children: Object(Ae.jsx)(ze, Object(re.a)(Object(re.a)({}, e.apr), {}, {
                                                hideButton: !0
                                            }))
                                        })
                                    })]
                                })]
                            }), Object(Ae.jsx)("td", {
                                children: Object(Ae.jsx)(_t, {
                                    children: Object(Ae.jsx)(Xt, {
                                        children: Object(Ae.jsx)(Me, {
                                            actionPanelToggled: c
                                        })
                                    })
                                })
                            })]
                        }) : Object(Ae.jsx)(Kt, {
                            onClick: d,
                            children: Object.keys(e).map((function(t) {
                                var r = O.indexOf(t);
                                if (-1 === r) return null;
                                switch (t) {
                                    case "details":
                                        return Object(Ae.jsx)("td", {
                                            children: Object(Ae.jsx)(_t, {
                                                children: Object(Ae.jsx)(Xt, {
                                                    children: Object(Ae.jsx)(Me, {
                                                        actionPanelToggled: c
                                                    })
                                                })
                                            })
                                        }, t);
                                    case "apr":
                                        return Object(Ae.jsx)("td", {
                                            children: Object(Ae.jsx)(_t, {
                                                children: Object(Ae.jsx)(Xt, {
                                                    label: l("APR"),
                                                    children: Object(Ae.jsx)(ze, Object(re.a)(Object(re.a)({}, e.apr), {}, {
                                                        hideButton: p
                                                    }))
                                                })
                                            })
                                        }, t);
                                    default:
                                        return Object(Ae.jsx)("td", {
                                            children: Object(Ae.jsx)(_t, {
                                                children: Object(Ae.jsx)(Xt, {
                                                    label: l(x[r].label),
                                                    children: se.a.createElement(Zt[t], Object(re.a)(Object(re.a)({}, e[t]), {}, {
                                                        userDataReady: n
                                                    }))
                                                })
                                            })
                                        }, t)
                                }
                            }))
                        }), o && Object(Ae.jsx)(Ae.Fragment, {
                            children: Object(Ae.jsx)("tr", {
                                children: Object(Ae.jsx)("td", {
                                    colSpan: 6,
                                    children: Object(Ae.jsx)(Wt, Object(re.a)(Object(re.a)({}, e), {}, {
                                        expanded: c
                                    }))
                                })
                            })
                        })]
                    })
                },
                rn = pe.e.div(Q || (Q = Object(ie.a)(["\n  filter: ", ";\n  width: 100%;\n  background: ", ";\n  border-radius: 16px;\n  margin: 16px 0;\n"])), (function(e) {
                    return e.theme.card.dropShadow
                }), (function(e) {
                    return e.theme.card.background
                })),
                an = pe.e.div(M || (M = Object(ie.a)(["\n  overflow: visible;\n  scroll-margin-top: 64px;\n\n  &::-webkit-scrollbar {\n    display: none;\n  }\n"]))),
                cn = pe.e.table(I || (I = Object(ie.a)(["\n  border-collapse: collapse;\n  font-size: 14px;\n  border-radius: 4px;\n  margin-left: auto;\n  margin-right: auto;\n  width: 100%;\n"]))),
                sn = pe.e.tbody(W || (W = Object(ie.a)(["\n  & tr {\n    td {\n      font-size: 16px;\n      vertical-align: middle;\n    }\n  }\n"]))),
                on = pe.e.div(H || (H = Object(ie.a)(["\n  position: relative;\n"]))),
                ln = pe.e.div(G || (G = Object(ie.a)(["\n  display: flex;\n  justify-content: center;\n  padding-top: 5px;\n  padding-bottom: 5px;\n"]))),
                dn = function(e) {
                    var t = Object(ce.useRef)(null),
                        n = Object(fe.b)().t,
                        r = e.data,
                        a = e.columns,
                        i = e.userDataReady,
                        c = Object(je.dc)({
                            columns: a,
                            data: r,
                            options: {
                                sortable: !0,
                                sortColumn: "farm"
                            }
                        }).rows;
                    return Object(Ae.jsx)(rn, {
                        id: "farms-table",
                        children: Object(Ae.jsxs)(on, {
                            children: [Object(Ae.jsx)(an, {
                                ref: t,
                                children: Object(Ae.jsx)(cn, {
                                    children: Object(Ae.jsx)(sn, {
                                        children: c.map((function(e) {
                                            return Object(ce.createElement)(nn, Object(re.a)(Object(re.a)({}, e.original), {}, {
                                                userDataReady: i,
                                                key: "table-row-".concat(e.id)
                                            }))
                                        }))
                                    })
                                })
                            }), Object(Ae.jsx)(ln, {
                                children: Object(Ae.jsxs)(je.o, {
                                    variant: "text",
                                    onClick: function() {
                                        t.current.scrollIntoView({
                                            behavior: "smooth"
                                        })
                                    },
                                    children: [n("To Top"), Object(Ae.jsx)(je.D, {
                                        color: "primary"
                                    })]
                                })
                            })]
                        })
                    })
                },
                bn = n(67),
                jn = pe.e.div(X || (X = Object(ie.a)(["\n  display: flex;\n  justify-content: center;\n  align-items: center;\n\n  a {\n    padding-left: 12px;\n    padding-right: 12px;\n  }\n"]))),
                un = function() {
                    var e, t = Object(oe.h)().url,
                        n = Object(oe.g)(),
                        r = Object(fe.b)().t;
                    switch (n.pathname) {
                        case "/farms":
                            e = 0;
                            break;
                        case "/farms/history":
                            e = 1;
                            break;
                        case "/farms/staked":
                            e = 2;
                            break;
                        default:
                            e = 0
                    }
                    return Object(Ae.jsx)(jn, {
                        children: Object(Ae.jsxs)(je.p, {
                            activeIndex: e,
                            scale: "sm",
                            variant: "primary",
                            children: [Object(Ae.jsx)(je.q, {
                                as: bn.a,
                                to: "".concat(t),
                                children: r("Live")
                            }), Object(Ae.jsx)(je.q, {
                                id: "finished-farms-button",
                                as: bn.a,
                                to: "".concat(t, "/history"),
                                children: r("Archive")
                            }), Object(Ae.jsx)(je.q, {
                                as: bn.a,
                                to: "".concat(t, "/staked"),
                                children: r("My farm")
                            })]
                        })
                    })
                },
                pn = pe.e.div(V || (V = Object(ie.a)(["\n  border-top: 2px dashed ", ";\n  margin: 20px 0;\n  opacity: 0.5;\n  width: 100%;\n"])), (function(e) {
                    return e.theme.colors.blue500
                })),
                xn = pe.e.div(Y || (Y = Object(ie.a)(["\n  @media screen and (min-width: 1400px) {\n    position: sticky;\n    top: 0;\n    left: 0;\n  }\n"]))),
                On = function(e) {
                    var t = Object.assign({}, e),
                        n = Object(fe.b)().t;
                    return Object(Ae.jsx)(xn, Object(re.a)(Object(re.a)({}, t), {}, {
                        children: Object(Ae.jsx)(je.s, {
                            background: "linear-gradient(167.09deg, #3E56FF 1.17%, #061BDA 97.46%)",
                            p: 0,
                            children: Object(Ae.jsxs)(je.n, {
                                p: "32px",
                                children: [Object(Ae.jsx)(je.Jb, {
                                    fontSize: "20px",
                                    fontWeight: "500",
                                    mb: "10px",
                                    children: n("Nomiswap extra rewards")
                                }), Object(Ae.jsx)(je.Jb, {
                                    fontSize: "14px",
                                    style: {
                                        opacity: .5
                                    },
                                    children: n("NMX token and its farming/staking is utilitarian and gives unique rewards.")
                                }), Object(Ae.jsx)(pn, {}), Object(Ae.jsx)(je.Hb, {
                                    variant: "success",
                                    children: "Soon"
                                })]
                            })
                        })
                    }))
                },
                mn = n(144),
                hn = n(166),
                fn = Object(pe.e)(je.O)(Z || (Z = Object(ie.a)(["\n  background-size: cover;\n  background-image: url(/images/farming/stakeBanner.png);\n  align-self: stretch;\n  padding-right: 20px;\n  padding-left: 20px;\n  align-items: center;\n"]))),
                gn = Object(pe.e)(je.Hb)(_ || (_ = Object(ie.a)(["\n  display: inline-flex;\n  background-image: linear-gradient(92deg, #44b0fe 12%, #c316ff 95%);\n"]))),
                vn = function() {
                    Object(hn.c)();
                    var e = Object(hn.e)(0).pool;
                    return Object(Ae.jsx)(je.s, {
                        withoutBorder: !0,
                        background: "linear-gradient(109deg, #783BFF 34%, #410BB9 100%)",
                        children: Object(Ae.jsxs)(je.O, {
                            alignItems: "center",
                            children: [Object(Ae.jsxs)(je.O, {
                                py: "20px",
                                pl: "20px",
                                flexDirection: "column",
                                children: [Object(Ae.jsx)(je.Jb, {
                                    fontSize: "18px",
                                    semibold: !0,
                                    children: "Earn more NMX in Launchpool"
                                }), Object(Ae.jsx)(je.O, {
                                    alignItems: "center",
                                    children: Object(Ae.jsxs)(je.Jb, {
                                        fontSize: "14px",
                                        children: ["Stake your NMX with", " ", Object(Ae.jsxs)(gn, {
                                            fontSize: "14px",
                                            fontWeight: 600,
                                            children: ["APR", (null === e || void 0 === e ? void 0 : e.apr) ? Object(Ae.jsx)(tt.a, {
                                                color: "white",
                                                ml: "6px",
                                                value: e.apr,
                                                decimals: 0,
                                                unit: "%",
                                                fontWeight: 600
                                            }) : Object(Ae.jsx)(je.Bb, {
                                                width: "30px",
                                                height: "18px",
                                                m: "3px"
                                            })]
                                        })]
                                    })
                                })]
                            }), Object(Ae.jsx)(fn, {
                                children: Object(Ae.jsx)(je.o, {
                                    style: {
                                        whiteSpace: "nowrap"
                                    },
                                    scale: "sm",
                                    as: bn.a,
                                    to: "/pools",
                                    children: "Stake now"
                                })
                            })]
                        })
                    })
                },
                yn = pe.e.div(K || (K = Object(ie.a)(["\n  display: grid;\n  grid-gap: 28px;\n  grid-template-columns: 1fr;\n\n  @media screen and (min-width: 1400px) {\n    grid-template-columns: 305px auto;\n    position: relative;\n  }\n"]))),
                kn = pe.e.div($ || ($ = Object(ie.a)(["\n  display: flex;\n  width: 100%;\n  align-items: end;\n  position: relative;\n\n  justify-content: space-between;\n  flex-direction: column;\n\n  ", " {\n    flex-direction: row;\n    flex-wrap: wrap;\n  }\n"])), (function(e) {
                    return e.theme.mediaQueries.lg
                })),
                wn = pe.e.div(ee || (ee = Object(ie.a)(["\n  > ", " {\n    font-size: 12px;\n  }\n"])), je.Jb),
                Sn = pe.e.div(te || (te = Object(ie.a)(["\n  display: flex;\n  align-items: center;\n  width: 100%;\n  padding: 20px 0;\n\n  ", " {\n    width: auto;\n    padding: 0;\n  }\n"])), (function(e) {
                    return e.theme.mediaQueries.lg
                })),
                Cn = pe.e.div(ne || (ne = Object(ie.a)(["\n  flex-wrap: wrap;\n  justify-content: space-between;\n  display: flex;\n  align-items: center;\n  width: 100%;\n\n  > div {\n    padding: 8px 0;\n  }\n\n  ", " {\n    justify-content: flex-start;\n    width: auto;\n\n    > div {\n      padding: 0;\n    }\n  }\n"])), (function(e) {
                    return e.theme.mediaQueries.lg
                })),
                Tn = function() {
                    var e = Object(oe.g)().pathname,
                        t = Object(fe.b)().t,
                        n = Object(Oe.b)(),
                        r = n.data,
                        a = n.userDataLoaded,
                        i = Object(me.a)(),
                        c = Object(ce.useState)(""),
                        s = Object(ae.a)(c, 2),
                        o = s[0],
                        l = s[1],
                        d = Object(be.c)().account,
                        b = Object(ce.useState)("hot"),
                        j = Object(ae.a)(b, 2),
                        u = j[0],
                        p = j[1],
                        x = Object(he.a)(),
                        O = x.observerRef,
                        m = x.isIntersecting,
                        h = Object(ce.useRef)(0),
                        f = e.includes("archived"),
                        g = e.includes("history"),
                        v = e.includes("staked"),
                        y = !g && !f;
                    Object(Oe.f)(f);
                    var k = !d || !!d && a,
                        w = r.filter((function(e) {
                            return 0 !== e.pid && "0X" !== e.multiplier && !Object(ke.a)(e.pid)
                        })),
                        S = r.filter((function(e) {
                            return 0 !== e.pid && "0X" === e.multiplier && !Object(ke.a)(e.pid)
                        })),
                        C = r.filter((function(e) {
                            return Object(ke.a)(e.pid)
                        })),
                        T = r.filter((function(e) {
                            return e.userData && new de.a(e.userData.stakedBalance).isGreaterThan(0)
                        })),
                        A = Object(ce.useCallback)((function(e) {
                            var t = e.map((function(e) {
                                if (!e.lpTotalInQuoteToken || !e.quoteTokenPriceBusd) return e;
                                var t = new de.a(e.lpTotalInQuoteToken).times(e.quoteTokenPriceBusd),
                                    n = y ? Object(ve.a)(new de.a(e.tokensPerSec), new de.a(null === i || void 0 === i ? void 0 : i.toFixed(2)), t, e.lpAddresses[ue.a.MAINNET]) : {
                                        nmxRewardsApr: 0,
                                        lpRewardsApr: 0
                                    },
                                    r = n.nmxRewardsApr,
                                    a = n.lpRewardsApr;
                                return Object(re.a)(Object(re.a)({}, e), {}, {
                                    apr: r,
                                    lpRewardsApr: a,
                                    liquidity: t
                                })
                            }));
                            if (o) {
                                var n = Object(we.a)(o.toLowerCase());
                                t = t.filter((function(e) {
                                    return Object(we.a)(e.lpSymbol.toLowerCase()).includes(n)
                                }))
                            }
                            return t
                        }), [i, o, y]),
                        D = Object(ce.useState)(12),
                        q = Object(ae.a)(D, 2),
                        B = q[0],
                        N = q[1],
                        R = Object(ce.useMemo)((function() {
                            var e = [];
                            return y && (e = A(w)), g && (e = A(S)), f && (e = A(C)), v && (e = A(T)),
                                function(e) {
                                    switch (u) {
                                        case "apr":
                                            return Object(ye.orderBy)(e, (function(e) {
                                                return e.apr + e.lpRewardsApr
                                            }), "desc");
                                        case "earned":
                                            return Object(ye.orderBy)(e, (function(e) {
                                                return e.userData ? Number(e.userData.earnings) : 0
                                            }), "desc");
                                        case "liquidity":
                                            return Object(ye.orderBy)(e, (function(e) {
                                                return Number(e.liquidity)
                                            }), "desc");
                                        default:
                                            return e
                                    }
                                }(e).slice(0, B)
                        }), [u, w, A, S, C, y, g, f, v, T, B]);
                    h.current = R.length, Object(ce.useEffect)((function() {
                        m && N((function(e) {
                            return e <= h.current ? e + 12 : e
                        }))
                    }), [m]);
                    var P = R.map((function(e) {
                        var t, n, r = e.token,
                            a = e.quoteToken,
                            c = r.address,
                            s = a.address,
                            o = e.lpSymbol && e.lpSymbol.split(" ")[0].toUpperCase().replace("PANCAKE", "");
                        return {
                            apr: {
                                value: (t = e.apr, n = e.lpRewardsApr, t && n ? (t + n).toLocaleString("en-US", {
                                    maximumFractionDigits: 2
                                }) : t ? t.toLocaleString("en-US", {
                                    maximumFractionDigits: 2
                                }) : null),
                                pid: e.pid,
                                multiplier: e.multiplier,
                                lpLabel: o,
                                lpSymbol: e.lpSymbol,
                                tokenAddress: c,
                                quoteTokenAddress: s,
                                nmxPrice: new de.a(null === i || void 0 === i ? void 0 : i.toFixed(2)),
                                originalValue: e.apr
                            },
                            farm: {
                                label: o,
                                pid: e.pid,
                                token: e.token,
                                quoteToken: e.quoteToken
                            },
                            earned: {
                                earnings: Object(ge.d)(new de.a(e.userData.earnings)),
                                pid: e.pid
                            },
                            liquidity: {
                                liquidity: e.liquidity
                            },
                            details: e
                        }
                    }));
                    return Object(Ae.jsx)(Ae.Fragment, {
                        children: Object(Ae.jsxs)(xe.b, {
                            children: [Object(Ae.jsx)(mn.d, {
                                title: t("Farms"),
                                subtitle: t("Nomiswap farms offer multiple farming opportunities to you. Increase your farming rewards participating in Team Farming program and continuously grow your extra bonuses for unstoppable farming up to 10x."),
                                titleProps: {
                                    maxWidth: "532px"
                                },
                                mb: "24px",
                                children: Object(Ae.jsx)(vn, {})
                            }), Object(Ae.jsxs)(yn, {
                                children: [Object(Ae.jsx)(On, {}), Object(Ae.jsxs)(je.O, {
                                    flexDirection: "column",
                                    children: [Object(Ae.jsxs)(kn, {
                                        children: [Object(Ae.jsx)(Cn, {
                                            children: Object(Ae.jsx)(un, {})
                                        }), Object(Ae.jsxs)(Sn, {
                                            children: [Object(Ae.jsxs)(wn, {
                                                children: [Object(Ae.jsx)(je.Jb, {
                                                    textTransform: "uppercase",
                                                    children: t("Sort by")
                                                }), Object(Ae.jsx)(Ce.a, {
                                                    options: [{
                                                        label: t("Hot"),
                                                        value: "hot"
                                                    }, {
                                                        label: t("APR"),
                                                        value: "apr"
                                                    }, {
                                                        label: t("Earned"),
                                                        value: "earned"
                                                    }, {
                                                        label: t("Liquidity"),
                                                        value: "liquidity"
                                                    }],
                                                    onOptionChange: function(e) {
                                                        p(e.value)
                                                    }
                                                })]
                                            }), Object(Ae.jsxs)(wn, {
                                                style: {
                                                    marginLeft: 16
                                                },
                                                children: [Object(Ae.jsx)(je.Jb, {
                                                    textTransform: "uppercase",
                                                    children: t("Search")
                                                }), Object(Ae.jsx)(Se.a, {
                                                    onChange: function(e) {
                                                        l(e.target.value)
                                                    },
                                                    placeholder: t("Search Farms")
                                                })]
                                            })]
                                        })]
                                    }), function() {
                                        var e = Yt.map((function(e) {
                                            return {
                                                id: e.id,
                                                name: e.name,
                                                label: e.label,
                                                sort: function(t, n) {
                                                    switch (e.name) {
                                                        case "farm":
                                                            return n.id - t.id;
                                                        case "apr":
                                                            return t.original.apr.value && n.original.apr.value ? Number(t.original.apr.value) - Number(n.original.apr.value) : 0;
                                                        case "earned":
                                                            return t.original.earned.earnings - n.original.earned.earnings;
                                                        default:
                                                            return 1
                                                    }
                                                },
                                                sortable: e.sortable
                                            }
                                        }));
                                        return Object(Ae.jsx)(dn, {
                                            data: P,
                                            columns: e,
                                            userDataReady: k
                                        })
                                    }()]
                                })]
                            }), Object(Ae.jsx)("div", {
                                ref: O
                            })]
                        })
                    })
                }
        }
    }
]);
//# sourceMappingURL=7.31073fec.chunk.js.map