import BigNumber from 'bignumber.js'
import { DEFAULT_GAS_LIMIT, DEFAULT_TOKEN_DECIMAL } from 'config'
import { BIG_TEN } from 'utils/bigNumber'
import { StakingServiceContract } from 'utils/contractHelpers'
import getGasPrice from 'utils/getGasPrice'

const options = {
  gasLimit: DEFAULT_GAS_LIMIT,
}

export const stakeFarm = async (
  stakingServiceContract: StakingServiceContract,
  amount,
  decimals: number = DEFAULT_TOKEN_DECIMAL,
) => {
  const gasPrice = getGasPrice()
  const value = new BigNumber(amount).times(BIG_TEN.pow(decimals)).toString()

  const tx = await stakingServiceContract.stake(value, { ...options, gasPrice })
  const receipt = await tx.wait()
  return receipt.status
}

export const unstakeFarm = async (
  stakingServiceContract: StakingServiceContract,
  amount,
  decimals: number = DEFAULT_TOKEN_DECIMAL,
) => {
  const gasPrice = getGasPrice()

  const value = new BigNumber(amount).times(BIG_TEN.pow(decimals)).toString()

  const tx = await stakingServiceContract.unstake(value, { ...options, gasPrice })
  const receipt = await tx.wait()
  return receipt.status
}

export const harvestFarm = async (stakingServiceContract: StakingServiceContract) => {
  const gasPrice = getGasPrice()

  const tx = await stakingServiceContract.claimReward({ ...options, gasPrice })
  const receipt = await tx.wait()
  return receipt.status
}
