import BigNumber from 'bignumber.js'
import { SEC_PER_YEAR } from 'config'
import lpAprs from 'config/constants/lpAprs.json'

/**
 * Get the APR value in %
 * @param stakingTokenPrice Token price in the same quote currency
 * @param rewardTokenPrice Token price in the same quote currency
 * @param totalStaked Total amount of stakingToken in the pool
 * @param tokenPerSec Amount of new cake allocated to the pool for each sec
 * @returns Null if the APR is NaN or infinite.
 */
export const getPoolApr = (
  stakingTokenPrice: number,
  rewardTokenPrice: number,
  totalStaked: number,
  tokenPerSec: BigNumber,
): number => {
  const totalRewardPricePerYear = new BigNumber(rewardTokenPrice).times(tokenPerSec).times(SEC_PER_YEAR)
  const totalStakingTokenInPool = new BigNumber(stakingTokenPrice).times(totalStaked)
  const apr = totalRewardPricePerYear.div(totalStakingTokenInPool).times(100)
  return apr.isNaN() || !apr.isFinite() ? null : apr.toNumber()
}

/**
 * Get farm APR value in %
 * @param tokenPerSec allocationPoint / totalAllocationPoint
 * @param nmxPriceUsd Cake price in USD
 * @param poolLiquidityUsd Total pool liquidity in USD
 * @param lpAddress Farm Address
 * @returns Farm Apr
 */
export const getFarmApr = (
  tokenPerSec: BigNumber,
  nmxPriceUsd: BigNumber,
  poolLiquidityUsd: BigNumber,
  lpAddress: string,
): { nmxRewardsApr: number; lpRewardsApr: number } => {
  const yearlyNmxRewardAllocation = tokenPerSec ? tokenPerSec.times(SEC_PER_YEAR) : new BigNumber(NaN)
  const nmxRewardsApr = yearlyNmxRewardAllocation.times(nmxPriceUsd).div(poolLiquidityUsd).times(100)
  let nmxRewardsAprAsNumber = null
  if (!nmxRewardsApr.isNaN() && nmxRewardsApr.isFinite()) {
    nmxRewardsAprAsNumber = nmxRewardsApr.toNumber()
  }
  const lpRewardsApr = lpAprs[lpAddress?.toLocaleLowerCase()] ?? 0
  return { nmxRewardsApr: nmxRewardsAprAsNumber, lpRewardsApr }
}

export default null
