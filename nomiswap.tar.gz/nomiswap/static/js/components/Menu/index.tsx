import React from 'react'
import styled from 'styled-components'
import { Menu as UiKitMenu, CogIcon, Flex, Box } from '@nominex/dex-uikit'
// import { useWeb3React } from '@web3-react/core'
// import { languageList } from 'config/localization/languages'
import { useTranslation } from 'contexts/Localization'
import { usePriceCakeBusd } from 'state/farms/hooks'
import GlobalSettings from './GlobalSettings'
import { WalletMenu } from './WalletMenu'
import { NmxInfoDropdown, NmxInfoType } from './NmxInfoDropdown'
// import ExtraRewardsDropdown from './ExtraRewardsDropdown'

const Divider = styled(Box)`
  width: 1px;
  height: 36px;
  background-color ${({ theme }) => `${theme.colors.white}1A`};
`

// TODO: Remove when data will be available
const nmxInfo: NmxInfoType = {
  balance: 124.04,
  totalLiquidity: 122323,
  balanceInLaunchPools: 543534,
  balanceInFarming: 543534,
  dailyProfit: 54353,
  dailyProfitInUsdt: 65656565,
  apr: 435,
  isConnected: true,
}

const UserMenu = () => {
  // const { account } = useWeb3React()

  return (
    <Flex alignItems="center">
      <NmxInfoDropdown nmxInfo={nmxInfo} />
      {/* {account && <ExtraRewardsDropdown ml="12px" />} */}
      <Divider mx="16px" />
      <WalletMenu />
      <Divider ml="16px" mr="4px" />
      <GlobalSettings IconComponent={CogIcon} />
    </Flex>
  )
}

const Menu = (props) => {
  const cakePriceUsd = usePriceCakeBusd()
  const { t } = useTranslation()

  return (
    <UiKitMenu
      userMenu={<UserMenu />}
      isDark
      // toggleTheme={toggleTheme}
      // currentLang={currentLanguage.code}
      // langs={languageList}
      // setLang={setLanguage}
      cakePriceUsd={cakePriceUsd.toNumber()}
      links={[]}
      activeItem=""
      footerMainLabel={t('Bringing the superb crypto trading experience to newcomers and experts')}
      {...props}
    />
  )
}

export default Menu
