import React from 'react'
import styled from 'styled-components'
import {
  BinanceIcon,
  Flex,
  Box,
  Text,
  ArrowDropDownIcon,
  Button,
  UserMenuProps,
  BaseMenu,
  UserMenuItem,
  UserMenuDivider,
  LogoutIcon,
  useModal,
  WarningIcon,
  useMatchBreakpoints,
} from '@nominex/dex-uikit'
import { useWeb3React } from '@web3-react/core'
import { useTranslation } from 'contexts/Localization'
import { FetchStatus, useGetBnbBalance } from 'hooks/useTokenBalance'
import useAuth from 'hooks/useAuth'
import WalletUserMenuItem from '../UserMenu/WalletUserMenuItem'
import WalletModal, { WalletView, LOW_BNB_BALANCE } from '../UserMenu/WalletModal'
import ConnectWalletButton from '../../ConnectWalletButton'
import CircleLoader from '../../Loader/CircleLoader'

const StyledMenu = styled.div`
  background-color: ${({ theme }) => theme.card.background};
  border: 1px solid ${({ theme }) => theme.colors.cardBorder};
  border-radius: 16px;
  overflow: hidden;
  width: 280px;
`

const PendingButton = ({ pendingTotal }) => {
  const { t } = useTranslation()

  return (
    <Button variant="success" scale="sm">
      <CircleLoader stroke="white" />
      <Text ml="8px" fontSize="14px" fontWeight="600">
        {pendingTotal} {t('pending')}...
      </Text>
    </Button>
  )
}

const ErrorButton = () => {
  const { t } = useTranslation()

  return (
    <Button variant="danger" scale="sm">
      <WarningIcon width="24px" color="contrast" />
      <Text ml="8px" fontSize="14px" fontWeight="600">
        {t('Error network')}
      </Text>
    </Button>
  )
}

const WalletMenuTrigger: React.FC<UserMenuProps> = ({ account }) => {
  const { t } = useTranslation()
  const { isMobile } = useMatchBreakpoints()

  const accountEllipsis = account ? `${account.substring(0, 6)}...${account.substring(account.length - 4)}` : null

  return (
    <Box>
      <Flex alignItems="center">
        <Box height="32px" background="#FFD0291A" borderRadius="6px" p="6px">
          <BinanceIcon />
        </Box>
        {!isMobile && (
          <Box ml="8px">
            <Text color="contrast" fontSize="11px">
              {t('Binance smart chain')}
            </Text>
            <Text color="contrast" fontWeight="600" fontSize="13px">
              {accountEllipsis}
            </Text>
          </Box>
        )}
        <ArrowDropDownIcon width="12px" color="placeholder" ml="8px" />
      </Flex>
    </Box>
  )
}

const WalletMenu: React.FC<UserMenuProps> = ({ ...props }) => {
  const { t } = useTranslation()

  const { balance, fetchStatus } = useGetBnbBalance()
  const hasLowBnbBalance = fetchStatus === FetchStatus.SUCCESS && balance.lte(LOW_BNB_BALANCE)
  const [onPresentWalletModal] = useModal(<WalletModal initialView={WalletView.WALLET_INFO} />)
  const [onPresentTransactionModal] = useModal(<WalletModal initialView={WalletView.TRANSACTIONS} />)
  const { logout } = useAuth()
  const { account } = useWeb3React()
  const pending = false
  const hasError = false
  const pendingTotal = 1

  if (!account) {
    return <ConnectWalletButton scale="sm" />
  }

  if (pending) {
    return <PendingButton pendingTotal={pendingTotal} />
  }

  if (hasError) {
    return <ErrorButton />
  }

  return (
    <BaseMenu
      component={<WalletMenuTrigger account={account} />}
      isOpen={false}
      options={{ placement: 'bottom-end' }}
      {...props}
    >
      <StyledMenu>
        <WalletUserMenuItem hasLowBnbBalance={hasLowBnbBalance} onPresentWalletModal={onPresentWalletModal} />
        <UserMenuItem as="button" onClick={onPresentTransactionModal}>
          {t('Transactions')}
        </UserMenuItem>
        <UserMenuDivider />
        <UserMenuItem as="button" onClick={logout}>
          <Flex alignItems="center" justifyContent="space-between" width="100%">
            {t('Disconnect')}
            <LogoutIcon />
          </Flex>
        </UserMenuItem>
      </StyledMenu>
    </BaseMenu>
  )
}

export default WalletMenu
