import React from 'react'
import { Flex, IconButton, useModal } from '@nominex/dex-uikit'
import SettingsModal from './SettingsModal'

const GlobalSettings = ({ IconComponent }) => {
  const [onPresentSettingsModal] = useModal(<SettingsModal />)

  return (
    <Flex>
      <IconButton onClick={onPresentSettingsModal} variant="text" scale="sm" id="open-settings-dialog-button">
        <IconComponent height={20} width={20} color="textSubtle" />
      </IconButton>
    </Flex>
  )
}

export default GlobalSettings
