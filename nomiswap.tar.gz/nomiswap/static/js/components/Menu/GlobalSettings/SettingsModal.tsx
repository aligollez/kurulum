import React, { useState } from 'react'
import styled from 'styled-components'
import { Text, Toggle, Flex, Modal, InjectedModalProps } from '@nominex/dex-uikit'
import {
  useAudioModeManager,
  useExpertModeManager,
  useUserExpertModeAcknowledgementShow,
  useUserSingleHopOnly,
} from 'state/user/hooks'
import { useTranslation } from 'contexts/Localization'
import { useSwapActionHandlers } from 'state/swap/hooks'
import useTheme from 'hooks/useTheme'
import QuestionHelper from '../../QuestionHelper'
import TransactionSettings from './TransactionSettings'
import ExpertModal from './ExpertModal'
import GasSettings from './GasSettings'

const ScrollableContainer = styled(Flex)`
  flex-direction: column;
  max-height: 400px;
  ${({ theme }) => theme.mediaQueries.sm} {
    max-height: none;
  }
`

const SettingsModal: React.FC<InjectedModalProps> = ({ onDismiss }) => {
  const [showConfirmExpertModal, setShowConfirmExpertModal] = useState(false)
  const [showExpertModeAcknowledgement, setShowExpertModeAcknowledgement] = useUserExpertModeAcknowledgementShow()
  const [expertMode, toggleExpertMode] = useExpertModeManager()
  const [singleHopOnly, setSingleHopOnly] = useUserSingleHopOnly()
  const [audioPlay, toggleSetAudioMode] = useAudioModeManager()
  const { onChangeRecipient } = useSwapActionHandlers()

  const { t } = useTranslation()
  const { theme } = useTheme()

  if (showConfirmExpertModal) {
    return (
      <ExpertModal
        setShowConfirmExpertModal={setShowConfirmExpertModal}
        onDismiss={onDismiss}
        setShowExpertModeAcknowledgement={setShowExpertModeAcknowledgement}
      />
    )
  }

  const handleExpertModeToggle = () => {
    if (expertMode) {
      onChangeRecipient(null)
      toggleExpertMode()
    } else if (!showExpertModeAcknowledgement) {
      onChangeRecipient(null)
      toggleExpertMode()
    } else {
      setShowConfirmExpertModal(true)
    }
  }

  return (
    <Modal title={t('Settings')} onDismiss={onDismiss} style={{ maxWidth: '460px' }}>
      <ScrollableContainer>
        <Flex pb="24px" pt="12px" flexDirection="column">
          <GasSettings />
        </Flex>
        <Flex pb="24px" flexDirection="column">
          <TransactionSettings />
        </Flex>
        <Flex
          justifyContent="flex-start"
          alignItems="center"
          mb="24px"
          pt="24px"
          borderTop={`1px ${theme.colors.cardBorder} solid`}
        >
          <Toggle id="toggle-expert-mode-button" scale="sm" checked={expertMode} onChange={handleExpertModeToggle} />
          <Flex alignItems="center" ml="12px">
            <Text fontSize="14px" semibold>
              {t('Expert Mode')}
            </Text>
            <QuestionHelper
              text={t('Bypasses confirmation modals and allows high slippage trades. Use at your own risk.')}
              placement="top-start"
              ml="4px"
            />
          </Flex>
        </Flex>
        <Flex justifyContent="flex-start" alignItems="center" mb="24px">
          <Toggle
            id="toggle-disable-multihop-button"
            checked={singleHopOnly}
            scale="sm"
            onChange={() => {
              setSingleHopOnly(!singleHopOnly)
            }}
          />
          <Flex alignItems="center" ml="12px">
            <Text fontSize="14px" semibold>
              {t('Disable Multihops')}
            </Text>
            <QuestionHelper text={t('Restricts swaps to direct pairs only.')} placement="top-start" ml="4px" />
          </Flex>
        </Flex>
        <Flex justifyContent="flex-start" alignItems="center" pb="24px">
          <Toggle checked={audioPlay} scale="sm" onChange={toggleSetAudioMode} />
          <Flex alignItems="center" ml="12px">
            <Text fontSize="14px" semibold>
              {t('Flippy sounds')}
            </Text>
            <QuestionHelper
              text={t('Fun sounds to make a truly immersive trading experience')}
              placement="top-start"
              ml="4px"
            />
          </Flex>
        </Flex>
      </ScrollableContainer>
    </Modal>
  )
}

export default SettingsModal
