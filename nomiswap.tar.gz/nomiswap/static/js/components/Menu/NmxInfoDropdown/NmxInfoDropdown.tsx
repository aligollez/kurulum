import React, { useMemo } from 'react'
import styled from 'styled-components'
// import { useHistory } from 'react-router-dom'
import { Text, Flex, NmxIcon } from '@nominex/dex-uikit'
// import { useTranslation } from 'contexts/Localization'
import { useNmxUsdtPrice } from 'hooks/useBusdPrice'

const StyledNmxDropdownTrigger = styled(Flex)`
  width: max-content;
  align-items: center;
  border-radius: 6px;
  height: 36px;
  padding: 0 10px;
  background: ${({ theme }) => theme.colors.gradients.primary};
`

// const StyledBalanceBlock = styled(Flex)`
//   align-items: center;
//   border-radius: 12px;
//   background: ${({ theme }) => theme.colors.gradients.primary};
//   padding: 20px 16px;
// `

// const StyledDropdownItem = styled(Flex)`
//   justify-content: space-between;
// `

// const Divider = styled.div`
//   width: 100%;
//   height: 1px;
//   background-color: ${({ theme }) => theme.colors.cardBorder};
//   margin: 16px 0;
// `

const NmxDropdownTrigger: React.FC<{ nmxPrice: string }> = ({ nmxPrice }) => (
  <StyledNmxDropdownTrigger>
    <NmxIcon width="18px" />
    <Text ml="6px" mr="4px" fontWeight="600" color="contrast">
      ${nmxPrice}
    </Text>
    {/* <ArrowDropDownIcon width="10px" color="placeholder" /> */}
  </StyledNmxDropdownTrigger>
)

// const StyledContainer = styled(Box)`
//   width: 376px;
//   border-radius: 12px;
//   background: ${({ theme }) => theme.colors.gradients.primary};
//   padding: 2px;
// `

export type NmxInfoType = {
  balance: number
  totalLiquidity: number
  balanceInLaunchPools: number
  balanceInFarming: number
  dailyProfit: number
  dailyProfitInUsdt: number
  apr: number
  isConnected: boolean
}

interface NmxInfoDropdownProps {
  nmxInfo: NmxInfoType
}

const NmxInfoDropdown: React.FC<NmxInfoDropdownProps> = () => {
  // const theme = useTheme()
  // const history = useHistory()
  // const { t } = useTranslation()
  const nmxPrice = useNmxUsdtPrice()
  const nmxPriceStr = useMemo(() => nmxPrice?.toFixed(2) ?? '', [nmxPrice])

  return (
    <>
      <NmxDropdownTrigger nmxPrice={nmxPriceStr} />
      {/* <BaseMenu
      component={<NmxDropdownTrigger nmxPrice={nmxPriceStr} />}
      isOpen={false}
      options={{ placement: 'bottom-end' }}
    >
      <StyledContainer>
        <Box borderRadius="12px" background={theme.colors.backgroundAlt} p="22px 14px">
          <Text mb="10px" fontWeight="600" fontSize="14px" color="contrast">
            {t('Your NMX breakdown')}
          </Text>
          <StyledBalanceBlock>
            <NmxIcon width="32px" height="32px" />
            <Box ml="12px">
              <Text mb="2px" fontSize="12px" style={{ opacity: '.7' }} color="contrast">
                {t('Your balance')}
              </Text>
              <Text fontWeight="600" fontSize="22px" color="contrast">
                {nmxInfo.balance} NMX
              </Text>
            </Box>
          </StyledBalanceBlock>
          <StyledDropdownItem mt="20px">
            <Text fontSize="14px" color="placeholder">
              {t('NMX price')}
            </Text>
            <Text fontWeight="600" fontSize="14px" color="contrast">
              ${nmxPriceStr}
            </Text>
          </StyledDropdownItem>
          <StyledDropdownItem mt="8px">
            <Text fontSize="14px" color="placeholder">
              {t('Total liquidity')}
            </Text>
            <Flex>
              <Text fontWeight="600" fontSize="14px" color="contrast">
                ${nmxInfo.totalLiquidity}
              </Text>
            </Flex>
          </StyledDropdownItem>
          {nmxInfo.isConnected && (
            <>
              <Divider />
              <StyledDropdownItem>
                <Text fontSize="14px" color="placeholder">
                  {t('Your $ in launchpools')}
                </Text>
                <Flex alignItems="center">
                  <Text fontWeight="600" mr="4px" fontSize="14px" color="contrast">
                    ≈${nmxInfo.balanceInLaunchPools}
                  </Text>
                </Flex>
              </StyledDropdownItem>
              <StyledDropdownItem mt="8px">
                <Text fontSize="14px" color="placeholder">
                  {t('Your $ in farming')}
                </Text>
                <Flex alignItems="center">
                  <Text fontWeight="600" mr="4px" fontSize="14px" color="contrast">
                    ≈${nmxInfo.balanceInFarming}
                  </Text>
                </Flex>
              </StyledDropdownItem>
              <Divider />
              <StyledDropdownItem>
                <Text fontSize="14px" color="placeholder">
                  {t('Daily profit')}
                </Text>
                <Flex flexDirection="column" alignItems="flex-end">
                  <Text fontWeight="600" fontSize="14px" color="success">
                    {nmxInfo.dailyProfit} NMX
                  </Text>
                  <Text fontSize="10px" color="placeholder">
                    ≈${nmxInfo.dailyProfitInUsdt}
                  </Text>
                </Flex>
              </StyledDropdownItem>
              <StyledDropdownItem mt="8px">
                <Text fontSize="14px" color="placeholder">
                  {t('APR')}
                </Text>
                <Text fontWeight="600" fontSize="14px" color="contrast">
                  {nmxInfo.apr}%
                </Text>
              </StyledDropdownItem>
              <Flex mt="16px">
                <Button onClick={() => history.push('/farms')} width="100%" mr="12px">
                  {t('Farming')}
                </Button>
                <Button onClick={() => history.push('/pools')} width="100%">
                  {t('Launchpools')}
                </Button>
              </Flex>
            </>
          )}
        </Box>
      </StyledContainer> 
    </BaseMenu>
    */}
    </>
  )
}

export default NmxInfoDropdown
