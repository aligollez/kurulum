import React from 'react'
import { BoxProps, Flex, TokenImage } from '@nominex/dex-uikit'
import { Currency } from '@nominex/nomiswap-sdk'

type DoubleCurrencyLogoProps = {
  margin?: boolean
  size?: number
  currency0?: Currency
  currency1?: Currency
} & BoxProps

export default function DoubleCurrencyLogo({ currency0, currency1, size = 20, ...props }: DoubleCurrencyLogoProps) {
  return (
    <Flex alignItems="center" justifyItems="center" {...props}>
      {currency0 && <TokenImage symbol={currency0.symbol} height={size} width={size} style={{ marginRight: '4px' }} />}
      {currency1 && <TokenImage symbol={currency1.symbol} height={size} width={size} />}
    </Flex>
  )
}
