import React from 'react'
import styled from 'styled-components'
import { LoadingIcon } from '@nominex/dex-uikit'
import Page from '../Layout/Page'

const Wrapper = styled(Page)`
  display: flex;
  justify-content: center;
  align-items: center;
`

const PageLoader: React.FC = () => {
  return (
    <Wrapper>
      <LoadingIcon color="blue500" width="128px" />
    </Wrapper>
  )
}

export default PageLoader
