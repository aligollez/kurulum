import React from 'react'
import { Link, useLocation } from 'react-router-dom'
import { ButtonMenu, ButtonMenuItem } from '@nominex/dex-uikit'
import { useTranslation } from 'contexts/Localization'

const AppNavTabs = () => {
  const location = useLocation()
  const { t } = useTranslation()
  return (
    <ButtonMenu activeIndex={location.pathname.includes('/liquidity') ? 2 : 0} scale="sm">
      <ButtonMenuItem id="swap-nav-link" to="/swap" as={Link}>
        {t('Swap')}
      </ButtonMenuItem>
      <ButtonMenuItem id="limit-nav-link" disabled>
        {t('Limit')}
      </ButtonMenuItem>
      <ButtonMenuItem id="liquidity-nav-link" to="/liquidity" as={Link}>
        {t('Liquidity')}
      </ButtonMenuItem>
    </ButtonMenu>
  )
}

export default AppNavTabs
