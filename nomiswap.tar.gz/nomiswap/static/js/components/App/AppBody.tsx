import React from 'react'
import styled from 'styled-components'
import { Card, Flex, NotificationDot, TuneIcon } from '@nominex/dex-uikit'
import GlobalSettings from 'components/Menu/GlobalSettings'
import { useExpertModeManager } from 'state/user/hooks'
import AppNavTabs from './AppNavTabs'
import Transactions from './Transactions'

export const BodyWrapper = styled(Card)`
  max-width: 570px;
  width: 100%;
  z-index: 1;
`

interface Props {
  noConfig?: boolean
}

/**
 * The styled container element that wraps the content of most pages and the tabs.
 */
const AppBody: React.FC<Props> = ({ children, noConfig = false }) => {
  const [expertMode] = useExpertModeManager()

  return (
    <BodyWrapper isActive>
      <Flex flexDirection="column" py="24px" px="30px">
        <Flex alignItems="center" justifyContent="space-between">
          <AppNavTabs />
          <Flex alignItems="center">
            {!noConfig && (
              <NotificationDot show={expertMode}>
                <GlobalSettings IconComponent={TuneIcon} />
              </NotificationDot>
            )}
            <Transactions />
          </Flex>
        </Flex>
        {children}
      </Flex>
    </BodyWrapper>
  )
}

export default AppBody
