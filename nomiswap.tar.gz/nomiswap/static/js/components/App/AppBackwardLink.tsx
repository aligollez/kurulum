import React from 'react'
import { Link } from 'react-router-dom'
import { SpaceProps } from 'styled-system'
import { Flex, Text, Heading, ChevronLeftIcon, Box } from '@nominex/dex-uikit'

interface Props extends SpaceProps {
  title: string
  subtitle: string
  route: string
}

const AppBackwardLink: React.FC<Props> = ({ title, subtitle, route, ...props }) => (
  <Flex {...props}>
    <Link to={route}>
      <ChevronLeftIcon color="textSubtitle" />
    </Link>
    <Box marginLeft="8px">
      <Heading marginBottom="4px" scale="sm" color="contrast">
        {title}
      </Heading>
      <Text fontSize="14px" color="textSubtitle">
        {subtitle}
      </Text>
    </Box>
  </Flex>
)

export default AppBackwardLink
