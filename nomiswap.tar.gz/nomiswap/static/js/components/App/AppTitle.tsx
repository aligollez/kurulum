import React from 'react'
import { Flex, Text, Heading, FlexProps } from '@nominex/dex-uikit'
import styled from 'styled-components'

interface AppTitleProps extends FlexProps {
  title: string
  subtitle: string
}

export const AppTitle: React.FC<AppTitleProps> = ({ title, subtitle, ...props }) => (
  <Flex flexDirection="column" {...props}>
    <Heading marginBottom="8px" scale="xl" color="contrast">
      {title}
    </Heading>
    <Text fontSize="14px" color="textSubtitle">
      {subtitle}
    </Text>
  </Flex>
)

interface ExtendedAppTitleProps extends AppTitleProps {
  titleProps?: FlexProps
}

const ExtendedAppTitleWrapper = styled(Flex)`
  justify-content: space-between;
  flex-direction: column;
  align-items: flex-start;

  @media screen and (min-width: 1400px) {
    flex-direction: row;
    align-items: center;
  }
`

export const ExtendedAppTitle: React.FC<ExtendedAppTitleProps> = ({
  title,
  subtitle,
  titleProps = {},
  children,
  ...props
}) => (
  <ExtendedAppTitleWrapper {...props}>
    <AppTitle title={title} subtitle={subtitle} {...titleProps} />
    <Flex my="16px">{children}</Flex>
  </ExtendedAppTitleWrapper>
)
