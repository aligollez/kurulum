import React from 'react'
import styled from 'styled-components'
import { RowBetween } from 'components/Layout/Row'
import { AutoColumn } from 'components/Layout/Column'
import { useTranslation } from 'contexts/Localization'
import useTheme from 'hooks/useTheme'
import { ArrowForwardIcon } from '@nominex/dex-uikit'

type Props = {
  isFirstStepCompleted?: boolean
  disabled?: boolean
} & Parameters<typeof AutoColumn>[0]

const Grouping = styled(RowBetween)`
  width: 60%;
`

const Step = styled.div<{ disabled?: boolean }>`
  align-items: center;
  background: ${({ theme, disabled }) =>
    disabled ? theme.colors.backgroundDisabled : 'linear-gradient(79.77deg, #00A0FF 12.42%, #3283FC 87.69%)'};
  border-radius: 16px;
  color: ${({ theme, disabled }) => (disabled ? theme.colors.textDisabled : theme.colors.contrast)};
  cursor: default;
  display: flex;
  font-size: 12px;
  font-weight: 600;
  justify-content: center;
  padding: 0 8px;
  margin: 0 6px;
  min-height: 24px;
  white-space: nowrap;
`

const StepRow = styled.div`
  align-items: center;
  display: flex;
  width: calc(100% - 20px);
`

const DirectionFlow = styled.div`
  min-width: 24px;
  height: 24px;
  border-radius: 50%;
  background-color: ${({ theme }) => theme.colors.backgroundDisabled};
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 0 6px;
`

const Connector = styled.div`
  width: 100%;
  height: 1px;
  background-color: ${({ theme }) => theme.colors.backgroundDisabled};
  opacity: 0.6;
`

const ProgressSteps: React.FC<Props> = ({ isFirstStepCompleted, disabled, ...rest }) => {
  const { t } = useTranslation()
  const { theme } = useTheme()

  return (
    <AutoColumn justify="center" {...rest}>
      <Grouping>
        <StepRow>
          <Step disabled={disabled}>{isFirstStepCompleted ? '✓' : `${t('Step')} 1`}</Step>
          <Connector />
          <DirectionFlow>
            <ArrowForwardIcon color={theme.colors.textDisabled} width="14px" />
          </DirectionFlow>
          <Connector />
        </StepRow>
        <Step disabled={disabled || !isFirstStepCompleted}>{t('Step')} 2</Step>
      </Grouping>
    </AutoColumn>
  )
}

export default ProgressSteps
