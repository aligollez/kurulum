import React from 'react'
import { IconButton, HistoryIcon, useModal } from '@nominex/dex-uikit'
// import { useTranslation } from 'contexts/Localization'
import TransactionsModal from './TransactionsModal'

const Transactions = () => {
  const [onPresentTransactionsModal] = useModal(<TransactionsModal />)
  // const { t } = useTranslation()

  return (
    <>
      {/* <Button variant="text" onClick={onPresentTransactionsModal} scale="sm">
        {t('Transactions')}
      </Button> */}
      <IconButton onClick={onPresentTransactionsModal} variant="text" scale="sm">
        <HistoryIcon height={20} width={20} color="textSubtle" />
      </IconButton>
    </>
  )
}

export default Transactions
