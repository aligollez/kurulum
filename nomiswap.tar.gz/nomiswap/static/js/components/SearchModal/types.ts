export enum CurrencyModalView {
  search,
  manage,
  importToken,
  importList,
}

export default CurrencyModalView
