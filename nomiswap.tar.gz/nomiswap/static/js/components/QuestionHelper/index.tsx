import React from 'react'
import { HelpIcon, useTooltip, Box, BoxProps, Placement } from '@nominex/dex-uikit'
import styled from 'styled-components'

interface Props extends BoxProps {
  text: string | React.ReactNode
  placement?: Placement
}

const QuestionWrapper = styled.div`
  :hover,
  :focus {
    opacity: 0.7;
  }
`

const offsets = {
  'top-start': [-16, 10],
  'right-end': [16, 10],
}

const QuestionHelper: React.FC<Props> = ({ text, placement = 'right-end', ...props }) => {
  const tooltipOffset: [number, number] = placement in offsets ? offsets[placement] : [0, 0]
  const { targetRef, tooltip, tooltipVisible } = useTooltip(text, { placement, trigger: 'hover', tooltipOffset })

  return (
    <Box {...props}>
      {tooltipVisible && tooltip}
      <QuestionWrapper ref={targetRef}>
        <HelpIcon color="placeholder" width="12px" />
      </QuestionWrapper>
    </Box>
  )
}

export default QuestionHelper
