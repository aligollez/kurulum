import React, { useState } from 'react'
import { useLocation } from 'react-router'
import { Link } from 'react-router-dom'
import { fadeIn, fadeOut } from 'react-animations'
import styled, { css, keyframes } from 'styled-components'
import { ProSidebar, Menu, MenuItem, SidebarHeader, SidebarFooter, SidebarContent } from 'react-pro-sidebar'
import {
  Flex,
  ChevronLeftIcon,
  Image,
  LogoIcon,
  LogoWithTextIcon,
  SupportIcon,
  BookIcon,
  Pulsar,
  useMatchBreakpoints,
} from '@nominex/dex-uikit'
import { useTranslation } from 'contexts/Localization'
import { menuItemsConfig } from './config/config'

import 'react-pro-sidebar/dist/css/styles.css'
import './styles/styles.css'

declare global {
  interface Window {
    kayako: any
  }
}

const { kayako } = window

const fadeInAnimation = keyframes`${fadeIn}`
const fadeOutAnimation = keyframes`${fadeOut}`
const rotateAnimation = css`
  transform: rotate(180deg);
  transition: 0.5s transform ease;
`

const SidebarToggleStyled = styled.button<{ collapsed: boolean; visible: boolean }>`
  animation: 0.5s ${({ visible }) => (visible ? fadeInAnimation : fadeOutAnimation)};
  position: absolute;
  right: -12px;
  border: none;
  width: 24px;
  height: 24px;
  display: flex;
  justify-content: center;
  align-items: center;
  background: ${({ theme }) => theme.colors.gradients.accent};
  border-radius: 100%;
  cursor: pointer;
  z-index: 1010;
  top: 50%;
  transform: translateY(-50%);

  & > * {
    ${({ collapsed }) => collapsed && rotateAnimation};
    fill: ${({ theme }) => theme.colors.placeholder};
  }

  & path {
    transition: fill 0.2s ease;
  }

  &:hover > * {
    fill: ${({ theme }) => theme.colors.text};
  }
`

const asideDesktop = css`
  position: sticky;
  top: 0;
  left: 0;
  z-index: 21;
`

const AsideStyled = styled.aside<{ collapseToggleVisible: boolean; isMobile: boolean }>`
  border-right-width: 1px;
  border-right-style: solid;
  border-right-color: ${({ collapseToggleVisible }) => (collapseToggleVisible ? '#172648' : 'transparent')};
  height: 100vh;
  ${({ isMobile }) => !isMobile && asideDesktop};
`

const StyledKayakoTrigger = styled.span`
  color: ${({ theme }) => theme.colors.white};

  &:hover {
    color: ${({ theme }) => theme.colors.blue500};
  }
`

const Aside = ({ collapsed, toggled, handleCollapsedChange, handleToggleSidebar }) => {
  const { t } = useTranslation()
  const { pathname } = useLocation()
  const { isMobile } = useMatchBreakpoints()
  const menuItems = menuItemsConfig(t)

  const activeMenuItemHref = menuItems
    .map(({ href }) => href)
    .sort((hrefA, hrefB) => hrefB.length - hrefA.length) // We sort to find longest routes first
    .find((href) => pathname.startsWith(href))

  const [collapseToggleVisible, setCollapseToggleVisibility] = useState(!isMobile)

  const showCollapseToggle = (value: boolean) => {
    setCollapseToggleVisibility(value)
  }

  const toggleKayakoMessenger = () => {
    kayako.ready(() => {
      if (kayako.visibility() === 'minimized') {
        kayako.maximize()
      } else {
        kayako.minimize()
      }
    })
  }

  return (
    <AsideStyled
      id="main-navigation"
      collapseToggleVisible={collapseToggleVisible}
      isMobile={isMobile}
      onMouseEnter={() => showCollapseToggle(true)}
      onMouseLeave={() => showCollapseToggle(false)}
    >
      <ProSidebar
        collapsed={collapsed && !isMobile}
        toggled={toggled}
        onToggle={handleToggleSidebar}
        breakPoint="sm"
        width="260px"
        collapsedWidth="82px"
      >
        <SidebarHeader style={{ position: 'relative' }}>
          <Flex px="26px" py="28px">
            <Link to="/">
              {collapsed && !isMobile ? (
                <LogoIcon width="30px" height="30px" />
              ) : (
                <LogoWithTextIcon width="160px" height="32px" />
              )}
            </Link>
          </Flex>
          {(collapseToggleVisible || collapsed) && !isMobile && (
            <SidebarToggleStyled
              onClick={handleCollapsedChange}
              collapsed={collapsed}
              visible={collapseToggleVisible || collapsed}
            >
              <ChevronLeftIcon />
            </SidebarToggleStyled>
          )}
        </SidebarHeader>
        <SidebarContent>
          <Flex flexDirection="column" alignItems="stretch" justifyContent="space-between" style={{ height: '100%' }}>
            <Menu iconShape="square">
              {menuItems.map(({ label, href, IconComponent }) => {
                const isActive = href === activeMenuItemHref
                return (
                  <MenuItem
                    active={isActive}
                    icon={IconComponent && <IconComponent color="currentColor" />}
                    key={`menu-item-${label}`}
                  >
                    <Link to={href}>{label}</Link>
                  </MenuItem>
                )
              })}
            </Menu>
            {!collapsed && (
              <Flex justifyContent="center" pt="28px" pb="32px">
                <a
                  href="https://www.binance.org/en/blog/the-mvbii-phase-two-meet-top-20-projects/"
                  target="_blank"
                  rel="noreferrer"
                >
                  <Image src="/images/banners/mvb.png" alt="Most Valuable Builder" width={212} height={131} />
                </a>
              </Flex>
            )}
          </Flex>
        </SidebarContent>
        <SidebarFooter>
          <Menu iconShape="square">
            <MenuItem icon={<SupportIcon className="action-icon" color="indigo500" />} onClick={toggleKayakoMessenger}>
              <StyledKayakoTrigger>{t('Support')}</StyledKayakoTrigger>
            </MenuItem>
            <MenuItem icon={<BookIcon className="action-icon" color="purple500" />} suffix={<Pulsar />}>
              <a href="https://nomiswap.gitbook.io/" target="_blank" rel="noreferrer">
                {t('Knowledge base')}
              </a>
            </MenuItem>
          </Menu>
        </SidebarFooter>
      </ProSidebar>
    </AsideStyled>
  )
}

export default Aside
