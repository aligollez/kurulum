import { HomeIcon, SyncAltIcon, LiquidityIcon, FarmingIcon, PoolsIcon, UserPlusIcon } from '@nominex/dex-uikit'
import { ContextApi } from 'contexts/Localization/types'

type MenuItemsType = {
  label: string
  href: string
  IconComponent?: any
}

const menuItemsConfig: (t: ContextApi['t']) => MenuItemsType[] = (t) => [
  {
    label: t('Home'),
    href: '/',
    IconComponent: HomeIcon,
  },
  {
    label: t('Swap'),
    href: '/swap',
    IconComponent: SyncAltIcon,
  },
  {
    label: t('Liquidity'),
    href: '/liquidity',
    IconComponent: LiquidityIcon,
  },
  {
    label: t('Farms'),
    href: '/farms',
    IconComponent: FarmingIcon,
  },
  {
    label: t('Launchpools'),
    href: '/pools',
    IconComponent: PoolsIcon,
  },
  {
    label: t('Referral program'),
    href: '/referrals',
    IconComponent: UserPlusIcon,
  },
]

export { menuItemsConfig }
