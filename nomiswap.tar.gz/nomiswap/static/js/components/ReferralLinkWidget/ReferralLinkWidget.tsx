import React from 'react'
import styled from 'styled-components'
// import { Text, Flex, TelegramIcon, TwitterIcon, Link, FacebookIcon, LinkedinIcon } from '@nominex/dex-uikit'
import { Text } from '@nominex/dex-uikit'
import { useTranslation } from 'contexts/Localization'
import CopyAddress from '../Menu/UserMenu/CopyAddress'

const StyledWrapper = styled.div`
  height: fit-content;
  width: 416px;
  background: ${({ theme }) => theme.colors.gradients.primary};
  border-radius: 12px;
  box-shadow: 0px 5px 70px -40px #334bf8;
  padding: 24px;
`

/* const LinksWrapper = styled.div`
  display: grid;
  grid-auto-flow: column;
  grid-column-gap: 22px;
  align-items: center;
` */

const ReferralLinkWidget = ({ link, ...props }) => {
  const { t } = useTranslation()

  return (
    <StyledWrapper {...props}>
      <Text mb="20px" color="white">
        {t('My referral link')}
      </Text>
      <CopyAddress account={link} />

      {/* TODO: temporarily disabled
      <Flex justifyContent="space-between" mt="20px">
        <Text color="white">{t('Share link')}</Text>
        <LinksWrapper>
          <Link external href="https://t.me/nominex_announcements">
            <TelegramIcon width="14px" height="14px" color="white" />
          </Link>
          <Link external href="https://twitter.com/NominexExchange">
            <TwitterIcon width="14px" height="14px" color="white" />
          </Link>
          <Link external href="https://linkedin.com/company/14863255">
            <LinkedinIcon width="14px" height="14px" color="white" />
          </Link>
          <Link external href="https://www.facebook.com/Nominex">
            <FacebookIcon width="14px" height="14px" color="white" />
          </Link>
        </LinksWrapper>
      </Flex> */}
    </StyledWrapper>
  )
}

export default ReferralLinkWidget
