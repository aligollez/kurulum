import React from 'react'
import { Currency, Pair } from '@nominex/nomiswap-sdk'
import { Button, ArrowDropDownIcon, Text, useModal, Flex } from '@nominex/dex-uikit'
import styled from 'styled-components'
import { useTranslation } from 'contexts/Localization'
import useActiveWeb3React from 'hooks/useActiveWeb3React'
import { useCurrencyBalance } from '../../state/wallet/hooks'
import CurrencySearchModal from '../SearchModal/CurrencySearchModal'
import { CurrencyLogo, DoubleCurrencyLogo } from '../Logo'

import { RowBetween } from '../Layout/Row'
import { Input as NumericalInput } from './NumericalInput'

const InputRow = styled.div`
  display: flex;
  justify-content: stretch;
  padding: 0 24px 20px 16px;
`
const CurrencySelectButton = styled(Button).attrs({ variant: 'text', scale: 'md' })<{
  selected: boolean
}>`
  padding: 0 12px;
  background: ${({ theme, selected }) => (selected ? theme.colors.backgroundAlt : theme.colors.primary)};
  border-radius: 12px;
  color: ${({ theme, selected }) => (selected ? theme.colors.text : theme.colors.white)};
  font-weight: ${({ selected }) => (selected ? 500 : 600)};
  font-size: ${({ selected }) => (selected ? '18px' : '16px')};
`
const LabelRow = styled.div`
  display: flex;
  flex-flow: row nowrap;
  align-items: center;
  color: ${({ theme }) => theme.colors.text};
  font-size: 0.75rem;
  line-height: 1rem;
  padding: 16px 24px 4px 16px;
`
const InputPanel = styled.div<{ hideInput?: boolean }>`
  display: flex;
  flex-flow: column nowrap;
  position: relative;
  border-radius: ${({ hideInput }) => (hideInput ? '8px' : '12px')};
  background-color: ${({ theme }) => theme.colors.background};
  z-index: 1;
`
const Container = styled.div<{ hideInput: boolean }>`
  border-radius: 12px;
  background-color: ${({ theme }) => theme.colors.input};
  box-shadow: ${({ theme }) => theme.shadows.inset};
`

const MaxButton = styled(Button).attrs({ scale: 'none', variant: 'text' })`
  font-weight: 400;
`

interface CurrencyInputPanelProps {
  value: string
  onUserInput: (value: string) => void
  onMax?: () => void
  showMaxButton: boolean
  label?: string
  onCurrencySelect: (currency: Currency) => void
  currency?: Currency | null
  disableCurrencySelect?: boolean
  hideBalance?: boolean
  pair?: Pair | null
  hideInput?: boolean
  otherCurrency?: Currency | null
  id: string
  showCommonBases?: boolean
}
export default function CurrencyInputPanel({
  value,
  onUserInput,
  onMax,
  showMaxButton,
  label,
  onCurrencySelect,
  currency,
  disableCurrencySelect = false,
  hideBalance = false,
  pair = null, // used for double token logo
  hideInput = false,
  otherCurrency,
  id,
  showCommonBases,
}: CurrencyInputPanelProps) {
  const { account } = useActiveWeb3React()
  const selectedCurrencyBalance = useCurrencyBalance(account ?? undefined, currency ?? undefined)
  const { t } = useTranslation()
  const translatedLabel = label || t('Input')

  const [onPresentCurrencyModal] = useModal(
    <CurrencySearchModal
      onCurrencySelect={onCurrencySelect}
      selectedCurrency={currency}
      otherSelectedCurrency={otherCurrency}
      showCommonBases={showCommonBases}
    />,
  )
  return (
    <InputPanel id={id}>
      <Container hideInput={hideInput}>
        {!hideInput && (
          <LabelRow>
            <RowBetween>
              <Text fontSize="14px" color="placeholder">
                {translatedLabel}
              </Text>
              {account && (
                <Flex>
                  <Text
                    onClick={onMax}
                    fontSize="14px"
                    style={{ display: 'inline', cursor: 'pointer' }}
                    color="placeholder"
                  >
                    {!hideBalance && !!currency
                      ? t('Balance: %balance%', { balance: selectedCurrencyBalance?.toSignificant(6) ?? t('Loading') })
                      : ' -'}
                  </Text>
                  {currency && showMaxButton && label !== 'To' && <MaxButton onClick={onMax}>Max</MaxButton>}
                </Flex>
              )}
            </RowBetween>
          </LabelRow>
        )}
        <InputRow>
          <>
            <CurrencySelectButton
              selected={!!currency}
              className="open-currency-select-button"
              onClick={() => {
                if (!disableCurrencySelect) {
                  onPresentCurrencyModal()
                }
              }}
            >
              <Flex alignItems="center" justifyContent="space-between">
                {pair ? (
                  <DoubleCurrencyLogo currency0={pair.token0} currency1={pair.token1} size={16} mr="4px" />
                ) : currency ? (
                  <CurrencyLogo currency={currency} size="24px" style={{ marginRight: '8px' }} />
                ) : null}
                {pair
                  ? `${pair?.token0.symbol}:${pair?.token1.symbol}`
                  : (currency && currency.symbol && currency.symbol.length > 20
                      ? `${currency.symbol.slice(0, 4)}...${currency.symbol.slice(
                          currency.symbol.length - 5,
                          currency.symbol.length,
                        )}`
                      : currency?.symbol) || t('Select a currency')}
                {!disableCurrencySelect && (
                  <ArrowDropDownIcon width="10px" ml="10px" color={currency ? 'placeholder' : 'white'} />
                )}
              </Flex>
            </CurrencySelectButton>
            {!hideInput && (
              <NumericalInput
                align="right"
                className="token-amount-input"
                value={value}
                onUserInput={(val) => {
                  onUserInput(val)
                }}
              />
            )}
          </>
        </InputRow>
      </Container>
    </InputPanel>
  )
}
