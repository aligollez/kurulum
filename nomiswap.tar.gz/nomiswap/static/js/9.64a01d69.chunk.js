(this["webpackJsonpnomiswap-frontend"] = this["webpackJsonpnomiswap-frontend"] || []).push([
    [9], {
        1171: function(t, e, n) {
            "use strict";
            n.r(e), n.d(e, "default", (function() {
                return J
            }));
            var i = n(11),
                o = n(0),
                c = n(2),
                r = n(67),
                l = n(15),
                u = n(21),
                a = n(98),
                d = n(45),
                s = n(101),
                b = n(144),
                j = n(1);

            function O() {
                var t = Object(l.b)().t;
                return Object(j.jsxs)(c.O, {
                    flexDirection: "column",
                    alignItems: "center",
                    children: [Object(j.jsx)(c.Jb, {
                        color: "placeholder",
                        mb: "12px",
                        children: t("Don't see a pool you joined?")
                    }), Object(j.jsx)(c.o, {
                        id: "import-pool-link",
                        variant: "secondary",
                        scale: "sm",
                        as: r.a,
                        to: "/liquidity/find",
                        children: t("Find other LP tokens")
                    })]
                })
            }
            var h, m = n(247),
                p = n(4),
                x = n(40),
                f = n(192),
                g = n(369),
                v = n(222),
                y = n(9),
                k = n(5),
                q = Object(k.e)(c.t)(h || (h = Object(y.a)(["\n  background-color: ", ";\n  border-radius: 12px;\n  margin-top: 20px;\n  margin-bottom: 20px;\n  min-height: ", ";\n  display: flex;\n  flex-direction: column;\n"])), (function(t) {
                    return t.theme.colors.backgroundAlt2
                }), (function(t) {
                    return t.minHeight
                })),
                w = ["account", "isLoading", "items"],
                L = function(t) {
                    var e = t.account,
                        n = t.isLoading,
                        i = t.items,
                        o = void 0 === i ? [] : i,
                        r = Object(x.a)(t, w),
                        u = Object(l.b)().t,
                        a = Object(f.a)().theme;
                    return e ? n ? Object(j.jsx)(q, {
                        minHeight: "236px",
                        children: Object(j.jsx)(c.Jb, {
                            my: "auto",
                            color: "placeholder",
                            textAlign: "center",
                            children: Object(j.jsx)(v.a, {
                                children: u("Loading")
                            })
                        })
                    }) : (null === o || void 0 === o ? void 0 : o.length) > 0 ? Object(j.jsx)(c.P, Object(p.a)(Object(p.a)({}, r), {}, {
                        children: o.map((function(t) {
                            return Object(j.jsx)(g.b, {
                                pair: t,
                                background: a.colors.input,
                                mt: "20px"
                            }, t.liquidityToken.address)
                        }))
                    })) : null : Object(j.jsx)(q, {
                        minHeight: "236px",
                        children: Object(j.jsx)(c.Jb, {
                            color: "placeholder",
                            my: "auto",
                            textAlign: "center",
                            children: u("Connect to a wallet to view your liquidity.")
                        })
                    })
                };

            function J() {
                var t = Object(u.a)().account,
                    e = Object(l.b)().t,
                    n = Object(d.k)(),
                    h = Object(o.useMemo)((function() {
                        return n.map((function(t) {
                            return {
                                liquidityToken: Object(d.a)(t),
                                tokens: t
                            }
                        }))
                    }), [n]),
                    p = Object(o.useMemo)((function() {
                        return h.map((function(t) {
                            return t.liquidityToken
                        }))
                    }), [h]),
                    x = Object(a.f)(null !== t && void 0 !== t ? t : void 0, p),
                    f = Object(i.a)(x, 2),
                    g = f[0],
                    v = f[1],
                    y = Object(o.useMemo)((function() {
                        return h.filter((function(t) {
                            var e, n = t.liquidityToken;
                            return null === (e = g[n.address]) || void 0 === e ? void 0 : e.greaterThan("0")
                        }))
                    }), [h, g]),
                    k = Object(s.c)(y.map((function(t) {
                        return t.tokens
                    }))),
                    w = v || (null === k || void 0 === k ? void 0 : k.length) < y.length || (null === k || void 0 === k ? void 0 : k.some((function(t) {
                        return !t
                    }))),
                    J = k.map((function(t) {
                        return Object(i.a)(t, 2)[1]
                    })).filter((function(t) {
                        return Boolean(t)
                    }));
                return Object(j.jsxs)(m.a, {
                    children: [Object(j.jsx)(b.c, {
                        title: e("Your Liquidity"),
                        subtitle: e("Remove liquidity to receive tokens back"),
                        alignItems: "center",
                        mb: "24px"
                    }), Object(j.jsxs)(b.b, {
                        children: [Object(j.jsx)(L, {
                            pt: "16px",
                            account: !!t,
                            isLoading: w,
                            items: J
                        }), t && !w && Object(j.jsxs)(q, {
                            minHeight: 0 === J.length ? "236px" : "auto",
                            children: [0 === J.length && Object(j.jsx)(c.Jb, {
                                mt: "auto",
                                color: "placeholder",
                                textAlign: "center",
                                children: e("No liquidity found.")
                            }), Object(j.jsx)(O, {})]
                        }), Object(j.jsx)(c.o, {
                            scale: "lg",
                            id: "join-pool-button",
                            as: r.a,
                            to: "/liquidity/add",
                            width: "100%",
                            startIcon: Object(j.jsx)(c.a, {
                                color: "white"
                            }),
                            children: e("Add Liquidity")
                        })]
                    })]
                })
            }
        }
    }
]);
//# sourceMappingURL=9.64a01d69.chunk.js.map