(this["webpackJsonpnomiswap-frontend"] = this["webpackJsonpnomiswap-frontend"] || []).push([
    [10], {
        1173: function(e, t, r) {
            "use strict";
            r.r(t), r.d(t, "default", (function() {
                return y
            }));
            r(0);
            var n, i, c = r(28),
                s = r(2),
                a = r(15),
                o = r(144),
                j = r(4),
                l = r(40),
                b = r(9),
                p = r(5),
                x = r(433),
                d = r(1),
                h = ["link"],
                O = p.e.div(n || (n = Object(b.a)(["\n  height: fit-content;\n  width: 416px;\n  background: ", ";\n  border-radius: 12px;\n  box-shadow: 0px 5px 70px -40px #334bf8;\n  padding: 24px;\n"])), (function(e) {
                    return e.theme.colors.gradients.primary
                })),
                u = function(e) {
                    var t = e.link,
                        r = Object(l.a)(e, h),
                        n = Object(a.b)().t;
                    return Object(d.jsxs)(O, Object(j.a)(Object(j.a)({}, r), {}, {
                        children: [Object(d.jsx)(s.Jb, {
                            mb: "20px",
                            color: "white",
                            children: n("My referral link")
                        }), Object(d.jsx)(x.a, {
                            account: t
                        })]
                    }))
                },
                f = r(247),
                m = r(192),
                g = Object(p.e)(s.t)(i || (i = Object(b.a)(["\n  padding: 0 32px 48px 32px;\n"]))),
                w = function() {
                    var e = Object(a.b)().t,
                        t = Object(m.a)().theme,
                        r = Object(s.bc)(),
                        n = r.isTablet,
                        i = r.isMobile;
                    return Object(d.jsxs)(s.P, {
                        gridTemplateColumns: n || i ? "" : "repeat(3, 1fr)",
                        gridGap: "28px",
                        my: "16px",
                        children: [Object(d.jsx)(s.s, {
                            children: Object(d.jsxs)(g, {
                                children: [Object(d.jsx)(s.O, {
                                    justifyContent: "center",
                                    children: Object(d.jsx)(s.V, {
                                        src: "/images/referrals/step1.png",
                                        alt: "First step",
                                        height: 198,
                                        width: 318
                                    })
                                }), Object(d.jsxs)(s.O, {
                                    alignItems: "center",
                                    my: "12px",
                                    children: [Object(d.jsxs)(s.Hb, {
                                        variant: "lightBlue",
                                        mr: "12px",
                                        children: [e("Step"), " 1"]
                                    }), Object(d.jsx)(s.Jb, {
                                        fontSize: "20px",
                                        semibold: !0,
                                        children: e("Get a referral link")
                                    })]
                                }), Object(d.jsx)(s.Jb, {
                                    fontSize: "14px",
                                    color: "".concat(t.colors.white, "80"),
                                    children: e("Connect your wallet to get a referral link")
                                })]
                            })
                        }), Object(d.jsx)(s.s, {
                            children: Object(d.jsxs)(g, {
                                children: [Object(d.jsx)(s.O, {
                                    justifyContent: "center",
                                    children: Object(d.jsx)(s.V, {
                                        src: "/images/referrals/step2.png",
                                        alt: "First step",
                                        height: 198,
                                        width: 318
                                    })
                                }), Object(d.jsxs)(s.O, {
                                    alignItems: "center",
                                    my: "12px",
                                    children: [Object(d.jsxs)(s.Hb, {
                                        variant: "lightBlue",
                                        mr: "12px",
                                        children: [e("Step"), " 2"]
                                    }), Object(d.jsx)(s.Jb, {
                                        fontSize: "20px",
                                        semibold: !0,
                                        children: e("Invite friends")
                                    })]
                                }), Object(d.jsx)(s.Jb, {
                                    fontSize: "14px",
                                    color: "".concat(t.colors.white, "80"),
                                    children: e("Invite your friends to register via your referral link")
                                })]
                            })
                        }), Object(d.jsx)(s.s, {
                            children: Object(d.jsxs)(g, {
                                children: [Object(d.jsx)(s.O, {
                                    justifyContent: "center",
                                    children: Object(d.jsx)(s.V, {
                                        src: "/images/referrals/step3.png",
                                        alt: "First step",
                                        height: 198,
                                        width: 318
                                    })
                                }), Object(d.jsxs)(s.O, {
                                    alignItems: "center",
                                    my: "12px",
                                    children: [Object(d.jsxs)(s.Hb, {
                                        variant: "lightBlue",
                                        mr: "12px",
                                        children: [e("Step"), " 3"]
                                    }), Object(d.jsx)(s.Jb, {
                                        fontSize: "20px",
                                        semibold: !0,
                                        children: e("Earn crypto")
                                    })]
                                }), Object(d.jsx)(s.Jb, {
                                    fontSize: "14px",
                                    color: "".concat(t.colors.white, "80"),
                                    children: e("Receive referral rewards in NMX tokens from your friends\u2019 earnings & swaps")
                                })]
                            })
                        })]
                    })
                };

            function y() {
                var e = Object(a.b)().t,
                    t = Object(c.c)((function(e) {
                        return e.profile.authentication
                    })),
                    r = t.isLoaded,
                    n = t.userId;
                return Object(d.jsxs)(f.a, {
                    children: [Object(d.jsxs)(s.O, {
                        width: "100%",
                        justifyContent: "space-between",
                        flexWrap: "wrap",
                        children: [Object(d.jsx)(o.c, {
                            title: e("Invite Your Friends. Earn Cryptocurrency Together."),
                            subtitle: e("Nomiswap farms offer multiple farming opportunities to you. Increase your farming rewards participating in Team Farming program and continuously grow your extra bonuses for unstoppable farming up to 10x."),
                            maxWidth: "532px",
                            alignSelf: "start",
                            mb: "8px"
                        }), r && !!n && Object(d.jsx)(u, {
                            link: "https://nomiswap.io/?r=".concat(n)
                        })]
                    }), Object(d.jsx)(w, {})]
                })
            }
        }
    }
]);
//# sourceMappingURL=10.9d06f662.chunk.js.map